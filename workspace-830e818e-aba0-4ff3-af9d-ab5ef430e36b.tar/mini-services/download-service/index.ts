/**
 * YesCode — Download Service
 *
 * Standalone HTTP server for streaming large ZIP files without Next.js
 * body/response size limits. The Next.js download route redirects here
 * via XTransformPort query parameter.
 *
 * Port: 3030 (hardcoded)
 */

import { createServer, type IncomingMessage, type ServerResponse } from "node:http";
import { createReadStream, statSync, existsSync, readdirSync, readFileSync } from "node:fs";
import { basename } from "node:path";

const PORT = 3030;

const server = createServer((req: IncomingMessage, res: ServerResponse) => {
  const url = new URL(req.url ?? "/", `http://localhost:${PORT}`);
  const parts = url.pathname.split("/").filter(Boolean);

  if (parts[0] !== "download" || !parts[1]) {
    res.writeHead(404, { "Content-Type": "application/json" });
    res.end(JSON.stringify({ error: "Not found. Use /download/:jobId" }));
    return;
  }

  const jobId = parts[1];
  const pathFile = `/tmp/yescode/downloads/${jobId}.path`;

  try {
    let zipPath: string | null = null;

    if (existsSync(pathFile)) {
      zipPath = readFileSync(pathFile, "utf8").trim();
    }

    if (!zipPath || !existsSync(zipPath)) {
      // Try to find the ZIP by scanning the downloads directory
      const dlDir = "/tmp/yescode/downloads";
      if (existsSync(dlDir)) {
        const files = readdirSync(dlDir);
        const zipFile = files.find(
          (f) => f.includes(jobId.slice(0, 8)) && f.endsWith(".zip"),
        );
        if (zipFile) {
          zipPath = `${dlDir}/${zipFile}`;
        }
      }
    }

    if (!zipPath || !existsSync(zipPath)) {
      res.writeHead(404, { "Content-Type": "application/json" });
      res.end(JSON.stringify({ error: "ZIP not found for job " + jobId }));
      return;
    }

    const stat = statSync(zipPath);
    const name = basename(zipPath);

    res.writeHead(200, {
      "Content-Type": "application/zip",
      "Content-Length": String(stat.size),
      "Content-Disposition": `attachment; filename="${name}"`,
      "Cache-Control": "no-store",
      "Accept-Ranges": "bytes",
    });

    const stream = createReadStream(zipPath);
    stream.on("data", (chunk: Buffer) => {
      res.write(chunk);
    });
    stream.on("end", () => {
      res.end();
    });
    stream.on("error", (err: Error) => {
      console.error("[yescode-download] Stream error:", err.message);
      if (!res.headersSent) {
        res.writeHead(500);
      }
      res.end();
    });
    // Clean up pipe on client disconnect
    req.on("close", () => {
      stream.destroy();
    });
  } catch (err) {
    res.writeHead(500, { "Content-Type": "application/json" });
    res.end(JSON.stringify({ error: "Download failed", details: String(err) }));
  }
});

server.listen(PORT, "127.0.0.1", () => {
  console.log(`[yescode-download] listening on http://127.0.0.1:${PORT}`);
});
