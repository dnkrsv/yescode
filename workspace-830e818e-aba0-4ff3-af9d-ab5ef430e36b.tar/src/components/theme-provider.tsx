"use client";

import { ThemeProvider as NextThemesProvider } from "next-themes";
import type { ComponentProps } from "react";

/**
 * Wraps next-themes' ThemeProvider so children can read the current theme
 * (light/dark/system) via `useTheme()`. Default theme is dark — YesCode's
 * terminal aesthetic reads best on a dark canvas, but users can toggle.
 */
export function ThemeProvider({
  children,
  ...props
}: ComponentProps<typeof NextThemesProvider>) {
  return <NextThemesProvider {...props}>{children}</NextThemesProvider>;
}
