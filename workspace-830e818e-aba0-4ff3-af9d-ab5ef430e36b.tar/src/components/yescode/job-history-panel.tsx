"use client";

import { useEffect, useState, useCallback } from "react";
import { useJobStore, type JobHistoryEntry } from "@/stores/job-store";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  History,
  Download,
  CheckCircle2,
  XCircle,
  Loader2,
  Clock,
  RotateCcw,
  Trash2,
  X,
  Play,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { motion, AnimatePresence } from "framer-motion";
import { toast } from "sonner";
import type { ExportOptions } from "@/lib/exporter/pipeline";
import { CompareExportsDialog } from "./compare-exports-dialog";

function timeAgo(ts: number): string {
  const s = Math.floor((Date.now() - ts) / 1000);
  if (s < 60) return `${s}s ago`;
  if (s < 3600) return `${Math.floor(s / 60)}m ago`;
  if (s < 86400) return `${Math.floor(s / 3600)}h ago`;
  return `${Math.floor(s / 86400)}d ago`;
}

function formatBytes(bytes: number | null): string {
  if (!bytes) return "—";
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
}

function hostOf(url: string): string {
  try {
    return new URL(url).hostname.replace(/^www\./, "");
  } catch {
    return url.slice(0, 30);
  }
}

const STATUS_CONFIG: Record<
  JobHistoryEntry["status"],
  { icon: typeof CheckCircle2; className: string; label: string }
> = {
  completed: {
    icon: CheckCircle2,
    className: "text-emerald-600 dark:text-emerald-400",
    label: "done",
  },
  failed: {
    icon: XCircle,
    className: "text-destructive",
    label: "failed",
  },
  running: {
    icon: Loader2,
    className: "text-accent",
    label: "running",
  },
};

function HistoryRow({
  entry,
  isActive,
  onClick,
  onDelete,
}: {
  entry: JobHistoryEntry;
  isActive: boolean;
  onClick: () => void;
  onDelete: () => void;
}) {
  const cfg = STATUS_CONFIG[entry.status];
  // Render icon inline to satisfy react-hooks/static-components
  let iconEl: React.ReactNode;
  if (entry.status === "completed") {
    iconEl = <CheckCircle2 className={cn("h-3.5 w-3.5 shrink-0", cfg.className)} />;
  } else if (entry.status === "failed") {
    iconEl = <XCircle className={cn("h-3.5 w-3.5 shrink-0", cfg.className)} />;
  } else {
    iconEl = <Loader2 className={cn("h-3.5 w-3.5 shrink-0 animate-spin", cfg.className)} />;
  }

  return (
    <motion.div
      layout
      initial={{ opacity: 0, x: -8 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: -8, height: 0 }}
      transition={{ duration: 0.2 }}
      className={cn(
        "group relative rounded-lg border px-3 py-2.5 transition-all hover:shadow-sm",
        isActive
          ? "border-accent/50 bg-accent/5 shadow-sm"
          : "border-border bg-card/40 hover:border-accent/30",
      )}
    >
      <button
        type="button"
        onClick={onClick}
        className="w-full text-left"
      >
        <div className="flex items-center gap-2 mb-1">
          {iconEl}
          <span className="font-mono text-xs font-semibold truncate flex-1">
            {hostOf(entry.targetUrl)}
          </span>
          <span className="text-[10px] text-muted-foreground font-mono tabular-nums shrink-0">
            {timeAgo(entry.createdAt)}
          </span>
        </div>
        <div className="flex items-center gap-2 text-[10px] font-mono text-muted-foreground">
          {entry.outputZipName ? (
            <span className="truncate">{entry.outputZipName}</span>
          ) : (
            <span className="uppercase">{entry.label ?? entry.stage}</span>
          )}
          {entry.outputZipSizeBytes != null && (
            <>
              <span className="text-muted-foreground/50">·</span>
              <span className="tabular-nums">{formatBytes(entry.outputZipSizeBytes)}</span>
            </>
          )}
          {entry.nitStatus && entry.nitStatus !== "NOT_RUN" && (
            <>
              <span className="text-muted-foreground/50">·</span>
              <span
                className={cn(
                  "uppercase font-semibold",
                  entry.nitStatus === "PASSED"
                    ? "text-emerald-600 dark:text-emerald-400"
                    : "text-destructive",
                )}
              >
                NIT {entry.nitStatus}
              </span>
            </>
          )}
        </div>
      </button>
      {/* Delete button — appears on hover */}
      <button
        type="button"
        onClick={(e) => {
          e.stopPropagation();
          onDelete();
        }}
        className="absolute top-1.5 right-1.5 opacity-0 group-hover:opacity-100 transition-opacity h-6 w-6 inline-flex items-center justify-center rounded-md hover:bg-destructive/10 text-muted-foreground hover:text-destructive"
        aria-label="Delete from history"
        title={entry.status === "running" ? "Cancel job" : "Delete from history"}
      >
        {entry.status === "running" ? (
          <X className="h-3 w-3" />
        ) : (
          <Trash2 className="h-3 w-3" />
        )}
      </button>
    </motion.div>
  );
}

export function JobHistoryPanel() {
  const history = useJobStore((s) => s.history);
  const setHistory = useJobStore((s) => s.setHistory);
  const loadFromHistory = useJobStore((s) => s.loadFromHistory);
  const jobId = useJobStore((s) => s.jobId);
  const refresh = useJobStore((s) => s.reset);
  const [deleting, setDeleting] = useState<string | null>(null);
  const [clearing, setClearing] = useState(false);
  const [confirmClear, setConfirmClear] = useState(false);

  // Fetch history on mount and every 10s
  useEffect(() => {
    let cancelled = false;
    const fetchHistory = () => {
      fetch("/api/export")
        .then((r) => r.json())
        .then((d: { jobs: JobHistoryEntry[] }) => {
          if (!cancelled) setHistory(d.jobs ?? []);
        })
        .catch(() => {});
    };
    fetchHistory();
    const id = setInterval(fetchHistory, 10000);
    return () => {
      cancelled = true;
      clearInterval(id);
    };
  }, [setHistory]);

  const onDelete = useCallback(
    async (entry: JobHistoryEntry) => {
      setDeleting(entry.jobId);
      try {
        const res = await fetch(`/api/export/${entry.jobId}`, { method: "DELETE" });
        if (!res.ok) {
          const err = await res.json().catch(() => ({ error: "Delete failed" }));
          throw new Error(err.error || `HTTP ${res.status}`);
        }
        const data = await res.json();
        // Refresh history immediately
        const r = await fetch("/api/export");
        const d = (await r.json()) as { jobs: JobHistoryEntry[] };
        setHistory(d.jobs ?? []);
        if (entry.jobId === jobId) refresh();
        toast.success(
          data.action === "cancelled" ? "Job cancelled" : "Removed from history",
          { description: hostOf(entry.targetUrl) },
        );
      } catch (err) {
        const msg = err instanceof Error ? err.message : String(err);
        toast.error("Delete failed", { description: msg });
      } finally {
        setDeleting(null);
      }
    },
    [jobId, refresh, setHistory],
  );

  const onRerun = useCallback(
    async (entry: JobHistoryEntry) => {
      try {
        // Fetch the original job's options from the logs endpoint
        const logsRes = await fetch(`/api/export/${entry.jobId}/logs`);
        if (!logsRes.ok) throw new Error(`HTTP ${logsRes.status}`);
        const logsData = await logsRes.json();
        const originalOptions: ExportOptions | null = logsData.options ?? null;
        // POST a new export with the same URL + original options (if found)
        const res = await fetch("/api/export", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            url: entry.targetUrl,
            options: originalOptions ?? undefined,
          }),
        });
        if (!res.ok) {
          const err = await res.json().catch(() => ({ error: "Re-run failed" }));
          throw new Error(err.error || `HTTP ${res.status}`);
        }
        const data = (await res.json()) as { jobId: string };
        // Trigger the store to follow the new job via SSE
        const { useJobStore } = await import("@/stores/job-store");
        useJobStore.getState().startJob(
          data.jobId,
          entry.targetUrl,
          originalOptions ?? {},
        );
        toast.success("Re-running export", {
          description: `${hostOf(entry.targetUrl)} → job ${data.jobId.slice(0, 8)}`,
        });
      } catch (err) {
        const msg = err instanceof Error ? err.message : String(err);
        toast.error("Re-run failed", { description: msg });
      }
    },
    [],
  );

  const onClearAll = useCallback(async () => {
    // Two-click confirmation pattern: first click sets confirmClear=true,
    // second click within 5s actually clears.
    if (!confirmClear) {
      setConfirmClear(true);
      toast.info("Click 'Clear all' again to confirm", {
        description: "This will delete all completed/failed jobs + ZIP files",
      });
      setTimeout(() => setConfirmClear(false), 5000);
      return;
    }
    setConfirmClear(false);
    setClearing(true);
    try {
      const res = await fetch("/api/export", { method: "DELETE" });
      if (!res.ok) {
        const err = await res.json().catch(() => ({ error: "Clear failed" }));
        throw new Error(err.error || `HTTP ${res.status}`);
      }
      const data = (await res.json()) as { deleted: number; skippedRunning: number };
      // Refresh history
      const r = await fetch("/api/export");
      const d = (await r.json()) as { jobs: JobHistoryEntry[] };
      setHistory(d.jobs ?? []);
      refresh();
      toast.success(`Cleared ${data.deleted} job(s)`, {
        description: data.skippedRunning > 0 ? `${data.skippedRunning} running job(s) left alone` : undefined,
      });
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err);
      toast.error("Clear failed", { description: msg });
    } finally {
      setClearing(false);
    }
  }, [confirmClear, refresh, setHistory]);

  if (history.length === 0) {
    // Don't render the panel at all when there's no history — keeps the page clean
    return null;
  }

  return (
    <Card className="shadow-sm">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <History className="h-4 w-4 text-accent" />
            <CardTitle className="text-sm font-mono uppercase tracking-wider">
              History
            </CardTitle>
            <Badge variant="outline" className="font-mono text-[10px] h-5">
              {history.length}
            </Badge>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-[10px] text-muted-foreground font-mono hidden sm:inline">
              hover to delete · click to view
            </span>
            <CompareExportsDialog />
            <Button
              type="button"
              size="sm"
              variant="ghost"
              onClick={onClearAll}
              disabled={clearing || history.length === 0}
              className="h-7 px-2 text-[11px] font-mono gap-1 hover:text-destructive hover:bg-destructive/10"
              title="Clear all completed/failed jobs from history"
            >
              {clearing ? (
                <Loader2 className="h-3 w-3 animate-spin" />
              ) : (
                <Trash2 className="h-3 w-3" />
              )}
              Clear all
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent className="pt-0">
        <ScrollArea className="yescode-scroll max-h-72 pr-2">
          <div className="space-y-1.5">
            <AnimatePresence initial={false}>
              {history.map((entry) => (
                <div key={entry.jobId}>
                  <HistoryRow
                    entry={entry}
                    isActive={entry.jobId === jobId}
                    onClick={() => {
                      if (entry.jobId === jobId) return;
                      loadFromHistory(entry);
                    }}
                    onDelete={() => onDelete(entry)}
                  />
                  {deleting === entry.jobId && (
                    <div className="absolute inset-0 bg-background/60 backdrop-blur-sm flex items-center justify-center rounded-lg">
                      <Loader2 className="h-4 w-4 animate-spin text-accent" />
                    </div>
                  )}
                  {entry.status === "completed" && entry.jobId === jobId && (
                    <div className="flex gap-2 mt-1.5 ml-1">
                      <Button asChild size="sm" variant="ghost" className="h-7 px-2 text-[11px] font-mono">
                        <a href={`/api/export/${entry.jobId}/download`} download>
                          <Download className="h-3 w-3 mr-1" />
                          Download
                        </a>
                      </Button>
                      <Button
                        size="sm"
                        variant="ghost"
                        className="h-7 px-2 text-[11px] font-mono"
                        onClick={() => onRerun(entry)}
                      >
                        <Play className="h-3 w-3 mr-1" />
                        Re-run
                      </Button>
                      <Button
                        size="sm"
                        variant="ghost"
                        className="h-7 px-2 text-[11px] font-mono"
                        onClick={() => refresh()}
                      >
                        <RotateCcw className="h-3 w-3 mr-1" />
                        New
                      </Button>
                    </div>
                  )}
                </div>
              ))}
            </AnimatePresence>
          </div>
        </ScrollArea>
        <p className="mt-3 text-[10px] text-muted-foreground font-mono flex items-center gap-1">
          <Clock className="h-3 w-3" />
          Auto-refreshes every 10s · persisted across restarts
        </p>
      </CardContent>
    </Card>
  );
}
