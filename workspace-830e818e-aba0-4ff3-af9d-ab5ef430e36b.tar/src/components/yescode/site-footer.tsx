"use client";

import { Github, Shield, Zap, FileArchive, Heart } from "lucide-react";

export function SiteFooter() {
  return (
    <footer className="mt-auto border-t border-border bg-card/40 backdrop-blur">
      <div className="mx-auto max-w-6xl px-4 sm:px-6 py-6">
        <div className="flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <div className="h-7 w-7 rounded-md bg-gradient-to-br from-accent to-foreground flex items-center justify-center">
              <span className="font-sans font-extrabold text-sm text-background">Y</span>
            </div>
            <div className="flex flex-col">
              <span className="font-mono font-bold text-sm tracking-tight leading-tight">
                YesCode
              </span>
              <span className="text-[10px] text-muted-foreground font-mono leading-tight">
                standalone static site exporter
              </span>
            </div>
          </div>
          <div className="flex items-center gap-4 text-xs text-muted-foreground font-mono">
            <span className="inline-flex items-center gap-1.5">
              <Shield className="h-3.5 w-3.5 text-accent" />
              NIT-gated
            </span>
            <span className="inline-flex items-center gap-1.5">
              <Zap className="h-3.5 w-3.5 text-accent" />
              14-stage pipeline
            </span>
            <span className="inline-flex items-center gap-1.5">
              <FileArchive className="h-3.5 w-3.5 text-accent" />
              Deterministic ZIP
            </span>
            <a
              href="#"
              className="inline-flex items-center gap-1.5 hover:text-foreground transition-colors"
              aria-label="Source"
            >
              <Github className="h-3.5 w-3.5" />
              Source
            </a>
          </div>
          <p className="text-[11px] text-muted-foreground font-mono flex items-center gap-1">
            <span>Yes to pure code.</span>
            <Heart className="h-3 w-3 text-accent fill-accent" />
            <span>No to Framer bindings.</span>
          </p>
        </div>
      </div>
    </footer>
  );
}
