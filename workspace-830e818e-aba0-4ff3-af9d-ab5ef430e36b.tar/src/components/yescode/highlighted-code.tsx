"use client";

import { useState, useEffect, type CSSProperties } from "react";

/**
 * YesCode — lazy-loaded syntax highlighter wrapper.
 *
 * react-syntax-highlighter is a heavy dependency (~1MB with all languages).
 * We lazy-load it via dynamic import so it only ships when the user opens
 * the ZIP preview dialog and selects a file. Falls back to a plain <pre>
 * if the import fails (e.g., in an offline build).
 *
 * Uses Prism with the "one-dark" theme — matches the amber accent palette
 * and reads well on the zinc-950 terminal background.
 */

type Language =
  | "html"
  | "xml"
  | "css"
  | "javascript"
  | "json"
  | "markdown"
  | "yaml"
  | "typescript"
  | "jsx"
  | "tsx"
  | "plaintext";

const EXT_TO_LANG: Record<string, Language> = {
  html: "html",
  htm: "html",
  xml: "xml",
  svg: "xml",
  css: "css",
  js: "javascript",
  mjs: "javascript",
  cjs: "javascript",
  json: "json",
  webmanifest: "json",
  map: "json",
  md: "markdown",
  yaml: "yaml",
  yml: "yaml",
  ts: "typescript",
  tsx: "tsx",
  jsx: "jsx",
  txt: "plaintext",
};

interface HighlightedCodeProps {
  code: string;
  ext: string;
  truncated?: boolean;
  truncatedAt?: number;
}

/** Format bytes for the truncation notice. */
function formatBytes(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
}

const codeBlockStyle: CSSProperties = {
  margin: 0,
  padding: "12px",
  fontFamily: "var(--font-roboto-mono), ui-monospace, monospace",
  fontSize: "11px",
  lineHeight: 1.6,
  background: "transparent",
};

const customStyle: CSSProperties = {
  margin: 0,
  padding: 0,
  background: "transparent",
  minHeight: "100%",
};

export function HighlightedCode({
  code,
  ext,
  truncated,
  truncatedAt,
}: HighlightedCodeProps) {
  const [Highlighter, setHighlighter] = useState<{
    Prism: React.ComponentType<{
      language: string;
      style: unknown;
      customStyle?: CSSProperties;
      codeTagProps?: { style: CSSProperties };
      children: string;
    }>;
    style: unknown;
  } | null>(null);
  const [loadFailed, setLoadFailed] = useState(false);

  useEffect(() => {
    let cancelled = false;
    void (async () => {
      try {
        const mod = await import("react-syntax-highlighter");
        const styleMod = await import(
          "react-syntax-highlighter/dist/esm/styles/prism/one-dark"
        );
        if (!cancelled) {
          setHighlighter({
            Prism: mod.Prism,
            style: (styleMod as { default: unknown }).default,
          });
        }
      } catch {
        if (!cancelled) setLoadFailed(true);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  const language = EXT_TO_LANG[ext.toLowerCase()] ?? "plaintext";

  if (loadFailed || !Highlighter) {
    // Fallback: plain pre while loading or if dynamic import failed
    return (
      <pre
        style={codeBlockStyle}
        className="whitespace-pre-wrap break-words text-zinc-100 min-h-full"
      >
        {code}
        {truncated && (
          <span className="block mt-3 pt-3 border-t border-zinc-800 text-zinc-500 text-[10px]">
            ⚠ Truncated at {formatBytes(truncatedAt ?? 0)} — download ZIP for
            full file
          </span>
        )}
      </pre>
    );
  }

  const { Prism, style } = Highlighter;
  return (
    <div className="min-h-full">
      <Prism
        language={language}
        style={style}
        customStyle={customStyle}
        codeTagProps={{ style: codeBlockStyle }}
      >
        {code}
      </Prism>
      {truncated && (
        <div className="mt-3 pt-3 border-t border-zinc-800 text-zinc-500 text-[10px] font-mono px-3 pb-3">
          ⚠ Truncated at {formatBytes(truncatedAt ?? 0)} — download ZIP for full
          file
        </div>
      )}
    </div>
  );
}
