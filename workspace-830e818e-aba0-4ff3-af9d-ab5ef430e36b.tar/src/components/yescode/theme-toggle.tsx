"use client";

import { useEffect, useState } from "react";
import { useTheme } from "next-themes";
import { Moon, Sun, MonitorSmartphone } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { cn } from "@/lib/utils";

type Theme = "light" | "dark" | "system";

const OPTIONS: { value: Theme; label: string; icon: typeof Moon }[] = [
  { value: "light", label: "Light", icon: Sun },
  { value: "dark", label: "Dark", icon: Moon },
  { value: "system", label: "System", icon: MonitorSmartphone },
];

/**
 * YesCode theme toggle. Sits in the top-right corner as a fixed pill, with
 * a dropdown for light/dark/system. Persists choice via next-themes
 * (localStorage). Renders a placeholder until mounted to avoid hydration
 * mismatch.
 */
export function ThemeToggle({ className }: { className?: string }) {
  const [mounted, setMounted] = useState(false);
  const { theme, setTheme, resolvedTheme } = useTheme();

  useEffect(() => {
    // Mark as mounted in a microtask to avoid synchronous setState in
    // the effect body (react-hooks/set-state-in-effect rule).
    Promise.resolve().then(() => setMounted(true));
  }, []);

  if (!mounted) {
    return (
      <div
        className={cn(
          "h-9 w-9 rounded-md border border-border bg-card/60",
          className,
        )}
        aria-hidden
      />
    );
  }

  const current =
    OPTIONS.find((o) => o.value === theme) ?? OPTIONS[1];
  const CurrentIcon = current.icon;
  const isDark = (resolvedTheme ?? theme) === "dark";

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button
          variant="outline"
          size="icon"
          className={cn(
            "h-9 w-9 rounded-md border-border bg-card/60 backdrop-blur hover:bg-accent/10 hover:border-accent/40 transition-colors",
            className,
          )}
          aria-label={`Toggle theme (current: ${current.label})`}
        >
          <CurrentIcon
            className={cn(
              "h-4 w-4 transition-all",
              isDark ? "text-accent" : "text-foreground",
            )}
          />
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="min-w-[8rem]">
        {OPTIONS.map((opt) => {
          const Icon = opt.icon;
          const active = theme === opt.value;
          return (
            <DropdownMenuItem
              key={opt.value}
              onClick={() => setTheme(opt.value)}
              className={cn(
                "cursor-pointer gap-2 font-mono text-xs",
                active && "bg-accent/10 text-accent",
              )}
            >
              <Icon className="h-3.5 w-3.5" />
              {opt.label}
              {active && (
                <span className="ml-auto text-[10px] uppercase text-accent">
                  ●
                </span>
              )}
            </DropdownMenuItem>
          );
        })}
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
