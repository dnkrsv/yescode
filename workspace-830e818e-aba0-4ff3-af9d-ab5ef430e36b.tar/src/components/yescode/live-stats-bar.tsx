"use client";

import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { CheckCircle2, FileArchive, Zap, TrendingUp, Clock, ShieldCheck, Globe } from "lucide-react";

interface StatsResponse {
  counts: { total: number; running: number; completed: number; failed: number };
  successRate: number;
  avgDurationMs: number;
  maxDurationMs: number;
  totalArchiveSizeBytes: number;
  avgRoutesPerExport: number;
  nitPassRate: number;
  topHosts: Array<{ host: string; count: number }>;
  generatedAt: number;
}

/**
 * YesCode — live aggregate stats bar shown below the hero subtitle.
 * Fetches /api/stats on mount + every 30s and displays:
 *   total jobs, success rate, avg duration, NIT pass rate, archived size,
 *   and a "live" indicator. Also renders a Top Hosts widget when there
 *   are multiple distinct hosts.
 */
export function LiveStatsBar() {
  const [stats, setStats] = useState<StatsResponse | null>(null);

  useEffect(() => {
    let cancelled = false;
    const fetchStats = async () => {
      try {
        const r = await fetch("/api/stats");
        if (!r.ok) return;
        const d = (await r.json()) as StatsResponse;
        if (!cancelled) setStats(d);
      } catch {
        // silent
      }
    };
    fetchStats();
    const id = setInterval(fetchStats, 30000);
    return () => {
      cancelled = true;
      clearInterval(id);
    };
  }, []);

  if (!stats || stats.counts.total === 0) return null;

  const fmtDuration = (ms: number) => {
    if (ms < 1000) return `${ms}ms`;
    if (ms < 60000) return `${(ms / 1000).toFixed(1)}s`;
    return `${Math.floor(ms / 60000)}m${Math.floor((ms % 60000) / 1000)}s`;
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 0.35 }}
      className="mt-6 flex flex-col items-center gap-3"
    >
      <div className="flex flex-wrap items-center justify-center gap-2 sm:gap-3 text-[11px] font-mono">
        <StatPill icon={TrendingUp} iconClass="text-accent" label="total" value={String(stats.counts.total)} />
        <StatPill icon={CheckCircle2} iconClass="text-emerald-500" label="success" value={`${stats.successRate}%`} />
        <StatPill icon={Clock} iconClass="text-accent" label="avg" value={fmtDuration(stats.avgDurationMs)} />
        <StatPill icon={ShieldCheck} iconClass={stats.nitPassRate === 100 ? "text-emerald-500" : "text-amber-500"} label="NIT" value={`${stats.nitPassRate}%`} />
        <StatPill icon={FileArchive} iconClass="text-accent" label="archived" value={formatBytes(stats.totalArchiveSizeBytes)} />
        <StatPill icon={Zap} iconClass="text-accent" label="live" value="" pulse />
      </div>
      {stats.topHosts.length > 0 && (
        <TopHostsWidget hosts={stats.topHosts} />
      )}
    </motion.div>
  );
}

function StatPill({
  icon: Icon,
  iconClass,
  label,
  value,
  pulse,
}: {
  icon: React.ElementType;
  iconClass: string;
  label: string;
  value: string;
  pulse?: boolean;
}) {
  return (
    <motion.span
      whileHover={{ y: -1, scale: 1.03 }}
      transition={{ type: "spring", stiffness: 300, damping: 20 }}
      className="inline-flex items-center gap-1.5 rounded-full border border-border bg-card/60 backdrop-blur px-3 py-1.5 hover:border-accent/40 transition-colors group"
    >
      <Icon className={`h-3 w-3 ${iconClass} ${pulse ? "yescode-pulse" : ""} group-hover:scale-110 transition-transform`} />
      <span className="text-muted-foreground">{label}</span>
      {value && <span className="font-bold tabular-nums">{value}</span>}
    </motion.span>
  );
}

function TopHostsWidget({ hosts }: { hosts: Array<{ host: string; count: number }> }) {
  const maxCount = Math.max(...hosts.map((h) => h.count), 1);
  return (
    <motion.div
      initial={{ opacity: 0, y: 4 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, delay: 0.5 }}
      className="w-full max-w-2xl rounded-lg border border-border bg-card/40 backdrop-blur px-4 py-2.5"
    >
      <div className="flex items-center gap-2 mb-1.5">
        <Globe className="h-3 w-3 text-accent" />
        <span className="font-mono text-[10px] uppercase tracking-wider text-muted-foreground">
          Top hosts
        </span>
      </div>
      <div className="flex flex-wrap gap-x-4 gap-y-1">
        {hosts.slice(0, 5).map((h) => (
          <div key={h.host} className="flex items-center gap-1.5 min-w-0">
            <span className="font-mono text-[11px] truncate max-w-32" title={h.host}>
              {h.host}
            </span>
            <div className="h-1.5 w-12 rounded-full bg-muted overflow-hidden">
              <motion.div
                className="h-full bg-accent rounded-full"
                initial={{ width: 0 }}
                animate={{ width: `${(h.count / maxCount) * 100}%` }}
                transition={{ duration: 0.6, delay: 0.6 }}
              />
            </div>
            <span className="font-mono text-[10px] tabular-nums text-muted-foreground">
              {h.count}
            </span>
          </div>
        ))}
      </div>
    </motion.div>
  );
}

function formatBytes(bytes: number): string {
  if (bytes < 1024) return `${bytes}B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)}K`;
  return `${(bytes / (1024 * 1024)).toFixed(1)}M`;
}
