"use client";

import { useEffect, useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { useKeyboardShortcut } from "@/hooks/use-keyboard-shortcut";
import { useJobStore } from "@/stores/job-store";
import { Keyboard, Command, CornerDownLeft, Escape, Slash } from "lucide-react";
import { cn } from "@/lib/utils";

interface ShortcutDef {
  keys: string[];
  description: string;
  category: "global" | "export" | "navigation";
}

const SHORTCUTS: ShortcutDef[] = [
  {
    keys: ["⌘", "↵"],
    description: "Submit export form",
    category: "export",
  },
  {
    keys: ["?"],
    description: "Toggle this shortcuts dialog",
    category: "global",
  },
  {
    keys: ["Esc"],
    description: "Close dialogs / clear focus",
    category: "global",
  },
  {
    keys: ["/"],
    description: "Focus URL input",
    category: "navigation",
  },
];

const CATEGORY_LABELS: Record<ShortcutDef["category"], string> = {
  global: "Global",
  export: "Export",
  navigation: "Navigation",
};

/**
 * YesCode — keyboard shortcuts help dialog. Opens when the user presses `?`
 * (when not focused in an input). Shows all available shortcuts grouped by
 * category. Also auto-focuses the URL input when `/` is pressed.
 */
export function ShortcutsHelp() {
  const [open, setOpen] = useState(false);
  const status = useJobStore((s) => s.status);

  // ? toggles the dialog (only when not typing in an input)
  useKeyboardShortcut({
    combo: "?",
    handler: () => setOpen((v) => !v),
    allowInInput: false,
  });

  // / focuses the URL input
  useKeyboardShortcut({
    combo: "/",
    enabled: status !== "running",
    handler: () => {
      const input = document.querySelector<HTMLInputElement>('input[type="url"]');
      input?.focus();
      input?.select();
    },
  });

  // Esc closes the dialog (Dialog already handles this, but we listen to
  // be explicit)
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        e.preventDefault();
        setOpen(false);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open]);

  const grouped = SHORTCUTS.reduce(
    (acc, s) => {
      (acc[s.category] ??= []).push(s);
      return acc;
    },
    {} as Record<string, ShortcutDef[]>,
  );

  return (
    <>
      {/* Floating help button — bottom-left, subtle */}
      <button
        type="button"
        onClick={() => setOpen(true)}
        className="fixed bottom-4 left-4 z-40 h-9 w-9 rounded-md border border-border bg-card/60 backdrop-blur shadow-sm flex items-center justify-center hover:border-accent/40 hover:bg-accent/10 transition-colors group"
        aria-label="Keyboard shortcuts (?)"
        title="Keyboard shortcuts (?)"
      >
        <Keyboard className="h-4 w-4 text-muted-foreground group-hover:text-accent" />
      </button>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="font-mono text-sm flex items-center gap-2">
              <Keyboard className="h-4 w-4 text-accent" />
              Keyboard shortcuts
            </DialogTitle>
            <DialogDescription className="font-mono text-xs">
              Press <kbd className="font-mono">?</kbd> anytime to toggle this dialog
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-2">
            {Object.entries(grouped).map(([cat, items]) => (
              <div key={cat}>
                <h3 className="font-mono text-[10px] uppercase tracking-wider text-muted-foreground mb-2">
                  {CATEGORY_LABELS[cat as ShortcutDef["category"]]}
                </h3>
                <div className="space-y-1.5">
                  {items.map((s) => (
                    <div
                      key={s.description}
                      className="flex items-center justify-between gap-3 py-1"
                    >
                      <span className="text-xs text-foreground/80">
                        {s.description}
                      </span>
                      <div className="flex items-center gap-1">
                        {s.keys.map((k, i) => (
                          <kbd
                            key={i}
                            className={cn(
                              "inline-flex items-center justify-center min-w-6 h-6 px-1.5 rounded border border-border bg-muted font-mono text-[10px] font-semibold",
                            )}
                          >
                            {k}
                          </kbd>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}

// Silence unused imports — they're re-exported for potential future use
void Command;
void CornerDownLeft;
void Slash;
