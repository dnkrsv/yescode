"use client";

import { useEffect, useState } from "react";
import { toast } from "sonner";
import { Keyboard } from "lucide-react";

const STORAGE_KEY = "yescode:onboarded";
const ONBOARDING_DELAY_MS = 2000; // wait 2s after page load

/**
 * YesCode — first-visit onboarding hint.
 *
 * Shows a toast "Press ? for keyboard shortcuts" once per browser (tracked
 * via localStorage). Runs on mount, checks localStorage, sets the flag, and
 * fires the toast after a short delay so it doesn't overlap with the hero
 * entrance animation.
 *
 * Silent on subsequent visits. No-op if localStorage is unavailable.
 */
export function OnboardingHint() {
  const [shown, setShown] = useState(false);

  useEffect(() => {
    let cancelled = false;
    const check = () => {
      if (cancelled) return;
      try {
        const seen = localStorage.getItem(STORAGE_KEY);
        if (seen) return; // already onboarded
        // Schedule the hint
        setTimeout(() => {
          if (cancelled) return;
          localStorage.setItem(STORAGE_KEY, Date.now().toString());
          setShown(true);
          toast.info("Welcome to YesCode", {
            description: "Press ? to see keyboard shortcuts · / to focus the URL input",
            duration: 6000,
            icon: <Keyboard className="h-4 w-4 text-accent" />,
          });
        }, ONBOARDING_DELAY_MS);
      } catch {
        // localStorage unavailable — skip silently
      }
    };
    check();
    return () => {
      cancelled = true;
    };
  }, []);

  // This component renders nothing visible — it only fires a toast.
  void shown;
  return null;
}
