"use client";

import { useJobStore } from "@/stores/job-store";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import {
  Download,
  CheckCircle2,
  XCircle,
  RefreshCw,
  ShieldCheck,
  ShieldAlert,
  FileArchive,
  Route,
  Image as ImageIcon,
  Code2,
  Type as TypeIcon,
  Gauge,
  Package,
  Copy,
  Check,
} from "lucide-react";
import { motion } from "framer-motion";
import { ZipPreviewDialog } from "./zip-preview-dialog";
import { useState, useCallback } from "react";
import { toast } from "sonner";
import { copyToClipboard } from "@/lib/clipboard";

/** Inline "job id" row with a copy button — appears under the success title. */
function CopyJobIdRow({ jobId }: { jobId: string }) {
  const [copied, setCopied] = useState(false);
  const onCopy = useCallback(async () => {
    const ok = await copyToClipboard(jobId);
    if (ok) {
      setCopied(true);
      toast.success("Job ID copied", {
        description: jobId.slice(0, 12) + "…",
      });
      setTimeout(() => setCopied(false), 2000);
    } else {
      toast.error("Copy failed", { description: "Clipboard not available in this browser" });
    }
  }, [jobId]);
  return (
    <button
      type="button"
      onClick={onCopy}
      className="mt-1.5 inline-flex items-center gap-1.5 text-[10px] font-mono text-muted-foreground hover:text-accent transition-colors group"
      title="Copy full job ID"
    >
      <span className="tabular-nums">id:{jobId.slice(0, 8)}</span>
      {copied ? (
        <Check className="h-3 w-3 text-emerald-500" />
      ) : (
        <Copy className="h-3 w-3 opacity-50 group-hover:opacity-100" />
      )}
    </button>
  );
}

function MetricTile({
  icon: Icon,
  label,
  value,
  hint,
}: {
  icon: React.ElementType;
  label: string;
  value: string;
  hint?: string;
}) {
  return (
    <motion.div
      whileHover={{ y: -2, scale: 1.02 }}
      transition={{ type: "spring", stiffness: 300, damping: 20 }}
      className="rounded-lg border border-border bg-background/60 px-3 py-3 flex flex-col gap-1 hover:border-accent/40 hover:bg-accent/5 transition-colors cursor-default group"
    >
      <div className="flex items-center gap-2 text-[11px] font-mono uppercase tracking-wider text-muted-foreground group-hover:text-accent transition-colors">
        <Icon className="h-3.5 w-3.5 group-hover:scale-110 transition-transform" />
        {label}
      </div>
      <p className="font-mono text-lg font-semibold tabular-nums leading-tight">
        {value}
      </p>
      {hint && (
        <p className="text-[10px] text-muted-foreground font-mono truncate">{hint}</p>
      )}
    </motion.div>
  );
}

function formatBytes(bytes: number): string {
  if (!bytes) return "0 B";
  const units = ["B", "KB", "MB", "GB"];
  const i = Math.min(units.length - 1, Math.floor(Math.log(bytes) / Math.log(1024)));
  const v = bytes / Math.pow(1024, i);
  return `${v.toFixed(i === 0 ? 0 : 2)} ${units[i]}`;
}

export function ResultCards() {
  const status = useJobStore((s) => s.status);
  const metrics = useJobStore((s) => s.metrics);
  const error = useJobStore((s) => s.error);
  const jobId = useJobStore((s) => s.jobId);
  const reset = useJobStore((s) => s.reset);

  if (status === "idle" || status === "running") return null;

  if (status === "failed") {
    return (
      <motion.div
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-3xl mx-auto"
      >
        <Card className="border-destructive/40 bg-destructive/5">
          <CardHeader>
            <div className="flex items-center gap-3">
              <div className="rounded-full bg-destructive/15 p-2">
                <XCircle className="h-6 w-6 text-destructive" />
              </div>
              <div>
                <CardTitle className="text-xl">Export failed</CardTitle>
                <CardDescription className="font-mono text-xs">
                  Job {jobId?.slice(0, 12) ?? "unknown"} did not complete.
                </CardDescription>
              </div>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <pre className="yescode-scroll max-h-48 overflow-auto rounded-lg bg-zinc-950 text-zinc-100 p-3 font-mono text-xs whitespace-pre-wrap break-words">
              {error ?? "Unknown error"}
            </pre>
            <div className="flex flex-wrap gap-3">
              <Button onClick={reset} variant="default" className="h-11 px-5">
                <RefreshCw className="h-4 w-4 mr-2" />
                Try Again
              </Button>
              <Button
                onClick={() =>
                  window.open(`/api/export/${jobId}/logs`, "_blank")
                }
                variant="outline"
                className="h-11 px-5 font-mono"
              >
                <FileArchive className="h-4 w-4 mr-2" />
                View full logs
              </Button>
            </div>
          </CardContent>
        </Card>
      </motion.div>
    );
  }

  // completed
  if (!metrics) return null;
  const nitPassed = metrics.nitStatus === "PASSED";

  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      className="w-full max-w-3xl mx-auto"
    >
      <Card className="border-accent/40 shadow-lg overflow-hidden">
        <CardHeader className="bg-gradient-to-br from-accent/15 to-transparent border-b border-accent/20">
          <div className="flex items-start justify-between gap-3 flex-wrap">
            <div className="flex items-center gap-3">
              <div className="rounded-full bg-accent/20 p-2">
                <CheckCircle2 className="h-6 w-6 text-accent" />
              </div>
              <div className="min-w-0">
                <CardTitle className="text-xl">Export complete</CardTitle>
                <CardDescription className="font-mono text-xs">
                  ZIP ready — fully self-contained, no Framer calls.
                </CardDescription>
                {jobId && (
                  <CopyJobIdRow jobId={jobId} />
                )}
              </div>
            </div>
            <Badge
              className={
                nitPassed
                  ? "bg-emerald-500/15 text-emerald-700 dark:text-emerald-300 border-emerald-500/30 font-mono uppercase"
                  : "bg-destructive/15 text-destructive border-destructive/30 font-mono uppercase"
              }
            >
              {nitPassed ? (
                <ShieldCheck className="h-3.5 w-3.5 mr-1.5" />
              ) : (
                <ShieldAlert className="h-3.5 w-3.5 mr-1.5" />
              )}
              NIT {metrics.nitStatus}
            </Badge>
          </div>
        </CardHeader>
        <CardContent className="space-y-5 pt-5">
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
            <MetricTile
              icon={Route}
              label="Routes"
              value={String(metrics.totalRoutes)}
              hint="discovered"
            />
            <MetricTile
              icon={Package}
              label="Assets"
              value={String(metrics.totalAssets)}
              hint="localized"
            />
            <MetricTile
              icon={Gauge}
              label="Size"
              value={formatBytes(metrics.totalSizeBytes)}
              hint="raw extracted"
            />
            <MetricTile
              icon={FileArchive}
              label="ZIP"
              value={formatBytes(metrics.outputZipSizeBytes)}
              hint={metrics.outputZipName}
            />
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
            <MetricTile
              icon={Code2}
              label="JS Modules"
              value={String(metrics.totalJsModules)}
              hint="rewritten"
            />
            <MetricTile
              icon={Code2}
              label="CSS"
              value={String(metrics.totalCssFiles)}
              hint="rewritten"
            />
            <MetricTile
              icon={ImageIcon}
              label="Images"
              value={String(metrics.totalImages)}
              hint="downloaded"
            />
            <MetricTile
              icon={TypeIcon}
              label="Fonts"
              value={String(metrics.totalFonts)}
              hint="vendored"
            />
          </div>

          <div className="flex items-center justify-between rounded-lg border border-border bg-muted/30 px-4 py-2.5">
            <div className="flex items-center gap-2 text-xs font-mono">
              <span className="text-muted-foreground">duration:</span>
              <span className="font-semibold tabular-nums">
                {(metrics.durationMs / 1000).toFixed(2)}s
              </span>
              <span className="text-muted-foreground mx-2">|</span>
              <span className="text-muted-foreground">NIT calls blocked:</span>
              <span
                className={
                  "font-semibold tabular-nums " +
                  (metrics.nitProhibitedCalls === 0
                    ? "text-emerald-600 dark:text-emerald-400"
                    : "text-destructive")
                }
              >
                {metrics.nitProhibitedCalls}
              </span>
              <span className="text-muted-foreground mx-2">|</span>
              <span className="text-muted-foreground">console errors:</span>
              <span
                className={
                  "font-semibold tabular-nums " +
                  (metrics.nitConsoleErrors === 0
                    ? "text-emerald-600 dark:text-emerald-400"
                    : "text-destructive")
                }
              >
                {metrics.nitConsoleErrors}
              </span>
            </div>
          </div>

          <div className="flex flex-wrap gap-3 pt-1">
            <Button
              asChild
              className="h-12 px-6 text-base font-semibold shadow-sm"
            >
              <a href={`/api/export/${jobId}/download`} download>
                <Download className="h-5 w-5 mr-2" />
                Download ZIP
              </a>
            </Button>
            <ZipPreviewDialog />
            <Button
              onClick={reset}
              variant="outline"
              className="h-12 px-5 font-mono"
            >
              <RefreshCw className="h-4 w-4 mr-2" />
              New export
            </Button>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}
