"use client";

import { useJobStore } from "@/stores/job-store";
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible";
import { Badge } from "@/components/ui/badge";
import {
  TerminalSquare,
  ChevronDown,
  Pause,
  Play,
} from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { cn } from "@/lib/utils";
import type { ProgressEvent } from "@/lib/exporter/pipeline";

const LEVEL_COLORS: Record<string, string> = {
  INFO: "text-emerald-600 dark:text-emerald-400",
  WARN: "text-amber-600 dark:text-amber-400",
  ERROR: "text-red-600 dark:text-red-400",
  DEBUG: "text-slate-500 dark:text-slate-400",
};

const STAGE_TAG: Record<string, string> = {
  QUEUED: "bg-slate-500/15 text-slate-600 dark:text-slate-300",
  PREFLIGHT: "bg-cyan-500/15 text-cyan-700 dark:text-cyan-300",
  DISCOVERY: "bg-violet-500/15 text-violet-700 dark:text-violet-300",
  CAPTURE: "bg-rose-500/15 text-rose-700 dark:text-rose-300",
  GRAPH: "bg-amber-500/15 text-amber-700 dark:text-amber-300",
  MATERIALIZE: "bg-emerald-500/15 text-emerald-700 dark:text-emerald-300",
  REWRITE: "bg-teal-500/15 text-teal-700 dark:text-teal-300",
  CLEANUP: "bg-pink-500/15 text-pink-700 dark:text-pink-300",
  ROUTING: "bg-indigo-500/15 text-indigo-700 dark:text-indigo-300",
  SEO: "bg-fuchsia-500/15 text-fuchsia-700 dark:text-fuchsia-300",
  RESIDUAL_SCAN: "bg-orange-500/15 text-orange-700 dark:text-orange-300",
  NIT: "bg-red-500/20 text-red-700 dark:text-red-300",
  PACKAGING: "bg-lime-500/15 text-lime-700 dark:text-lime-300",
  COMPLETED: "bg-emerald-500/20 text-emerald-700 dark:text-emerald-300",
};

function fmtTime(ts: number): string {
  const d = new Date(ts);
  return (
    String(d.getHours()).padStart(2, "0") +
    ":" +
    String(d.getMinutes()).padStart(2, "0") +
    ":" +
    String(d.getSeconds()).padStart(2, "0") +
    "." +
    String(d.getMilliseconds()).padStart(3, "0")
  );
}

function LogRow({ ev }: { ev: ProgressEvent }) {
  const level = ev.level ?? "INFO";
  return (
    <div className="grid grid-cols-[auto_auto_auto_1fr] gap-x-3 items-start px-3 py-1.5 border-b border-border/40 hover:bg-muted/30 font-mono text-[12px] leading-relaxed">
      <span className="text-muted-foreground/70 tabular-nums">
        {fmtTime(ev.timestamp)}
      </span>
      <span
        className={cn(
          "px-1.5 py-0.5 rounded text-[10px] font-semibold uppercase tracking-tight w-fit self-center",
          STAGE_TAG[ev.stage] ?? "bg-muted text-muted-foreground",
        )}
      >
        {ev.stage}
      </span>
      <span
        className={cn(
          "font-semibold text-[10px] uppercase self-center",
          LEVEL_COLORS[level],
        )}
      >
        {level}
      </span>
      <span className="text-foreground/90 break-words min-w-0">
        {ev.message}
      </span>
    </div>
  );
}

export function LogDrawer() {
  const logs = useJobStore((s) => s.logs);
  const status = useJobStore((s) => s.status);
  const [open, setOpen] = useState(true);
  const [paused, setPaused] = useState(false);
  const scrollRef = useRef<HTMLDivElement | null>(null);
  const [, setTick] = useState(0);

  // Force re-render periodically while running so timestamps look live.
  useEffect(() => {
    if (status !== "running") return;
    const id = setInterval(() => setTick((t) => t + 1), 500);
    return () => clearInterval(id);
  }, [status]);

  // Auto-scroll to bottom when new logs arrive (unless paused).
  useEffect(() => {
    if (paused || !open) return;
    const el = scrollRef.current;
    if (el) el.scrollTop = el.scrollHeight;
  }, [logs, paused, open]);

  // Auto-open when first log arrives.
  useEffect(() => {
    if (logs.length > 0 && !open) setOpen(true);
  }, [logs.length, open]);

  const running = status === "running";

  return (
    <Collapsible
      open={open}
      onOpenChange={setOpen}
      className="w-full rounded-xl border border-border bg-card/80 backdrop-blur shadow-sm overflow-hidden"
    >
      <CollapsibleTrigger asChild>
        <button
          className="w-full flex items-center justify-between gap-3 px-4 py-3 hover:bg-muted/40 transition-colors"
          aria-expanded={open}
        >
          <div className="flex items-center gap-3">
            <TerminalSquare
              className={cn(
                "h-5 w-5",
                running ? "text-accent" : "text-muted-foreground",
              )}
            />
            <div className="flex items-baseline gap-2">
              <span className="font-mono text-sm font-semibold">
                Export Log
              </span>
              <span className="text-xs text-muted-foreground font-mono tabular-nums">
                {logs.length} event{logs.length === 1 ? "" : "s"}
              </span>
            </div>
            {running && (
              <span className="flex items-center gap-1.5 text-[11px] font-mono text-accent">
                <span className="h-2 w-2 rounded-full bg-accent yescode-pulse" />
                LIVE
              </span>
            )}
          </div>
          <div className="flex items-center gap-2">
            {running && (
              <span
                role="button"
                tabIndex={0}
                onClick={(e) => {
                  e.stopPropagation();
                  setPaused((p) => !p);
                }}
                onKeyDown={(e) => {
                  if (e.key === "Enter" || e.key === " ") {
                    e.preventDefault();
                    e.stopPropagation();
                    setPaused((p) => !p);
                  }
                }}
                className="inline-flex items-center justify-center h-7 px-2 rounded-md hover:bg-muted/60 cursor-pointer text-xs font-mono transition-colors"
                title={paused ? "Resume auto-scroll" : "Pause auto-scroll"}
                aria-label={paused ? "Resume auto-scroll" : "Pause auto-scroll"}
              >
                {paused ? (
                  <Play className="h-3 w-3" />
                ) : (
                  <Pause className="h-3 w-3" />
                )}
              </span>
            )}
            <Badge
              variant="outline"
              className="font-mono text-[10px] h-5 uppercase"
            >
              {status}
            </Badge>
            <ChevronDown
              className={cn(
                "h-4 w-4 text-muted-foreground transition-transform",
                open && "rotate-180",
              )}
            />
          </div>
        </button>
      </CollapsibleTrigger>
      <CollapsibleContent>
        <div
          ref={scrollRef}
          className="yescode-scroll max-h-96 overflow-y-auto bg-zinc-950 dark:bg-zinc-950 text-zinc-100 border-t border-border"
        >
          {logs.length === 0 ? (
            <div className="px-3 py-6 text-center font-mono text-xs text-zinc-500">
              <span className="text-accent yescode-cursor">▌</span> waiting for
              pipeline events…
            </div>
          ) : (
            <>
              <div className="px-3 py-1.5 text-[10px] font-mono text-zinc-500 bg-zinc-900/50 border-b border-zinc-800 sticky top-0 z-10">
                $ yescode --tail logs
              </div>
              {logs.map((ev, i) => (
                <LogRow key={`${ev.timestamp}-${i}`} ev={ev} />
              ))}
              {running && (
                <div className="px-3 py-1.5 font-mono text-xs text-zinc-500 border-t border-zinc-800">
                  <span className="text-accent yescode-cursor">▌</span>{" "}
                  {useJobStore.getState().message}
                </div>
              )}
            </>
          )}
        </div>
      </CollapsibleContent>
    </Collapsible>
  );
}
