"use client";

import { useEffect, useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  BarChart3,
  TrendingUp,
  Clock,
  HardDrive,
  CheckCircle2,
  Loader2,
  FileJson,
  FileSpreadsheet,
} from "lucide-react";
import { motion } from "framer-motion";
import { cn } from "@/lib/utils";
import {
  ResponsiveContainer,
  BarChart as ReBarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  LineChart as ReLineChart,
  Line,
  Area,
  AreaChart,
  Cell,
} from "recharts";

interface HistoryStats {
  exportsOverTime: Array<{ date: string; total: number; completed: number; failed: number }>;
  durationTrend: Array<{ jobId: string; host: string; durationMs: number; createdAt: number }>;
  sizeBuckets: Record<string, number>;
  successRateTrend: Array<{ window: string; rate: number; total: number }>;
  totalAnalyzed: number;
  generatedAt: number;
}

interface AggregateStats {
  counts: { total: number; running: number; completed: number; failed: number };
  successRate: number;
  avgDurationMs: number;
  maxDurationMs: number;
  totalArchiveSizeBytes: number;
  avgRoutesPerExport: number;
  nitPassRate: number;
  topHosts: Array<{ host: string; count: number }>;
}

function formatBytes(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
}

function formatDuration(ms: number): string {
  if (ms < 1000) return `${ms}ms`;
  if (ms < 60000) return `${(ms / 1000).toFixed(1)}s`;
  return `${Math.floor(ms / 60000)}m${Math.floor((ms % 60000) / 1000)}s`;
}

function shortDate(iso: string): string {
  return iso.slice(5); // MM-DD
}

const ACCENT_COLOR = "oklch(0.78 0.16 65)";
const DESTRUCTIVE_COLOR = "oklch(0.577 0.245 27.325)";

const tooltipStyle = {
  backgroundColor: "var(--popover)",
  border: "1px solid var(--border)",
  borderRadius: "6px",
  fontSize: "11px",
  fontFamily: "var(--font-roboto-mono), monospace",
  color: "var(--popover-foreground)",
};

/**
 * YesCode — Stats Dashboard modal with recharts visualizations.
 */
export function StatsDashboard() {
  const [open, setOpen] = useState(false);
  const [agg, setAgg] = useState<AggregateStats | null>(null);
  const [history, setHistory] = useState<HistoryStats | null>(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!open) return;
    let cancelled = false;
    void (async () => {
      setLoading(true);
      try {
        const [aggRes, histRes] = await Promise.all([
          fetch("/api/stats"),
          fetch("/api/stats/history"),
        ]);
        if (!cancelled) {
          if (aggRes.ok) setAgg((await aggRes.json()) as AggregateStats);
          if (histRes.ok) setHistory((await histRes.json()) as HistoryStats);
        }
      } catch {
        // silent
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [open]);

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button
          variant="outline"
          className="h-9 px-3 rounded-md border-border bg-card/60 backdrop-blur hover:border-accent/40 hover:bg-accent/10 font-mono text-xs gap-1.5"
        >
          <BarChart3 className="h-4 w-4 text-accent" />
          <span className="hidden sm:inline">Dashboard</span>
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-4xl max-h-[85vh] flex flex-col gap-0 p-0">
        <DialogHeader className="px-5 pt-5 pb-3 border-b border-border">
          <DialogTitle className="font-mono text-sm flex items-center gap-2">
            <BarChart3 className="h-4 w-4 text-accent" />
            Stats Dashboard
            {agg && (
              <Badge variant="outline" className="font-mono text-[10px] h-5 ml-2">
                {agg.counts.total} jobs
              </Badge>
            )}
          </DialogTitle>
          <DialogDescription className="font-mono text-xs">
            Historical trends and aggregate metrics across all exports
          </DialogDescription>
        </DialogHeader>

        <ScrollArea className="yescode-scroll flex-1 max-h-[70vh]">
          {loading && (
            <div className="flex items-center justify-center py-16 text-muted-foreground">
              <Loader2 className="h-5 w-5 animate-spin mr-2" />
              <span className="font-mono text-xs">Computing stats…</span>
            </div>
          )}

          {!loading && agg && history && (
            <div className="p-5 space-y-5">
              {/* Summary tiles */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <SummaryTile icon={TrendingUp} label="Total" value={String(agg.counts.total)} accent />
                <SummaryTile icon={CheckCircle2} label="Success" value={`${agg.successRate}%`} />
                <SummaryTile icon={Clock} label="Avg dur" value={formatDuration(agg.avgDurationMs)} />
                <SummaryTile icon={HardDrive} label="Archived" value={formatBytes(agg.totalArchiveSizeBytes)} />
              </div>

              {/* Exports over time */}
              <ChartCard title="Exports over time" subtitle="Last 30 days · completed vs failed">
                <ReBarChart data={history.exportsOverTime.map((d) => ({ date: shortDate(d.date), completed: d.completed, failed: d.failed }))}>
                  <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" opacity={0.3} />
                  <XAxis dataKey="date" stroke="var(--muted-foreground)" fontSize={9} fontFamily="monospace" tick={{ fill: "var(--muted-foreground)" }} />
                  <YAxis stroke="var(--muted-foreground)" fontSize={9} fontFamily="monospace" allowDecimals={false} width={20} />
                  <Tooltip contentStyle={tooltipStyle} cursor={{ fill: "var(--accent)", fillOpacity: 0.05 }} />
                  <Bar dataKey="completed" stackId="a" fill={ACCENT_COLOR} radius={[0, 0, 0, 0]} name="Completed" />
                  <Bar dataKey="failed" stackId="a" fill={DESTRUCTIVE_COLOR} radius={[2, 2, 0, 0]} name="Failed" />
                </ReBarChart>
              </ChartCard>

              {/* Duration trend */}
              {history.durationTrend.length > 0 && (
                <ChartCard title="Duration trend" subtitle={`Last ${history.durationTrend.length} exports`}>
                  <AreaChart data={history.durationTrend.map((d) => ({ host: d.host, duration: d.durationMs }))}>
                    <defs>
                      <linearGradient id="durGrad" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="0%" stopColor={ACCENT_COLOR} stopOpacity={0.4} />
                        <stop offset="100%" stopColor={ACCENT_COLOR} stopOpacity={0} />
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" opacity={0.3} />
                    <XAxis dataKey="host" stroke="var(--muted-foreground)" fontSize={9} fontFamily="monospace" tick={{ fill: "var(--muted-foreground)" }} />
                    <YAxis stroke="var(--muted-foreground)" fontSize={9} fontFamily="monospace" width={40} tickFormatter={(v) => formatDuration(v)} />
                    <Tooltip
                      contentStyle={tooltipStyle}
                      formatter={(v: number) => [formatDuration(v), "Duration"]}
                    />
                    <Area type="monotone" dataKey="duration" stroke={ACCENT_COLOR} strokeWidth={2} fill="url(#durGrad)" name="Duration" />
                  </AreaChart>
                </ChartCard>
              )}

              {/* Size distribution */}
              <ChartCard title="Size distribution" subtitle="ZIP size buckets">
                <ReBarChart
                  data={Object.entries(history.sizeBuckets).map(([label, value]) => ({ label, count: value }))}
                  layout="vertical"
                >
                  <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" opacity={0.3} horizontal={false} />
                  <XAxis type="number" stroke="var(--muted-foreground)" fontSize={9} fontFamily="monospace" allowDecimals={false} />
                  <YAxis type="category" dataKey="label" stroke="var(--muted-foreground)" fontSize={9} fontFamily="monospace" width={70} tick={{ fill: "var(--muted-foreground)" }} />
                  <Tooltip contentStyle={tooltipStyle} cursor={{ fill: "var(--accent)", fillOpacity: 0.05 }} />
                  <Bar dataKey="count" radius={[0, 2, 2, 0]} name="Count">
                    {Object.entries(history.sizeBuckets).map(([key], i) => (
                      <Cell key={i} fill={ACCENT_COLOR} fillOpacity={0.3 + (i * 0.12)} />
                    ))}
                  </Bar>
                </ReBarChart>
              </ChartCard>

              {/* Success rate trend */}
              {history.successRateTrend.length > 0 && (
                <ChartCard title="Success rate trend" subtitle="7-day rolling windows">
                  <ReLineChart data={history.successRateTrend.map((d) => ({ window: d.window, rate: d.rate }))}>
                    <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" opacity={0.3} />
                    <XAxis dataKey="window" stroke="var(--muted-foreground)" fontSize={9} fontFamily="monospace" tick={{ fill: "var(--muted-foreground)" }} />
                    <YAxis stroke="var(--muted-foreground)" fontSize={9} fontFamily="monospace" domain={[0, 100]} width={30} tickFormatter={(v) => `${v}%`} />
                    <Tooltip
                      contentStyle={tooltipStyle}
                      formatter={(v: number) => [`${v}%`, "Success rate"]}
                    />
                    <Line type="monotone" dataKey="rate" stroke={ACCENT_COLOR} strokeWidth={2} dot={{ r: 3, fill: ACCENT_COLOR }} activeDot={{ r: 5 }} name="Success rate" />
                  </ReLineChart>
                </ChartCard>
              )}

              {/* Export buttons */}
              <div className="flex flex-wrap gap-2 pt-2 border-t border-border">
                <Button asChild variant="outline" size="sm" className="font-mono text-xs h-8">
                  <a href="/api/export/download-csv?format=csv" download>
                    <FileSpreadsheet className="h-3.5 w-3.5 mr-1.5" />
                    Export CSV
                  </a>
                </Button>
                <Button asChild variant="outline" size="sm" className="font-mono text-xs h-8">
                  <a href="/api/export/download-csv?format=json" download>
                    <FileJson className="h-3.5 w-3.5 mr-1.5" />
                    Export JSON
                  </a>
                </Button>
              </div>
            </div>
          )}

          {!loading && !agg && (
            <div className="px-5 py-12 text-center text-muted-foreground font-mono text-xs">
              No stats available yet. Run an export first.
            </div>
          )}
        </ScrollArea>
      </DialogContent>
    </Dialog>
  );
}

function SummaryTile({
  icon: Icon,
  label,
  value,
  accent,
}: {
  icon: React.ElementType;
  label: string;
  value: string;
  accent?: boolean;
}) {
  return (
    <motion.div
      whileHover={{ y: -2 }}
      transition={{ type: "spring", stiffness: 300, damping: 20 }}
      className={cn(
        "rounded-lg border px-3 py-2.5 flex flex-col gap-1",
        accent ? "border-accent/30 bg-accent/5" : "border-border bg-card/40",
      )}
    >
      <div className="flex items-center gap-1.5 text-[10px] font-mono uppercase tracking-wider text-muted-foreground">
        <Icon className="h-3 w-3" />
        {label}
      </div>
      <p className="font-mono text-lg font-bold tabular-nums leading-tight">{value}</p>
    </motion.div>
  );
}

function ChartCard({
  title,
  subtitle,
  children,
}: {
  title: string;
  subtitle: string;
  children: React.ReactNode;
}) {
  return (
    <div className="rounded-lg border border-border bg-card/40 p-4">
      <div className="flex items-baseline justify-between mb-3">
        <h3 className="font-mono text-xs font-semibold uppercase tracking-wider">{title}</h3>
        <span className="font-mono text-[10px] text-muted-foreground">{subtitle}</span>
      </div>
      <div className="h-48 w-full">
        <ResponsiveContainer width="100%" height="100%">
          {children}
        </ResponsiveContainer>
      </div>
    </div>
  );
}
