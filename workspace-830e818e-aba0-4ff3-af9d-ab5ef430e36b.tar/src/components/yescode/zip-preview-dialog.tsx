"use client";

import { useEffect, useState, type ComponentType } from "react";
import { useJobStore } from "@/stores/job-store";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  Folder,
  FolderOpen,
  FileText,
  FileCode2,
  FileImage,
  FileArchive,
  File as FileIcon,
  ChevronRight,
  Loader2,
  Eye,
  AlertCircle,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { HighlightedCode } from "./highlighted-code";

interface TreeNode {
  type: "dir" | "file";
  name: string;
  path: string;
  children?: TreeNode[];
  size?: number;
  ext?: string;
}

interface ContentsResponse {
  jobId: string;
  zipName: string;
  totalFiles: number;
  totalSize: number;
  tree: TreeNode[];
}

interface FilePreview {
  path: string;
  name: string;
  ext: string;
  mime: string;
  size: number;
  truncated: boolean;
  truncatedAt: number;
  content: string;
}

function formatBytes(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
}

const EXT_ICON_MAP: Record<string, ComponentType<{ className?: string }>> = {
  html: FileText,
  htm: FileText,
  css: FileCode2,
  js: FileCode2,
  mjs: FileCode2,
  json: FileCode2,
  svg: FileImage,
  png: FileImage,
  jpg: FileImage,
  jpeg: FileImage,
  webp: FileImage,
  gif: FileImage,
  ico: FileImage,
  woff2: FileArchive,
  woff: FileArchive,
  ttf: FileArchive,
  otf: FileArchive,
  xml: FileText,
  txt: FileText,
  md: FileText,
};

// Extensions previewable via /contents/[filePath] endpoint
const PREVIEWABLE_EXT = new Set([
  "html", "htm", "css", "js", "mjs", "cjs", "json", "xml", "txt", "svg",
  "md", "csv", "yaml", "yml", "ts", "tsx", "jsx", "webmanifest", "map",
]);

interface TreeRowProps {
  node: TreeNode;
  depth: number;
  selectedPath: string | null;
  onSelect: (node: TreeNode) => void;
}

function TreeRow({ node, depth, selectedPath, onSelect }: TreeRowProps) {
  const [expanded, setExpanded] = useState(depth < 1);
  const isDir = node.type === "dir";
  const childCount = node.children?.length ?? 0;
  const isSelected = !isDir && selectedPath === node.path;
  const isPreviewable = !isDir && !!node.ext && PREVIEWABLE_EXT.has(node.ext);
  const iconClassName = cn(
    "h-3.5 w-3.5 shrink-0",
    isDir ? "text-accent" : isSelected ? "text-accent" : "text-muted-foreground",
  );

  let iconEl: React.ReactNode;
  if (isDir) {
    iconEl = childCount > 0 ? <FolderOpen className={iconClassName} /> : <Folder className={iconClassName} />;
  } else if (node.ext && node.ext in EXT_ICON_MAP) {
    const Cmp = EXT_ICON_MAP[node.ext];
    iconEl = <Cmp className={iconClassName} />;
  } else {
    iconEl = <FileIcon className={iconClassName} />;
  }

  return (
    <div>
      <button
        type="button"
        onClick={() => {
          if (isDir) setExpanded((v) => !v);
          else if (isPreviewable) onSelect(node);
        }}
        className={cn(
          "flex items-center gap-2 w-full text-left px-2 py-1.5 rounded-md transition-colors",
          isDir && "cursor-pointer hover:bg-muted/50",
          !isDir && isPreviewable && "cursor-pointer hover:bg-accent/10",
          isSelected && "bg-accent/15 text-accent",
          !isDir && !isPreviewable && "cursor-default opacity-60",
        )}
        style={{ paddingLeft: `${depth * 16 + 8}px` }}
      >
        {isDir ? (
          <ChevronRight
            className={cn(
              "h-3 w-3 text-muted-foreground shrink-0 transition-transform",
              expanded && "rotate-90",
            )}
          />
        ) : (
          <span className="w-3 shrink-0 flex items-center justify-center">
            {isPreviewable && <Eye className="h-2.5 w-2.5 text-accent/60" />}
          </span>
        )}
        {iconEl}
        <span
          className={cn(
            "font-mono text-xs truncate",
            isDir ? "font-semibold text-foreground" : isSelected ? "text-accent" : "text-foreground/80",
          )}
        >
          {node.name}
        </span>
        {isDir && childCount > 0 && (
          <span className="text-[10px] text-muted-foreground font-mono tabular-nums">
            {childCount}
          </span>
        )}
        {!isDir && node.size !== undefined && (
          <span className="ml-auto text-[10px] text-muted-foreground font-mono tabular-nums">
            {formatBytes(node.size)}
          </span>
        )}
      </button>
      {isDir && expanded && node.children && (
        <div className="border-l border-border/40 ml-4">
          {node.children.map((child, idx) => (
            <TreeRow
              key={`${child.path}-${idx}`}
              node={child}
              depth={depth + 1}
              selectedPath={selectedPath}
              onSelect={onSelect}
            />
          ))}
        </div>
      )}
    </div>
  );
}

function FilePreviewPanel({
  preview,
  loading,
  error,
}: {
  preview: FilePreview | null;
  loading: boolean;
  error: string | null;
}) {
  if (loading) {
    return (
      <div className="flex items-center justify-center h-full text-muted-foreground">
        <Loader2 className="h-4 w-4 animate-spin mr-2" />
        <span className="font-mono text-xs">Reading file…</span>
      </div>
    );
  }
  if (error) {
    return (
      <div className="flex flex-col items-center justify-center h-full gap-2 px-6 text-center">
        <AlertCircle className="h-6 w-6 text-muted-foreground/40" />
        <p className="font-mono text-xs text-muted-foreground">{error}</p>
      </div>
    );
  }
  if (!preview) {
    return (
      <div className="flex flex-col items-center justify-center h-full gap-2 px-6 text-center">
        <Eye className="h-8 w-8 text-muted-foreground/30" />
        <p className="font-mono text-xs text-muted-foreground">
          Select a previewable file
        </p>
        <p className="font-mono text-[10px] text-muted-foreground/60">
          HTML · CSS · JS · JSON · XML · SVG · MD
        </p>
      </div>
    );
  }
  return (
    <div className="flex flex-col h-full">
      <div className="flex items-center justify-between gap-2 px-3 py-2 border-b border-border bg-muted/30">
        <div className="flex items-center gap-2 min-w-0">
          <FileText className="h-3.5 w-3.5 text-accent shrink-0" />
          <span className="font-mono text-xs truncate">{preview.path}</span>
        </div>
        <div className="flex items-center gap-2 shrink-0">
          <Badge variant="outline" className="font-mono text-[10px] h-5">
            {preview.ext.toUpperCase()}
          </Badge>
          <span className="font-mono text-[10px] text-muted-foreground tabular-nums">
            {formatBytes(preview.size)}
          </span>
        </div>
      </div>
      <ScrollArea className="yescode-scroll flex-1">
        <div className="bg-zinc-950 dark:bg-zinc-950 min-h-full">
          <HighlightedCode
            code={preview.content}
            ext={preview.ext}
            truncated={preview.truncated}
            truncatedAt={preview.truncatedAt}
          />
        </div>
      </ScrollArea>
    </div>
  );
}

export function ZipPreviewDialog() {
  const jobId = useJobStore((s) => s.jobId);
  const status = useJobStore((s) => s.status);
  const [open, setOpen] = useState(false);
  const [data, setData] = useState<ContentsResponse | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [selectedFile, setSelectedFile] = useState<TreeNode | null>(null);
  const [preview, setPreview] = useState<FilePreview | null>(null);
  const [previewLoading, setPreviewLoading] = useState(false);
  const [previewError, setPreviewError] = useState<string | null>(null);

  useEffect(() => {
    if (!open || !jobId || status !== "completed") return;
    let cancelled = false;
    void (async () => {
      setLoading(true);
      setError(null);
      try {
        const r = await fetch(`/api/export/${jobId}/contents`);
        if (!r.ok) throw new Error(`HTTP ${r.status}`);
        const d = (await r.json()) as ContentsResponse;
        if (!cancelled) {
          setData(d);
          setLoading(false);
        }
      } catch (err) {
        if (!cancelled) {
          setError(err instanceof Error ? err.message : String(err));
          setLoading(false);
        }
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [open, jobId, status]);

  // Load file preview when a file is selected
  const onSelectFile = (node: TreeNode) => {
    setSelectedFile(node);
    setPreview(null);
    setPreviewError(null);
    if (!jobId) return;
    void (async () => {
      setPreviewLoading(true);
      try {
        const encoded = encodeURIComponent(node.path);
        const r = await fetch(`/api/export/${jobId}/contents/${encoded}`);
        if (!r.ok) {
          const e = await r.json().catch(() => ({ error: `HTTP ${r.status}` }));
          throw new Error(e.error || `HTTP ${r.status}`);
        }
        const p = (await r.json()) as FilePreview;
        setPreview(p);
      } catch (err) {
        setPreviewError(err instanceof Error ? err.message : String(err));
      } finally {
        setPreviewLoading(false);
      }
    })();
  };

  // Reset selection when dialog closes
  useEffect(() => {
    if (!open) {
      setSelectedFile(null);
      setPreview(null);
      setPreviewError(null);
    }
  }, [open]);

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" className="h-12 px-5 font-mono">
          <FileArchive className="h-4 w-4 mr-2" />
          Preview ZIP
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-4xl max-h-[85vh] flex flex-col gap-0 p-0">
        <DialogHeader className="px-5 pt-5 pb-3 border-b border-border">
          <DialogTitle className="font-mono text-sm flex items-center gap-2">
            <FileArchive className="h-4 w-4 text-accent" />
            ZIP contents
            {selectedFile && (
              <span className="text-muted-foreground font-normal">
                · {selectedFile.name}
              </span>
            )}
          </DialogTitle>
          <DialogDescription className="font-mono text-xs">
            {data
              ? `${data.zipName} · ${data.totalFiles} files · ${formatBytes(data.totalSize)}`
              : "Loading archive manifest…"}
          </DialogDescription>
        </DialogHeader>
        <div className="flex-1 flex min-h-0">
          {/* Tree panel (left) */}
          <div className="w-1/2 border-r border-border flex flex-col min-h-0">
            <div className="px-3 py-1.5 border-b border-border bg-muted/20">
              <span className="font-mono text-[10px] uppercase tracking-wider text-muted-foreground">
                Files
              </span>
            </div>
            <ScrollArea className="yescode-scroll flex-1 max-h-[60vh] px-1 py-1">
              {loading && (
                <div className="flex items-center justify-center py-12 text-muted-foreground">
                  <Loader2 className="h-5 w-5 animate-spin mr-2" />
                  <span className="font-mono text-xs">Reading archive…</span>
                </div>
              )}
              {error && (
                <div className="px-4 py-8 text-center">
                  <p className="font-mono text-xs text-destructive">{error}</p>
                </div>
              )}
              {data && !loading && (
                <div className="py-1">
                  {data.tree.map((node, idx) => (
                    <TreeRow
                      key={`${node.path}-${idx}`}
                      node={node}
                      depth={0}
                      selectedPath={selectedFile?.path ?? null}
                      onSelect={onSelectFile}
                    />
                  ))}
                </div>
              )}
            </ScrollArea>
          </div>
          {/* Preview panel (right) */}
          <div className="w-1/2 flex flex-col min-h-0">
            <div className="px-3 py-1.5 border-b border-border bg-muted/20 flex items-center justify-between">
              <span className="font-mono text-[10px] uppercase tracking-wider text-muted-foreground">
                Preview
              </span>
              {preview && (
                <span className="font-mono text-[10px] text-muted-foreground">
                  {preview.mime}
                </span>
              )}
            </div>
            <div className="flex-1 min-h-0 max-h-[60vh]">
              <FilePreviewPanel
                preview={preview}
                loading={previewLoading}
                error={previewError}
              />
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
