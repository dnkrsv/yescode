"use client";

import { useState, useCallback, useRef } from "react";
import { useRouter } from "next/navigation";
import { useJobStore } from "@/stores/job-store";
import { useSSEProgress } from "@/hooks/use-sse-progress";
import { useKeyboardShortcut } from "@/hooks/use-keyboard-shortcut";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { AdvancedOptions } from "./advanced-options";
import { ExportPresets } from "./export-presets";
import { Loader2, Sparkles, AlertCircle, Terminal } from "lucide-react";
import { toast } from "sonner";

const EXAMPLE_URLS = [
  "https://framer.com",
  "https://www.framer.com",
  "https://www.example.com",
];

export function ExportForm() {
  const router = useRouter();
  const [localUrl, setLocalUrl] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const formRef = useRef<HTMLFormElement | null>(null);
  const startJob = useJobStore((s) => s.startJob);
  const reset = useJobStore((s) => s.reset);
  const options = useJobStore((s) => s.options);
  const jobId = useJobStore((s) => s.jobId);
  const status = useJobStore((s) => s.status);

  useSSEProgress(jobId);

  // Cmd/Ctrl+Enter submits the form from anywhere (including inside the input)
  useKeyboardShortcut({
    combo: "mod+enter",
    enabled: status !== "running" && !submitting,
    allowInInput: true,
    handler: () => {
      formRef.current?.requestSubmit();
    },
  });

  const onSubmit = useCallback(
    async (e: React.FormEvent) => {
      e.preventDefault();
      const url = localUrl.trim();
      if (!url) {
        toast.error("Please enter a target URL.");
        return;
      }
      let parsed: URL;
      try {
        parsed = new URL(url);
        if (parsed.protocol !== "https:" && parsed.protocol !== "http:") {
          throw new Error("Protocol must be http or https");
        }
      } catch {
        toast.error("Invalid URL — must include http:// or https://");
        return;
      }
      setSubmitting(true);
      reset();
      try {
        const res = await fetch("/api/export", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ url: parsed.href, options }),
        });
        if (!res.ok) {
          const err = await res.json().catch(() => ({ error: "Request failed" }));
          throw new Error(err.error || `HTTP ${res.status}`);
        }
        const data = (await res.json()) as { jobId: string };
        startJob(data.jobId, parsed.href, options);
        toast.success("Export job queued", {
          description: `Job ${data.jobId.slice(0, 8)} started`,
        });
        router.push(`#job-${data.jobId.slice(0, 8)}`);
      } catch (err) {
        const msg = err instanceof Error ? err.message : String(err);
        toast.error("Failed to start export", { description: msg });
      } finally {
        setSubmitting(false);
      }
    },
    [localUrl, options, reset, startJob, router],
  );

  const isWorking = status === "running" || submitting;

  return (
    <form ref={formRef} onSubmit={onSubmit} className="w-full max-w-3xl mx-auto">
      <div className="flex flex-col sm:flex-row gap-3 items-stretch">
        <div className="relative flex-1">
          <Terminal className="absolute left-4 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground pointer-events-none" />
          <Input
            type="url"
            inputMode="url"
            autoFocus
            autoComplete="url"
            spellCheck={false}
            placeholder="https://your-site.framer.website"
            value={localUrl}
            onChange={(e) => setLocalUrl(e.target.value)}
            disabled={isWorking}
            className="h-14 pl-11 pr-4 text-base font-mono bg-card border-2 border-border focus-visible:border-accent focus-visible:ring-0 shadow-sm rounded-xl"
            aria-label="Target Framer URL"
          />
        </div>
        <Button
          type="submit"
          disabled={isWorking}
          className="h-14 px-7 text-base font-semibold rounded-xl shadow-sm bg-primary hover:bg-primary/90 transition-all hover:shadow-md"
        >
          {submitting ? (
            <>
              <Loader2 className="h-5 w-5 mr-2 animate-spin" />
              Queuing…
            </>
          ) : isWorking ? (
            <>
              <Loader2 className="h-5 w-5 mr-2 animate-spin" />
              Exporting…
            </>
          ) : (
            <>
              <Sparkles className="h-5 w-5 mr-2" />
              Export Site
            </>
          )}
        </Button>
        <AdvancedOptions disabled={isWorking} />
      </div>
      <div className="mt-3">
        <ExportPresets disabled={isWorking} />
      </div>
      <div className="mt-3 flex flex-wrap items-center gap-2 text-xs text-muted-foreground font-mono">
        <span className="text-muted-foreground/70">try:</span>
        {EXAMPLE_URLS.map((u) => (
          <button
            key={u}
            type="button"
            onClick={() => setLocalUrl(u)}
            disabled={isWorking}
            className="px-2 py-1 rounded-md border border-border bg-card hover:border-accent hover:text-accent-foreground transition-colors disabled:opacity-50"
          >
            {u.replace(/^https?:\/\//, "")}
          </button>
        ))}
      </div>
      {status === "failed" && (
        <div className="mt-4 flex items-start gap-3 rounded-lg border border-destructive/40 bg-destructive/5 px-4 py-3 text-sm">
          <AlertCircle className="h-5 w-5 text-destructive shrink-0 mt-0.5" />
          <div>
            <p className="font-semibold text-destructive">Export failed</p>
            <p className="text-muted-foreground font-mono text-xs mt-1">
              {useJobStore.getState().error}
            </p>
          </div>
        </div>
      )}
    </form>
  );
}
