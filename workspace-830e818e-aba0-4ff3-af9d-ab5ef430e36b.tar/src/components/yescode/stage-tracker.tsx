"use client";

import { useState, useEffect, useCallback } from "react";
import {
  PIPELINE_STAGES,
  STAGE_DESCRIPTIONS,
  stageIndex,
  type PipelineStageName,
} from "@/lib/exporter/pipeline";
import { useJobStore } from "@/stores/job-store";
import { cn } from "@/lib/utils";
import { motion } from "framer-motion";
import {
  CheckCircle2,
  CircleDot,
  Loader2,
  AlertTriangle,
  XCircle,
} from "lucide-react";
import { toast } from "sonner";

interface StageNodeProps {
  stage: PipelineStageName;
  state: "done" | "active" | "pending" | "failed";
  index: number;
  durationMs?: number;
}

function formatDuration(ms?: number): string {
  if (ms == null) return "";
  if (ms < 1000) return `${ms}ms`;
  if (ms < 60000) return `${(ms / 1000).toFixed(2)}s`;
  return `${Math.floor(ms / 60000)}m ${Math.floor((ms % 60000) / 1000)}s`;
}

function StageNode({ stage, state, index, durationMs }: StageNodeProps) {
  const num = String(index + 1).padStart(2, "0");
  // Pick icon inline to satisfy react-hooks/static-components rule
  let iconEl: React.ReactNode;
  if (state === "done") {
    iconEl = <CheckCircle2 className={cn("h-4 w-4 mt-0.5 shrink-0 text-accent")} />;
  } else if (state === "active") {
    iconEl = <Loader2 className={cn("h-4 w-4 mt-0.5 shrink-0 text-accent animate-spin")} />;
  } else if (state === "failed") {
    iconEl = <AlertTriangle className={cn("h-4 w-4 mt-0.5 shrink-0 text-destructive")} />;
  } else {
    iconEl = <CircleDot className={cn("h-4 w-4 mt-0.5 shrink-0 text-muted-foreground/50")} />;
  }

  return (
    <li
      className={cn(
        "relative flex items-start gap-3 rounded-lg px-3 py-2 transition-colors",
        state === "active" && "bg-accent/10 border border-accent/30",
        state === "done" && "opacity-80",
        state === "failed" && "bg-destructive/5 border border-destructive/30",
      )}
    >
      <span className="font-mono text-[10px] text-muted-foreground tabular-nums w-5 mt-1">
        {num}
      </span>
      {iconEl}
      <div className="min-w-0 flex-1">
        <div className="flex items-baseline gap-2">
          <span
            className={cn(
              "font-mono text-xs font-semibold uppercase tracking-tight",
              state === "pending"
                ? "text-muted-foreground/60"
                : "text-foreground",
            )}
          >
            {stage}
          </span>
          {durationMs != null && durationMs > 0 && (
            <span className="ml-auto font-mono text-[10px] text-muted-foreground tabular-nums">
              {formatDuration(durationMs)}
            </span>
          )}
        </div>
        <p className="text-[11px] leading-tight text-muted-foreground mt-0.5">
          {STAGE_DESCRIPTIONS[stage]}
        </p>
      </div>
    </li>
  );
}

export function StageTracker() {
  const stage = useJobStore((s) => s.stage);
  const status = useJobStore((s) => s.status);
  const overall = useJobStore((s) => s.overall);
  const jobId = useJobStore((s) => s.jobId);
  const failJob = useJobStore((s) => s.failJob);
  const reset = useJobStore((s) => s.reset);
  const currentIdx = PIPELINE_STAGES.indexOf(stage);
  const failed = status === "failed";

  // Stage duration tracking: record timestamp when each stage becomes active
  const [stageDurations, setStageDurations] = useState<Record<string, number>>({});
  const [stageStartTs, setStageStartTs] = useState<Record<string, number>>({});
  const [cancelling, setCancelling] = useState(false);

  useEffect(() => {
    const now = Date.now();
    setStageStartTs((prev) => {
      if (prev[stage] != null) return prev; // already started
      return { ...prev, [stage]: now };
    });
    // When a stage transitions away from active, record its duration
    // (we detect this by comparing with previous stage)
  }, [stage]);

  // Compute durations for completed stages whenever stage changes
  useEffect(() => {
    if (!stage) return;
    setStageDurations((prev) => {
      const next = { ...prev };
      // For every stage before the current one that has a startTs but no duration,
      // compute duration using the next stage's startTs
      const idx = PIPELINE_STAGES.indexOf(stage);
      for (let i = 0; i < idx; i++) {
        const s = PIPELINE_STAGES[i];
        if (next[s] != null) continue; // already recorded
        const start = stageStartTs[s];
        if (start == null) continue;
        // End = start of the next stage (or now for the latest completed)
        const nextStage = PIPELINE_STAGES[i + 1];
        const end = stageStartTs[nextStage] ?? Date.now();
        next[s] = Math.max(0, end - start);
      }
      return next;
    });
  }, [stage, stageStartTs]);

  const onCancel = useCallback(async () => {
    if (!jobId) return;
    setCancelling(true);
    try {
      const res = await fetch(`/api/export/${jobId}`, { method: "DELETE" });
      if (!res.ok) {
        const err = await res.json().catch(() => ({ error: "Cancel failed" }));
        throw new Error(err.error || `HTTP ${res.status}`);
      }
      failJob("Cancelled by user");
      toast.success("Job cancelled", { description: `Job ${jobId.slice(0, 8)} aborted` });
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err);
      toast.error("Cancel failed", { description: msg });
    } finally {
      setCancelling(false);
    }
  }, [jobId, failJob]);

  const isRunning = status === "running";

  return (
    <div className="w-full">
      {/* Top: overall progress bar + cancel button */}
      <div className="mb-4 flex items-center justify-between gap-4">
        <div>
          <p className="text-[11px] font-mono uppercase tracking-wider text-muted-foreground">
            Pipeline
          </p>
          <p className="font-mono text-2xl font-bold tabular-nums">
            {overall.toFixed(1)}
            <span className="text-muted-foreground text-base">%</span>
          </p>
        </div>
        <div className="text-right">
          <p className="text-[11px] font-mono uppercase tracking-wider text-muted-foreground">
            Stage
          </p>
          <p className="font-mono text-sm font-semibold">
            {stageIndex(stage).toString().padStart(2, "0")}
            <span className="text-muted-foreground">/{PIPELINE_STAGES.length}</span>
          </p>
        </div>
        {isRunning && (
          <button
            type="button"
            onClick={onCancel}
            disabled={cancelling}
            className={cn(
              "inline-flex items-center gap-1.5 h-8 px-3 rounded-md border font-mono text-[11px] uppercase tracking-wider transition-colors",
              cancelling
                ? "border-muted-foreground/30 text-muted-foreground/50 cursor-not-allowed"
                : "border-destructive/40 text-destructive hover:bg-destructive/10",
            )}
            aria-label="Cancel job"
          >
            {cancelling ? (
              <Loader2 className="h-3 w-3 animate-spin" />
            ) : (
              <XCircle className="h-3 w-3" />
            )}
            {cancelling ? "Cancelling…" : "Cancel"}
          </button>
        )}
      </div>
      <div className="h-2 rounded-full bg-secondary overflow-hidden mb-6 relative">
        <motion.div
          className={cn(
            "h-full rounded-full",
            failed ? "bg-destructive" : "bg-accent",
          )}
          initial={{ width: 0 }}
          animate={{ width: `${overall}%` }}
          transition={{ type: "spring", stiffness: 60, damping: 18 }}
        />
        {isRunning && (
          <motion.div
            aria-hidden
            className="absolute inset-y-0 left-0 bg-white/20 rounded-full"
            initial={{ width: "0%" }}
            animate={{ width: `${overall}%` }}
            transition={{ type: "spring", stiffness: 60, damping: 18 }}
          >
            <motion.div
              className="h-full w-12 bg-gradient-to-r from-transparent via-white/40 to-transparent"
              animate={{ x: ["-100%", "400%"] }}
              transition={{ duration: 1.5, repeat: Infinity, ease: "linear" }}
            />
          </motion.div>
        )}
      </div>

      {/* Stage rail: two columns on desktop, single column on mobile */}
      <ul className="grid grid-cols-1 sm:grid-cols-2 gap-1.5">
        {PIPELINE_STAGES.map((s, i) => {
          const state =
            failed && i === currentIdx
              ? "failed"
              : i < currentIdx
                ? "done"
                : i === currentIdx
                  ? status === "completed"
                    ? "done"
                    : "active"
                  : "pending";
          return (
            <StageNode
              key={s}
              stage={s}
              state={state}
              index={i}
              durationMs={state === "done" || state === "failed" ? stageDurations[s] : undefined}
            />
          );
        })}
      </ul>

      {failed && (
        <button
          type="button"
          onClick={reset}
          className="mt-4 w-full inline-flex items-center justify-center gap-2 h-9 rounded-md border border-border bg-card hover:border-accent/40 font-mono text-xs transition-colors"
        >
          <XCircle className="h-3.5 w-3.5" />
          Dismiss & start new
        </button>
      )}
    </div>
  );
}
