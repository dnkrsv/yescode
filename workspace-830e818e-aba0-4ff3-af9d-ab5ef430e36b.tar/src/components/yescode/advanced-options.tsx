"use client";

import { useState } from "react";
import { useJobStore } from "@/stores/job-store";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Slider } from "@/components/ui/slider";
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { Settings2, ChevronDown, RotateCcw, Globe, ShieldOff, Tag } from "lucide-react";
import { DEFAULT_EXPORT_OPTIONS } from "@/lib/exporter/pipeline";
import { cn } from "@/lib/utils";

/**
 * Advanced export options popover: maxPages, maxDepth, customDomain, skipNIT,
 * keepFramerBranding. Lives next to the Export button.
 */
export function AdvancedOptions({ disabled }: { disabled?: boolean }) {
  const options = useJobStore((s) => s.options);
  const setOptions = useJobStore((s) => s.setOptions);
  const [open, setOpen] = useState(false);

  const changedCount =
    (options.maxPages !== DEFAULT_EXPORT_OPTIONS.maxPages ? 1 : 0) +
    (options.maxDepth !== DEFAULT_EXPORT_OPTIONS.maxDepth ? 1 : 0) +
    (options.customDomain ? 1 : 0) +
    (options.skipNIT !== DEFAULT_EXPORT_OPTIONS.skipNIT ? 1 : 0) +
    (options.keepFramerBranding !== DEFAULT_EXPORT_OPTIONS.keepFramerBranding ? 1 : 0);

  const reset = () =>
    setOptions({
      maxPages: DEFAULT_EXPORT_OPTIONS.maxPages,
      maxDepth: DEFAULT_EXPORT_OPTIONS.maxDepth,
      customDomain: undefined,
      skipNIT: DEFAULT_EXPORT_OPTIONS.skipNIT,
      keepFramerBranding: DEFAULT_EXPORT_OPTIONS.keepFramerBranding,
    });

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button
          type="button"
          variant="outline"
          disabled={disabled}
          className={cn(
            "h-14 px-4 rounded-xl border-2 font-mono text-xs uppercase tracking-wider transition-all",
            changedCount > 0
              ? "border-accent/50 bg-accent/10 text-accent hover:bg-accent/15"
              : "border-border bg-card hover:border-accent/30",
          )}
          aria-label="Advanced options"
        >
          <Settings2 className="h-5 w-5" />
          {changedCount > 0 && (
            <span className="ml-1.5 inline-flex items-center justify-center h-5 min-w-5 px-1.5 rounded-full bg-accent text-accent-foreground text-[10px] font-bold">
              {changedCount}
            </span>
          )}
        </Button>
      </PopoverTrigger>
      <PopoverContent
        align="end"
        className="w-80 p-4 shadow-xl border-2"
        sideOffset={8}
      >
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <Settings2 className="h-4 w-4 text-accent" />
            <span className="font-mono text-xs font-semibold uppercase tracking-wider">
              Advanced
            </span>
          </div>
          {changedCount > 0 && (
            <Button
              type="button"
              variant="ghost"
              size="sm"
              onClick={reset}
              className="h-7 px-2 text-[11px] font-mono gap-1"
            >
              <RotateCcw className="h-3 w-3" />
              Reset
            </Button>
          )}
        </div>

        <div className="space-y-5">
          {/* maxPages */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <Label className="text-xs font-mono flex items-center gap-1.5">
                <Globe className="h-3 w-3 text-muted-foreground" />
                Max pages
              </Label>
              <span className="font-mono text-xs tabular-nums text-accent font-semibold">
                {options.maxPages}
              </span>
            </div>
            <Slider
              value={[options.maxPages ?? DEFAULT_EXPORT_OPTIONS.maxPages]}
              onValueChange={([v]) => setOptions({ maxPages: v })}
              min={1}
              max={500}
              step={1}
              disabled={disabled}
            />
            <p className="text-[10px] text-muted-foreground font-mono">
              Crawl ceiling (hard cap: 1000)
            </p>
          </div>

          {/* maxDepth */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <Label className="text-xs font-mono flex items-center gap-1.5">
                <Globe className="h-3 w-3 text-muted-foreground" />
                Max depth
              </Label>
              <span className="font-mono text-xs tabular-nums text-accent font-semibold">
                {options.maxDepth}
              </span>
            </div>
            <Slider
              value={[options.maxDepth ?? DEFAULT_EXPORT_OPTIONS.maxDepth]}
              onValueChange={([v]) => setOptions({ maxDepth: v })}
              min={1}
              max={10}
              step={1}
              disabled={disabled}
            />
            <p className="text-[10px] text-muted-foreground font-mono">
              BFS depth from seed (cap: 10)
            </p>
          </div>

          {/* customDomain */}
          <div className="space-y-1.5">
            <Label className="text-xs font-mono flex items-center gap-1.5">
              <Globe className="h-3 w-3 text-muted-foreground" />
              Custom domain
            </Label>
            <Input
              type="url"
              placeholder="https://my-prod.com"
              value={options.customDomain ?? ""}
              onChange={(e) =>
                setOptions({
                  customDomain: e.target.value || undefined,
                })
              }
              disabled={disabled}
              className="h-9 font-mono text-xs"
            />
            <p className="text-[10px] text-muted-foreground font-mono">
              Used for canonical & sitemap URLs
            </p>
          </div>

          {/* Toggles */}
          <div className="space-y-3 pt-2 border-t border-border">
            <ToggleRow
              icon={ShieldOff}
              label="Skip NIT"
              description="Faster, unverified export"
              checked={!!options.skipNIT}
              onCheckedChange={(v) => setOptions({ skipNIT: v })}
              disabled={disabled}
            />
            <ToggleRow
              icon={Tag}
              label="Keep Framer branding"
              description="Preserve badge & telemetry"
              checked={!!options.keepFramerBranding}
              onCheckedChange={(v) => setOptions({ keepFramerBranding: v })}
              disabled={disabled}
            />
          </div>
        </div>
      </PopoverContent>
    </Popover>
  );
}

function ToggleRow({
  icon: Icon,
  label,
  description,
  checked,
  onCheckedChange,
  disabled,
}: {
  icon: typeof Globe;
  label: string;
  description: string;
  checked: boolean;
  onCheckedChange: (v: boolean) => void;
  disabled?: boolean;
}) {
  return (
    <div className="flex items-center justify-between gap-3">
      <div className="flex items-start gap-2 min-w-0">
        <Icon className="h-3.5 w-3.5 text-muted-foreground mt-0.5 shrink-0" />
        <div className="min-w-0">
          <p className="text-xs font-mono font-medium leading-tight">{label}</p>
          <p className="text-[10px] text-muted-foreground font-mono leading-tight">
            {description}
          </p>
        </div>
      </div>
      <Switch
        checked={checked}
        onCheckedChange={onCheckedChange}
        disabled={disabled}
        className="data-[state=checked]:bg-accent"
      />
    </div>
  );
}

void Collapsible;
void CollapsibleContent;
void CollapsibleTrigger;
void ChevronDown;
