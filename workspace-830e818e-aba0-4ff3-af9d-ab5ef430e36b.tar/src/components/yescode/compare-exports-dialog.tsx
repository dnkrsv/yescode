"use client";

import { useEffect, useState, useCallback } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  GitCompare,
  Plus,
  Minus,
  FileWarning,
  Check,
  Loader2,
  ArrowRight,
} from "lucide-react";
import { motion } from "framer-motion";
import { cn } from "@/lib/utils";
import { useJobStore, type JobHistoryEntry } from "@/stores/job-store";
import { toast } from "sonner";

interface CompareResult {
  jobA: { jobId: string; targetUrl: string; zipName: string };
  jobB: { jobId: string; targetUrl: string; zipName: string };
  summary: { added: number; removed: number; changed: number; unchanged: number; total: number };
  added: Array<{ path: string; size: number }>;
  removed: Array<{ path: string; size: number }>;
  changed: Array<{ path: string; sizeA: number; sizeB: number }>;
  unchanged: string[];
}

function formatBytes(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
}

function hostOf(url: string): string {
  try {
    return new URL(url).hostname.replace(/^www\./, "");
  } catch {
    return url.slice(0, 30);
  }
}

/**
 * YesCode — Compare exports dialog.
 *
 * Lets the user pick two completed jobs from history and see a file-level
 * diff: added (in B not A), removed (in A not B), changed (different
 * content), unchanged (identical).
 */
export function CompareExportsDialog() {
  const history = useJobStore((s) => s.history);
  const [open, setOpen] = useState(false);
  const [jobA, setJobA] = useState<string | null>(null);
  const [jobB, setJobB] = useState<string | null>(null);
  const [result, setResult] = useState<CompareResult | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const completedJobs = history.filter((j) => j.status === "completed");

  const onCompare = useCallback(async () => {
    if (!jobA || !jobB) {
      toast.error("Select two jobs to compare");
      return;
    }
    if (jobA === jobB) {
      toast.error("Select two different jobs");
      return;
    }
    setLoading(true);
    setError(null);
    setResult(null);
    try {
      const res = await fetch(`/api/compare?jobA=${jobA}&jobB=${jobB}`);
      if (!res.ok) {
        const err = await res.json().catch(() => ({ error: `HTTP ${res.status}` }));
        throw new Error(err.error || `HTTP ${res.status}`);
      }
      const data = (await res.json()) as CompareResult;
      setResult(data);
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err);
      setError(msg);
      toast.error("Compare failed", { description: msg });
    } finally {
      setLoading(false);
    }
  }, [jobA, jobB]);

  // Reset state when dialog closes
  useEffect(() => {
    if (!open) {
      setJobA(null);
      setJobB(null);
      setResult(null);
      setError(null);
    }
  }, [open]);

  if (completedJobs.length < 2) return null;

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button
          variant="ghost"
          size="sm"
          className="h-7 px-2 text-[11px] font-mono gap-1"
        >
          <GitCompare className="h-3 w-3" />
          Compare
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-3xl max-h-[85vh] flex flex-col gap-0 p-0">
        <DialogHeader className="px-5 pt-5 pb-3 border-b border-border">
          <DialogTitle className="font-mono text-sm flex items-center gap-2">
            <GitCompare className="h-4 w-4 text-accent" />
            Compare exports
          </DialogTitle>
          <DialogDescription className="font-mono text-xs">
            Select two completed jobs to see a file-level diff
          </DialogDescription>
        </DialogHeader>

        <ScrollArea className="yescode-scroll flex-1 max-h-[70vh]">
          <div className="p-5 space-y-5">
            {/* Job selectors */}
            <div className="grid grid-cols-1 sm:grid-cols-[1fr_auto_1fr] gap-3 items-end">
              <JobSelector
                label="Job A (baseline)"
                jobs={completedJobs}
                selected={jobA}
                onSelect={setJobA}
                otherSelected={jobB}
              />
              <div className="flex items-center justify-center pb-2">
                <ArrowRight className="h-4 w-4 text-muted-foreground" />
              </div>
              <JobSelector
                label="Job B (new)"
                jobs={completedJobs}
                selected={jobB}
                onSelect={setJobB}
                otherSelected={jobA}
              />
            </div>

            <div className="flex items-center gap-2">
              <Button
                type="button"
                onClick={onCompare}
                disabled={!jobA || !jobB || loading || jobA === jobB}
                className="font-mono text-xs h-9"
              >
                {loading ? (
                  <>
                    <Loader2 className="h-3.5 w-3.5 mr-1.5 animate-spin" />
                    Comparing…
                  </>
                ) : (
                  <>
                    <GitCompare className="h-3.5 w-3.5 mr-1.5" />
                    Compare
                  </>
                )}
              </Button>
              {jobA && jobB && jobA === jobB && (
                <span className="font-mono text-[10px] text-destructive">
                  Select two different jobs
                </span>
              )}
            </div>

            {error && (
              <div className="px-3 py-2 rounded-md border border-destructive/40 bg-destructive/5 font-mono text-xs text-destructive">
                {error}
              </div>
            )}

            {result && (
              <CompareResultView result={result} />
            )}
          </div>
        </ScrollArea>
      </DialogContent>
    </Dialog>
  );
}

function JobSelector({
  label,
  jobs,
  selected,
  onSelect,
  otherSelected,
}: {
  label: string;
  jobs: JobHistoryEntry[];
  selected: string | null;
  onSelect: (id: string) => void;
  otherSelected: string | null;
}) {
  return (
    <div className="space-y-1.5">
      <label className="text-[10px] font-mono uppercase tracking-wider text-muted-foreground">
        {label}
      </label>
      <div className="space-y-1 max-h-48 overflow-y-auto yescode-scroll rounded-md border border-border p-1.5">
        {jobs.map((job) => {
          const isSel = selected === job.jobId;
          const isOther = otherSelected === job.jobId;
          return (
            <button
              key={job.jobId}
              type="button"
              onClick={() => onSelect(job.jobId)}
              className={cn(
                "w-full text-left px-2 py-1.5 rounded text-xs font-mono transition-colors flex items-center gap-2",
                isSel
                  ? "bg-accent/15 border border-accent/40 text-accent"
                  : isOther
                    ? "opacity-30 cursor-not-allowed"
                    : "hover:bg-muted/50 border border-transparent",
              )}
              disabled={isOther}
            >
              <span className="truncate flex-1">{hostOf(job.targetUrl)}</span>
              <span className="text-[10px] text-muted-foreground tabular-nums shrink-0">
                {job.outputZipSizeBytes ? formatBytes(job.outputZipSizeBytes) : "—"}
              </span>
              {isSel && <Check className="h-3 w-3 text-accent shrink-0" />}
            </button>
          );
        })}
      </div>
    </div>
  );
}

function CompareResultView({ result }: { result: CompareResult }) {
  const { summary, added, removed, changed } = result;
  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
      className="space-y-4"
    >
      {/* Summary tiles */}
      <div className="grid grid-cols-4 gap-2">
        <DiffTile icon={Plus} label="Added" count={summary.added} color="emerald" />
        <DiffTile icon={Minus} label="Removed" count={summary.removed} color="destructive" />
        <DiffTile icon={FileWarning} label="Changed" count={summary.changed} color="amber" />
        <DiffTile icon={Check} label="Unchanged" count={summary.unchanged} color="muted" />
      </div>

      {/* File lists */}
      {added.length > 0 && (
        <FileListSection
          title="Added"
          icon={Plus}
          color="emerald"
          files={added.map((f) => ({ path: f.path, detail: formatBytes(f.size) }))}
        />
      )}
      {removed.length > 0 && (
        <FileListSection
          title="Removed"
          icon={Minus}
          color="destructive"
          files={removed.map((f) => ({ path: f.path, detail: formatBytes(f.size) }))}
        />
      )}
      {changed.length > 0 && (
        <FileListSection
          title="Changed"
          icon={FileWarning}
          color="amber"
          files={changed.map((f) => ({
            path: f.path,
            detail: `${formatBytes(f.sizeA)} → ${formatBytes(f.sizeB)}`,
          }))}
        />
      )}
      {summary.unchanged > 0 && (
        <div className="flex items-center gap-2 px-3 py-2 rounded-md bg-muted/30 font-mono text-xs text-muted-foreground">
          <Check className="h-3.5 w-3.5 text-emerald-500" />
          {summary.unchanged} file{summary.unchanged === 1 ? "" : "s"} unchanged
        </div>
      )}
    </motion.div>
  );
}

function DiffTile({
  icon: Icon,
  label,
  count,
  color,
}: {
  icon: React.ElementType;
  label: string;
  count: number;
  color: "emerald" | "destructive" | "amber" | "muted";
}) {
  const colorMap = {
    emerald: "border-emerald-500/30 bg-emerald-500/5 text-emerald-600 dark:text-emerald-400",
    destructive: "border-destructive/30 bg-destructive/5 text-destructive",
    amber: "border-amber-500/30 bg-amber-500/5 text-amber-600 dark:text-amber-400",
    muted: "border-border bg-muted/30 text-muted-foreground",
  };
  return (
    <div className={cn("rounded-lg border px-2 py-2 flex flex-col gap-1 items-center text-center", colorMap[color])}>
      <Icon className="h-3.5 w-3.5" />
      <span className="font-mono text-lg font-bold tabular-nums leading-tight">{count}</span>
      <span className="font-mono text-[9px] uppercase tracking-wider">{label}</span>
    </div>
  );
}

function FileListSection({
  title,
  icon: Icon,
  color,
  files,
}: {
  title: string;
  icon: React.ElementType;
  color: "emerald" | "destructive" | "amber";
  files: Array<{ path: string; detail: string }>;
}) {
  const colorMap = {
    emerald: "text-emerald-600 dark:text-emerald-400",
    destructive: "text-destructive",
    amber: "text-amber-600 dark:text-amber-400",
  };
  return (
    <div>
      <div className="flex items-center gap-2 mb-2">
        <Icon className={cn("h-3.5 w-3.5", colorMap[color])} />
        <span className="font-mono text-xs font-semibold uppercase tracking-wider">{title}</span>
        <Badge variant="outline" className="font-mono text-[10px] h-5">{files.length}</Badge>
      </div>
      <div className="space-y-0.5 max-h-40 overflow-y-auto yescode-scroll">
        {files.map((f) => (
          <div
            key={f.path}
            className="flex items-center gap-2 px-2 py-1 rounded hover:bg-muted/30 font-mono text-[11px]"
          >
            <span className="truncate flex-1 text-foreground/80">{f.path}</span>
            <span className="text-[10px] text-muted-foreground tabular-nums shrink-0">{f.detail}</span>
          </div>
        ))}
      </div>
    </div>
  );
}
