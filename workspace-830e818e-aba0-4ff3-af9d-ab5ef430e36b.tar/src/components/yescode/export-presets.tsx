"use client";

import { useJobStore } from "@/stores/job-store";
import { DEFAULT_EXPORT_OPTIONS, type ExportOptions } from "@/lib/exporter/pipeline";
import { cn } from "@/lib/utils";
import { motion } from "framer-motion";
import { Zap, Microscope, SlidersHorizontal, Check } from "lucide-react";

type PresetId = "quick" | "thorough" | "custom";

interface Preset {
  id: PresetId;
  label: string;
  icon: React.ElementType;
  description: string;
  options: Partial<ExportOptions>;
}

const PRESETS: Preset[] = [
  {
    id: "quick",
    label: "Quick",
    icon: Zap,
    description: "Max 10 pages · depth 3 · skip NIT",
    options: {
      maxPages: 10,
      maxDepth: 3,
      skipNIT: true,
      keepFramerBranding: false,
    },
  },
  {
    id: "thorough",
    label: "Thorough",
    icon: Microscope,
    description: "Max 250 pages · depth 10 · full NIT",
    options: {
      maxPages: 250,
      maxDepth: 10,
      skipNIT: false,
      keepFramerBranding: false,
    },
  },
  {
    id: "custom",
    label: "Custom",
    icon: SlidersHorizontal,
    description: "Use advanced options →",
    options: {},
  },
];

/**
 * Detect which preset matches the current options (or "custom" if none match).
 */
function detectPreset(options: ExportOptions): PresetId {
  for (const p of PRESETS) {
    if (p.id === "custom") continue;
    const opts = p.options;
    if (
      (opts.maxPages === undefined || opts.maxPages === options.maxPages) &&
      (opts.maxDepth === undefined || opts.maxDepth === options.maxDepth) &&
      (opts.skipNIT === undefined || opts.skipNIT === options.skipNIT) &&
      (opts.keepFramerBranding === undefined || opts.keepFramerBranding === options.keepFramerBranding)
    ) {
      // Also check customDomain isn't set (presets don't set it)
      if (!options.customDomain) return p.id;
    }
  }
  return "custom";
}

/**
 * YesCode — export preset selector. Shows Quick / Thorough / Custom buttons.
 * Clicking a preset applies its options to the store. "Custom" is auto-
 * selected when the user manually changes advanced options.
 */
export function ExportPresets({ disabled }: { disabled?: boolean }) {
  const options = useJobStore((s) => s.options);
  const setOptions = useJobStore((s) => s.setOptions);
  const activePreset = detectPreset(options);

  const applyPreset = (preset: Preset) => {
    if (preset.id === "custom") return; // custom = keep current options
    setOptions({
      maxPages: preset.options.maxPages ?? DEFAULT_EXPORT_OPTIONS.maxPages,
      maxDepth: preset.options.maxDepth ?? DEFAULT_EXPORT_OPTIONS.maxDepth,
      skipNIT: preset.options.skipNIT ?? DEFAULT_EXPORT_OPTIONS.skipNIT,
      keepFramerBranding: preset.options.keepFramerBranding ?? DEFAULT_EXPORT_OPTIONS.keepFramerBranding,
      customDomain: undefined, // presets clear custom domain
    });
  };

  return (
    <div className="flex items-center gap-2 w-full">
      <span className="text-[11px] font-mono uppercase tracking-wider text-muted-foreground shrink-0 hidden sm:inline">
        Preset
      </span>
      <div className="flex gap-1.5 flex-1 sm:flex-none">
        {PRESETS.map((preset) => {
          const isActive = activePreset === preset.id;
          const Icon = preset.icon;
          return (
            <motion.button
              key={preset.id}
              type="button"
              whileHover={disabled ? undefined : { y: -1 }}
              whileTap={disabled ? undefined : { scale: 0.97 }}
              onClick={() => applyPreset(preset)}
              disabled={disabled && preset.id !== "custom"}
              className={cn(
                "group relative inline-flex items-center gap-1.5 rounded-md border px-2.5 py-1.5 font-mono text-[11px] transition-all",
                isActive
                  ? "border-accent bg-accent/10 text-accent"
                  : "border-border bg-card/60 text-muted-foreground hover:border-accent/40 hover:text-foreground",
                disabled && preset.id !== "custom" && "opacity-50 cursor-not-allowed",
              )}
              title={preset.description}
            >
              <Icon className="h-3 w-3" />
              {preset.label}
              {isActive && (
                <motion.span
                  layoutId="preset-active"
                  className="absolute -top-1 -right-1 h-3 w-3 rounded-full bg-accent flex items-center justify-center"
                  transition={{ type: "spring", stiffness: 300, damping: 20 }}
                >
                  <Check className="h-2 w-2 text-accent-foreground" strokeWidth={3} />
                </motion.span>
              )}
            </motion.button>
          );
        })}
      </div>
    </div>
  );
}
