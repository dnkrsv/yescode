"use client";

import { motion } from "framer-motion";
import { Badge } from "@/components/ui/badge";
import { Boxes, Terminal, ShieldCheck } from "lucide-react";
import { ThemeToggle } from "./theme-toggle";
import { LiveStatsBar } from "./live-stats-bar";
import { StatsDashboard } from "./stats-dashboard";

export function Hero() {
  return (
    <header className="relative overflow-hidden yescode-grid-bg">
      {/* Ambient glow — animated aurora that drifts slowly */}
      <motion.div
        aria-hidden
        className="absolute -top-40 left-1/2 -translate-x-1/2 h-72 w-[60rem] rounded-full bg-accent/15 blur-3xl pointer-events-none"
        animate={{
          opacity: [0.5, 0.8, 0.5],
          scale: [1, 1.05, 1],
        }}
        transition={{ duration: 8, repeat: Infinity, ease: "easeInOut" }}
      />
      {/* Secondary glow — bottom-right warm */}
      <div
        aria-hidden
        className="absolute top-20 right-0 h-64 w-64 rounded-full bg-accent/10 blur-3xl pointer-events-none"
      />
      {/* Top-right controls — fixed, persist on scroll */}
      <div className="absolute top-4 right-4 sm:top-6 sm:right-6 z-30 flex items-center gap-2">
        <StatsDashboard />
        <ThemeToggle />
      </div>

      <div className="relative mx-auto max-w-6xl px-4 sm:px-6 pt-16 sm:pt-20 pb-10 text-center">
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="flex justify-center mb-5"
        >
          <Badge
            variant="outline"
            className="font-mono text-[11px] uppercase tracking-wider border-accent/40 bg-accent/10 text-accent-foreground gap-1.5 px-3 py-1"
          >
            <span className="h-1.5 w-1.5 rounded-full bg-accent yescode-pulse" />
            v1.0 · Network-Independent
          </Badge>
        </motion.div>

        <motion.h1
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.05 }}
          className="font-sans font-extrabold tracking-tight text-5xl sm:text-7xl md:text-8xl leading-[0.95]"
        >
          <span className="block">Yes</span>
          <span className="relative block">
            <span className="bg-gradient-to-br from-accent via-accent to-foreground bg-clip-text text-transparent">
              Code
            </span>
            <motion.span
              aria-hidden
              className="absolute -bottom-1 left-1/2 -translate-x-1/2 h-[3px] w-24 rounded-full bg-gradient-to-r from-transparent via-accent to-transparent"
              initial={{ opacity: 0, scaleX: 0 }}
              animate={{ opacity: 1, scaleX: 1 }}
              transition={{ duration: 0.8, delay: 0.4 }}
            />
            {/* Blinking terminal cursor after "Code" */}
            <motion.span
              aria-hidden
              className="inline-block w-[0.5em] h-[0.8em] ml-2 bg-accent yescode-cursor align-text-bottom"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.9 }}
              style={{ verticalAlign: "baseline" }}
            />
          </span>
        </motion.h1>

        <motion.p
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.15 }}
          className="mx-auto mt-6 max-w-2xl text-base sm:text-lg text-muted-foreground leading-relaxed font-sans"
        >
          The ultimate standalone static site exporter.{" "}
          <span className="text-foreground font-medium">
            Preserve your design, liberate your code.
          </span>{" "}
          Convert any published Framer website into a 100% self-contained
          archive — no Framer infrastructure required.
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.25 }}
          className="mt-8 flex flex-wrap items-center justify-center gap-3 text-xs font-mono"
        >
          <span className="inline-flex items-center gap-1.5 rounded-full border border-border bg-card px-3 py-1.5 hover:border-accent/40 transition-colors">
            <Boxes className="h-3.5 w-3.5 text-accent" />
            14-stage pipeline
          </span>
          <span className="inline-flex items-center gap-1.5 rounded-full border border-border bg-card px-3 py-1.5 hover:border-accent/40 transition-colors">
            <Terminal className="h-3.5 w-3.5 text-accent" />
            AST-rewritten JS/CSS/HTML
          </span>
          <span className="inline-flex items-center gap-1.5 rounded-full border border-border bg-card px-3 py-1.5 hover:border-accent/40 transition-colors">
            <ShieldCheck className="h-3.5 w-3.5 text-accent" />
            NIT-gated validation
          </span>
        </motion.div>

        <LiveStatsBar />
      </div>
    </header>
  );
}
