"use client";

import "sonner/dist/styles.css";
import { Toaster as Sonner, ToasterProps } from "sonner";

/**
 * Sonner toaster — themed via next-themes. Renders at the bottom-right with
 * rich colors so success/error toasts are visually distinct. Mounted inside
 * <ThemeProvider> in the root layout.
 *
 * Note: we intentionally avoid calling useTheme() here to prevent any
 * hydration mismatch — sonner reads the resolved theme from the <html>
 * class attribute at runtime.
 */
const Toaster = ({ ...props }: ToasterProps) => {
  return (
    <Sonner
      theme="dark"
      className="toaster group"
      style={
        {
          "--normal-bg": "var(--popover)",
          "--normal-text": "var(--popover-foreground)",
          "--normal-border": "var(--border)",
          "--success-bg": "var(--popover)",
          "--success-text": "var(--popover-foreground)",
          "--success-border": "var(--accent)",
          "--error-bg": "var(--popover)",
          "--error-text": "var(--popover-foreground)",
          "--error-border": "var(--destructive)",
        } as React.CSSProperties
      }
      {...props}
    />
  );
};

export { Toaster };
