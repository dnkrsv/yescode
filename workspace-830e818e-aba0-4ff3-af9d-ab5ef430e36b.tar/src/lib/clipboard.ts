/**
 * YesCode — clipboard utility with fallback for non-secure contexts.
 *
 * The modern Clipboard API (`navigator.clipboard.writeText`) requires a
 * secure context (HTTPS or localhost). In headless browsers or HTTP
 * deployments it throws "Clipboard not available". This module falls back
 * to the legacy `document.execCommand('copy')` approach with a hidden
 * textarea, which works in all contexts.
 */

/**
 * Copy text to the clipboard. Tries the async Clipboard API first, falls
 * back to `execCommand('copy')` on failure.
 *
 * @returns true on success, false if both methods fail
 */
export async function copyToClipboard(text: string): Promise<boolean> {
  // 1. Try modern async Clipboard API (HTTPS / localhost)
  if (
    typeof navigator !== "undefined" &&
    navigator.clipboard &&
    typeof navigator.clipboard.writeText === "function" &&
    (typeof window !== "undefined" && window.isSecureContext)
  ) {
    try {
      await navigator.clipboard.writeText(text);
      return true;
    } catch {
      // fall through to legacy method
    }
  }

  // 2. Fallback: legacy execCommand with hidden textarea
  if (typeof document === "undefined") return false;
  try {
    const textarea = document.createElement("textarea");
    textarea.value = text;
    // Position off-screen so it's invisible but still focusable
    textarea.style.position = "fixed";
    textarea.style.left = "-9999px";
    textarea.style.top = "0";
    textarea.style.opacity = "0";
    textarea.setAttribute("readonly", "");
    document.body.appendChild(textarea);
    textarea.focus();
    textarea.select();
    // execCommand is deprecated but still works in all browsers
    const ok = document.execCommand("copy");
    document.body.removeChild(textarea);
    return ok;
  } catch {
    return false;
  }
}
