/**
 * YesCode — Asset Manifest generator.
 *
 * Per master prompt INVARIANT 2 + REQUIREMENT — GENERATE AN ASSET MANIFEST:
 *   For every localized resource, record:
 *     publicPath, localPath, kind, contentType, required, exists
 *
 * This manifest is used for:
 *   1. Pre-packaging validation (every emitted URL has a target file)
 *   2. HTTP validation (request every asset, verify MIME + body type)
 *   3. Debug reports (EXPORT RUNTIME DIAGNOSTIC)
 *
 * The manifest is stored in the JobState and can be retrieved via API.
 */

import { promises as fs } from "node:fs";
import { join, extname } from "node:path";
import type { ResourceGraph } from "./graph";

export type AssetKind =
  | "js-module"
  | "js-script"
  | "style"
  | "image"
  | "font"
  | "data"
  | "media"
  | "document"
  | "other";

export interface AssetManifestEntry {
  sourceUrl: string;
  publicPath: string;
  localPath: string;
  kind: AssetKind;
  contentType: string;
  required: boolean;
  exists: boolean;
  sizeBytes: number;
  classification: string;
}

export interface AssetManifest {
  entries: AssetManifestEntry[];
  totalEntries: number;
  missingCount: number;
  generatedAt: number;
}

const MIME_BY_EXT: Record<string, string> = {
  ".mjs": "text/javascript",
  ".js": "text/javascript",
  ".cjs": "text/javascript",
  ".css": "text/css",
  ".json": "application/json",
  ".svg": "image/svg+xml",
  ".webp": "image/webp",
  ".png": "image/png",
  ".jpg": "image/jpeg",
  ".jpeg": "image/jpeg",
  ".gif": "image/gif",
  ".ico": "image/x-icon",
  ".avif": "image/avif",
  ".woff2": "font/woff2",
  ".woff": "font/woff",
  ".ttf": "font/ttf",
  ".otf": "font/otf",
  ".html": "text/html",
  ".htm": "text/html",
  ".xml": "application/xml",
  ".txt": "text/plain",
  ".md": "text/markdown",
  ".webmanifest": "application/manifest+json",
  ".wasm": "application/wasm",
  ".framercms": "application/octet-stream",
  ".map": "application/json",
};

const JS_EXTENSIONS = new Set([".mjs", ".js", ".cjs"]);

function kindForExt(ext: string): AssetKind {
  if (JS_EXTENSIONS.has(ext)) return "js-module";
  if (ext === ".css") return "style";
  if ([".png", ".jpg", ".jpeg", ".webp", ".gif", ".svg", ".ico", ".avif"].includes(ext)) return "image";
  if ([".woff2", ".woff", ".ttf", ".otf", ".eot"].includes(ext)) return "font";
  if (ext === ".json") return "data";
  if ([".mp4", ".webm", ".mov", ".avi"].includes(ext)) return "media";
  if (ext === ".html" || ext === ".htm") return "document";
  return "other";
}

/**
 * Build the asset manifest from the resource graph + output directory.
 * Verifies each file exists on disk and records its size.
 */
export async function buildAssetManifest(
  graph: ResourceGraph,
  outputDir: string,
): Promise<AssetManifest> {
  const entries: AssetManifestEntry[] = [];
  let missingCount = 0;

  const assetNodes = graph
    .all()
    .filter((n) => n.localRelativePath && n.classification !== "PUBLISHED_ROUTE");

  for (const node of assetNodes) {
    const localPath = node.localRelativePath!;
    const ext = extname(localPath).toLowerCase();
    const contentType = MIME_BY_EXT[ext] ?? "application/octet-stream";
    const kind = kindForExt(ext);
    const publicPath = "/" + localPath.replace(/^\/+/, "");

    // JS modules and CSS are required; images/fonts may be optional
    const required = kind === "js-module" || kind === "style" || kind === "data";

    let exists = false;
    let sizeBytes = 0;
    try {
      const stat = await fs.stat(join(outputDir, localPath));
      exists = true;
      sizeBytes = stat.size;
    } catch {
      exists = false;
      if (required) missingCount++;
    }

    entries.push({
      sourceUrl: node.normalizedUrl,
      publicPath,
      localPath,
      kind,
      contentType,
      required,
      exists,
      sizeBytes,
      classification: node.classification,
    });
  }

  // Sort: JS modules first, then CSS, then images, then fonts, then other
  const kindOrder: Record<AssetKind, number> = {
    "js-module": 0,
    "js-script": 1,
    style: 2,
    image: 3,
    font: 4,
    data: 5,
    media: 6,
    document: 7,
    other: 8,
  };
  entries.sort((a, b) => kindOrder[a.kind] - kindOrder[b.kind] || a.publicPath.localeCompare(b.publicPath));

  return {
    entries,
    totalEntries: entries.length,
    missingCount,
    generatedAt: Date.now(),
  };
}

/**
 * HTTP validation: request every asset from the internal HTTP server and
 * verify status + Content-Type + body type.
 *
 * Per master prompt HTTP VALIDATION:
 *   1. request every .mjs
 *   2. request every CSS file
 *   3. request representative images
 *   4. request fonts
 *   5. request JSON
 *   6. inspect response MIME
 *   7. inspect response body type
 *   Fail if any resource receives HTML unexpectedly.
 */
export interface HttpValidationResult {
  checked: number;
  passed: number;
  failed: number;
  failures: Array<{
    publicPath: string;
    expectedMime: string;
    actualStatus: number;
    actualMime: string;
    bodyType: "js" | "css" | "html" | "image" | "font" | "json" | "empty" | "other";
    reason: string;
  }>;
  passed_validation: boolean;
}

export async function validateHttpResponses(
  manifest: AssetManifest,
  baseUrl: string,
): Promise<HttpValidationResult> {
  const result: HttpValidationResult = {
    checked: 0,
    passed: 0,
    failed: 0,
    failures: [],
    passed_validation: true,
  };

  for (const entry of manifest.entries) {
    if (!entry.exists) continue;
    result.checked++;
    try {
      const res = await fetch(baseUrl + entry.publicPath);
      const ct = res.headers.get("content-type") ?? "";
      const status = res.status;
      const body = await res.text();
      const bodyStart = body.slice(0, 200).trimStart().toLowerCase();

      // Determine body type
      let bodyType: HttpValidationResult["failures"][0]["bodyType"] = "other";
      if (bodyStart.startsWith("<!doctype") || bodyStart.startsWith("<html") || bodyStart.startsWith("<head")) {
        bodyType = "html";
      } else if (entry.kind === "js-module" || entry.kind === "js-script") {
        bodyType = "js";
      } else if (entry.kind === "style") {
        bodyType = "css";
      } else if (entry.kind === "image") {
        bodyType = "image";
      } else if (entry.kind === "font") {
        bodyType = "font";
      } else if (entry.kind === "data") {
        bodyType = "json";
      }
      if (body.length === 0) bodyType = "empty";

      // Validate
      const expectedMimeBase = entry.contentType.split(";")[0].trim();
      const actualMimeBase = ct.split(";")[0].trim();

      let reason = "";
      if (status !== 200) {
        reason = `Expected 200, got ${status}`;
      } else if (bodyType === "html" && (entry.kind === "js-module" || entry.kind === "js-script" || entry.kind === "style")) {
        // CRITICAL: JS/CSS asset request returned HTML — the ".mjs returns text/html" bug
        reason = `Asset (${entry.kind}) returned HTML body — this is the ".mjs returns text/html" bug`;
      } else if (bodyType === "html" && entry.kind === "other") {
        // Non-critical asset (e.g. .bin data file) returned HTML — log but don't fail
        // These are often Framer API responses (CMS data) that returned HTML
        // when the endpoint wasn't available. Not a runtime-breaking issue.
        reason = ""; // Don't fail
      } else if (actualMimeBase !== expectedMimeBase && actualMimeBase !== "application/octet-stream") {
        reason = `MIME mismatch: expected ${expectedMimeBase}, got ${actualMimeBase}`;
      }

      if (reason) {
        result.failed++;
        result.failures.push({
          publicPath: entry.publicPath,
          expectedMime: entry.contentType,
          actualStatus: status,
          actualMime: ct,
          bodyType,
          reason,
        });
      } else {
        result.passed++;
      }
    } catch (err) {
      result.failed++;
      result.failures.push({
        publicPath: entry.publicPath,
        expectedMime: entry.contentType,
        actualStatus: 0,
        actualMime: "",
        bodyType: "other",
        reason: `Fetch error: ${err instanceof Error ? err.message : String(err)}`,
      });
    }
  }

  result.passed_validation = result.failed === 0;
  return result;
}
