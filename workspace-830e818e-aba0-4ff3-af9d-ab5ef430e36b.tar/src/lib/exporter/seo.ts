/**
 * YesCode — SEO generator.
 *
 * Per rules.md SEO section:
 *   - sitemap.xml: valid XML with <loc> + <lastmod>
 *   - robots.txt: standard permissive directives referencing /sitemap.xml
 *   - HTML <head>: retain og:*, twitter:*, JSON-LD, set <link rel=canonical>
 *     to point to the user-specified production domain.
 */

import { promises as fs } from "node:fs";
import { join } from "node:path";
import type { DiscoveredRoute } from "./discovery";
import type { StructuredLogger } from "./logger";

/** Generate sitemap.xml content. */
export function sitemapXml(routes: DiscoveredRoute[], origin: string): string {
  const now = new Date().toISOString();
  const urls = routes.map((r) => {
    const u = new URL(r.url);
    const path = u.pathname.replace(/\/index\.html$/, "/");
    const loc = `${origin}${path}`.replace(/\/+$/, "/");
    return `  <url>
    <loc>${escapeXml(loc)}</loc>
    <lastmod>${now}</lastmod>
    <changefreq>weekly</changefreq>
    <priority>0.7</priority>
  </url>`;
  });
  return `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
${urls.join("\n")}
</urlset>
`;
}

/** Generate robots.txt content. */
export function robotsTxt(origin: string): string {
  return `# YesCode — robots.txt
User-agent: *
Allow: /

Sitemap: ${origin}/sitemap.xml
`;
}

function escapeXml(s: string): string {
  return s
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&apos;");
}

/** Write sitemap.xml and robots.txt to the output directory. */
export async function writeSeoFiles(
  outputDir: string,
  routes: DiscoveredRoute[],
  origin: string,
  logger: StructuredLogger,
): Promise<void> {
  const sitemap = sitemapXml(routes, origin);
  const robots = robotsTxt(origin);
  await fs.writeFile(join(outputDir, "sitemap.xml"), sitemap, "utf8");
  await fs.writeFile(join(outputDir, "robots.txt"), robots, "utf8");
  logger.info(
    `Wrote sitemap.xml (${routes.length} URLs) and robots.txt`,
    undefined,
    "SEO",
  );
}

/**
 * Inject a <link rel=canonical> into an HTML document pointing to the
 * production domain. If one already exists, replace its href.
 */
export function injectCanonical(html: string, canonicalHref: string): string {
  // Naive but safe: operate on <head> tag, only once
  const tag = `<link rel="canonical" href="${canonicalHref}">`;
  if (/<link\s+rel=["']canonical["']/i.test(html)) {
    return html.replace(
      /<link\s+rel=["']canonical["'][^>]*>/i,
      tag,
    );
  }
  if (/<\/head>/i.test(html)) {
    return html.replace(/<\/head>/i, `${tag}</head>`);
  }
  return html;
}
