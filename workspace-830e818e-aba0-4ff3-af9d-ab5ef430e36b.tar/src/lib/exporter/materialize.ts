/**
 * YesCode — Asset materialization (concurrent download pool).
 *
 * Per rules.md ASSET LOCALIZATION section:
 *   - Bounded worker pool (max 8 concurrent downloads)
 *   - Collision-safe naming: assets/<category>/<sanitized>-<hash12>.<ext>
 *   - Category folders: images/, js/sites/<siteId>/, js/modules/, css/,
 *     fonts/, media/, vendor/
 *   - Hash: SHA-256 of normalized URL (first 12 hex chars)
 *   - Extension: Content-Type first, URL ext fallback
 *   - Query param dedup: each ?scale-down-to= variant is a distinct file
 *   - Resource limits: max 100 MB per file, max 2 GB total
 */

import { createHash } from "node:crypto";
import { promises as fs } from "node:fs";
import { join, dirname } from "node:path";
import type { ResourceGraph, ResourceNode } from "./graph";
import { fetchWithUa, inferExtension } from "./capture";
import { classifyUrl, shouldDownload, type UrlClassification } from "./classifier";
import { MAX_FILE_SIZE_BYTES, MAX_TOTAL_ARCHIVE_BYTES, assertSafeArchivePath } from "./security";
import type { StructuredLogger } from "./logger";

const MAX_CONCURRENCY = 8;
const SITE_ID_RE = /\/sites\/v1\/([^/]+)\//i;

/** Map classification → category folder under /assets/. */
function categoryFor(c: UrlClassification, originalUrl?: string): string {
  // CMS data files (.framercms) go to /assets/js/cms/ (runtime expects them there)
  if (originalUrl && originalUrl.endsWith(".framercms")) return "js/cms";
  switch (c) {
    case "FRAMER_ASSET": return "images";
    case "FRAMER_RUNTIME": return "js/modules";
    case "THIRD_PARTY_STATIC_ASSET": return "vendor";
    case "FRAMER_BOOTSTRAP": return "js/bootstrap";
    case "LOCAL_RESOURCE": return "js/modules"; // relative JS imports → js/modules
    default: return "other";
  }
}

/**
 * Determine the file extension for a downloaded asset, with EXPLICIT
 * precedence to avoid the operator-precedence bug where JS modules were
 * saved with `.css` extension.
 *
 * Per the critical bug fix: JS modules (FRAMER_RUNTIME / FRAMER_BOOTSTRAP)
 * MUST be saved with `.mjs` or `.js` — NEVER `.css`. The basenames
 * react.*, framer.*, motion.*, script_main.* are always ESM modules → `.mjs`.
 *
 * Precedence (top wins):
 *   1. FRAMER_RUNTIME / FRAMER_BOOTSTRAP → always mjs/js (see isJsModule)
 *   2. Content-Type: text/css → css (only for non-JS categories)
 *   3. inferExtension fallback (URL ext or content-type map)
 */
function isJsModule(c: UrlClassification, url: string, contentType: string | null): boolean {
  if (c !== "FRAMER_RUNTIME" && c !== "FRAMER_BOOTSTRAP" && c !== "LOCAL_RESOURCE") return false;
  const ct = (contentType ?? "").split(";")[0].trim().toLowerCase();
  const lowerUrl = url.toLowerCase();
  // Content-Type indicates JavaScript
  if (ct === "text/javascript" || ct === "application/javascript" ||
      ct === "text/ecmascript" || ct === "application/ecmascript" ||
      ct === "module") {
    return true;
  }
  // URL extension
  if (lowerUrl.endsWith(".mjs") || lowerUrl.endsWith(".js") || lowerUrl.endsWith(".cjs")) {
    return true;
  }
  // URL path patterns typical of Framer runtime modules
  if (lowerUrl.includes("/modules/") || lowerUrl.includes("/sites/")) {
    return true;
  }
  // Basename patterns: react.*, framer.*, motion.*, script_main.*
  const baseName = (lowerUrl.split("?")[0].split("/").pop() ?? "").replace(/\.[a-z0-9]+$/i, "");
  if (/^(react|framer|motion|script_main|scheduler|react-dom|react-reconciler|three|gsap|popmotion)\b/.test(baseName)) {
    return true;
  }
  return false;
}

/** Extension-from-content-type override for specific categories.
 *
 * CRITICAL: All JS modules are saved as `.js` (not `.mjs`) to avoid
 * Google PageSpeed module on shared hosting (e.g. myjino.ru) rewriting
 * `.mjs` files into `.mjs.pagespeed.ce.XXX.js` which breaks minified JS
 * syntax and causes "SyntaxError: invalid regular expression flag j".
 * Browsers still execute `.js` files as ES modules when loaded via
 * `<script type="module">`, so this is safe. */
function overrideExtForCategory(c: UrlClassification, url: string, contentType: string | null): string {
  if (isJsModule(c, url, contentType)) {
    // Always use .js — avoids PageSpeed .mjs rewriting on shared hosting
    return "js";
  }
  return "";
}

/** Build the localRelativePath for a node. */
export function buildLocalPath(node: ResourceNode): string {
  const c = node.classification;
  if (c === "PUBLISHED_ROUTE") {
    // Routes are not stored under /assets; they become /route/index.html
    return "";
  }
  const cat = categoryFor(c, node.originalUrl);
  const hash = createHash("sha256").update(node.normalizedUrl).digest("hex").slice(0, 12);
  const url = new URL(node.normalizedUrl);
  const baseNameRaw = (url.pathname.split("/").pop() ?? "asset").replace(/\.[a-z0-9]+$/i, "") || "asset";
  const baseName = baseNameRaw.replace(/[^A-Za-z0-9._-]+/g, "-").slice(0, 60) || "asset";

  // CRITICAL: explicit precedence with proper parentheses.
  // Step 0: .framercms files keep their extension (not .bin)
  let ext = "";
  if (node.originalUrl.endsWith(".framercms")) {
    ext = "framercms";
  }
  // Step 1: category override (JS modules → js, never css)
  if (!ext) {
    ext = overrideExtForCategory(c, node.originalUrl, node.contentType);
  }
  // Step 2: only NON-JS categories can be CSS (check content-type)
  if (!ext) {
    const ct = (node.contentType ?? "").split(";")[0].trim().toLowerCase();
    if (ct === "text/css" || node.originalUrl.toLowerCase().endsWith(".css")) {
      ext = "css";
    }
  }
  // Step 3: fallback to inferExtension (URL ext or content-type map)
  if (!ext) {
    ext = inferExtension(node.originalUrl, node.contentType);
  }
  // Safety net: if somehow a JS category got "css", force "js"
  if ((c === "FRAMER_RUNTIME" || c === "FRAMER_BOOTSTRAP" || c === "LOCAL_RESOURCE") && ext === "css") {
    ext = "js";
  }
  // Safety net: force .js instead of .mjs for all JS modules (PageSpeed fix)
  if ((c === "FRAMER_RUNTIME" || c === "FRAMER_BOOTSTRAP" || c === "LOCAL_RESOURCE") && ext === "mjs") {
    ext = "js";
  }
  // .framercms files: no hash in filename (runtime constructs URL without hash)
  if (ext === "framercms") {
    return `assets/${cat}/${baseName}.${ext}`;
  }
  return `assets/${cat}/${baseName}-${hash}.${ext}`;
}

/** Worker: download a single node, save to disk, update graph. */
const MAX_RETRY_ATTEMPTS = 3;
const RETRY_BASE_DELAY_MS = 500;

/** Sleep helper that respects AbortSignal. */
function sleep(ms: number, signal?: AbortSignal): Promise<void> {
  return new Promise((resolve, reject) => {
    if (signal?.aborted) {
      reject(new Error("Aborted"));
      return;
    }
    const t = setTimeout(resolve, ms);
    signal?.addEventListener("abort", () => {
      clearTimeout(t);
      reject(new Error("Aborted"));
    }, { once: true });
  });
}

/** Returns true if an error is retryable (network/timeout, not 4xx). */
function isRetryableError(err: unknown, httpStatus: number | null): boolean {
  // 5xx server errors are retryable
  if (httpStatus !== null && httpStatus >= 500 && httpStatus < 600) return true;
  // 429 Too Many Requests is retryable
  if (httpStatus === 429) return true;
  // Network errors (fetch threw) are retryable
  if (err instanceof Error) {
    const msg = err.message.toLowerCase();
    if (msg.includes("fetch") || msg.includes("network") || msg.includes("timeout") || msg.includes("econnreset") || msg.includes("etimedout")) {
      return true;
    }
  }
  return false;
}

async function downloadNode(
  node: ResourceNode,
  outputDir: string,
  graph: ResourceGraph,
  logger: StructuredLogger,
  signal: AbortSignal | undefined,
): Promise<void> {
  if (node.state === "DOWNLOADED" || node.state === "COMPLETED") return;
  if (node.classification === "PUBLISHED_ROUTE" || node.classification === "INFORMATIONAL_STRING") return;
  // LOCAL_RESOURCE: skip only if it's a data: URI or already-local path.
  // Relative imports like `./foo.mjs` are classified as LOCAL_RESOURCE, but
  // their normalizedUrl points to the Framer CDN (after resolveUrl) — those
  // MUST be downloaded.
  if (node.classification === "LOCAL_RESOURCE") {
    if (!node.normalizedUrl.startsWith("http://") && !node.normalizedUrl.startsWith("https://")) {
      return; // data: URI or local path — skip
    }
  }

  const localPath = buildLocalPath(node);
  if (!localPath) return;

  // Zip slip check
  assertSafeArchivePath(localPath);

  graph.update(node.id, { state: "DOWNLOADING" });

  let lastErr: unknown = null;
  for (let attempt = 1; attempt <= MAX_RETRY_ATTEMPTS; attempt++) {
    if (signal?.aborted) {
      graph.update(node.id, { state: "FAILED" });
      return;
    }
    try {
      const { status, body, contentType } = await fetchWithUa(node.normalizedUrl, signal);

      // Non-retryable HTTP errors (4xx except 429)
      if (status >= 400 && !isRetryableError(null, status)) {
        graph.update(node.id, { state: "FAILED" });
        logger.warn(`Asset ${node.normalizedUrl} HTTP ${status} (permanent)`, undefined, "MATERIALIZE");
        return;
      }

      // Retryable HTTP errors (5xx, 429)
      if (status >= 400 && isRetryableError(null, status)) {
        if (attempt < MAX_RETRY_ATTEMPTS) {
          const delay = RETRY_BASE_DELAY_MS * Math.pow(2, attempt - 1);
          logger.debug(
            `Asset ${node.normalizedUrl} HTTP ${status}, retry ${attempt + 1}/${MAX_RETRY_ATTEMPTS} in ${delay}ms`,
            undefined,
            "MATERIALIZE",
          );
          await sleep(delay, signal);
          continue;
        }
        graph.update(node.id, { state: "FAILED" });
        logger.warn(
          `Asset ${node.normalizedUrl} HTTP ${status} after ${MAX_RETRY_ATTEMPTS} attempts`,
          undefined,
          "MATERIALIZE",
        );
        return;
      }

      // Success
      if (body.length > MAX_FILE_SIZE_BYTES) {
        graph.update(node.id, { state: "FAILED" });
        logger.error(
          `Asset exceeds 100 MB: ${node.normalizedUrl} (${body.length} bytes)`,
          undefined,
          "MATERIALIZE",
        );
        return;
      }
      const diskPath = join(outputDir, localPath);
      await fs.mkdir(dirname(diskPath), { recursive: true });
      await fs.writeFile(diskPath, body);
      graph.update(node.id, {
        state: "DOWNLOADED",
        body,
        contentType,
        httpStatus: status,
        localRelativePath: localPath,
        diskPath,
      });
      if (attempt > 1) {
        logger.info(
          `Downloaded ${node.classification} → /${localPath} (after ${attempt} attempts)`,
          { bytes: body.length },
          "MATERIALIZE",
        );
      } else {
        logger.debug(`Downloaded ${node.classification} → /${localPath}`, {
          bytes: body.length,
        });
      }
      return; // success
    } catch (err) {
      lastErr = err;
      if (signal?.aborted) {
        graph.update(node.id, { state: "FAILED" });
        return;
      }
      if (isRetryableError(err, null) && attempt < MAX_RETRY_ATTEMPTS) {
        const delay = RETRY_BASE_DELAY_MS * Math.pow(2, attempt - 1);
        logger.debug(
          `Download error for ${node.normalizedUrl}, retry ${attempt + 1}/${MAX_RETRY_ATTEMPTS} in ${delay}ms: ${err instanceof Error ? err.message : String(err)}`,
          undefined,
          "MATERIALIZE",
        );
        try {
          await sleep(delay, signal);
        } catch {
          graph.update(node.id, { state: "FAILED" });
          return;
        }
        continue;
      }
      // Non-retryable error or out of retries
      graph.update(node.id, { state: "FAILED" });
      logger.warn(
        `Download failed for ${node.normalizedUrl}: ${err instanceof Error ? err.message : String(err)}`,
        undefined,
        "MATERIALIZE",
      );
      return;
    }
  }

  // Exhausted retries
  void lastErr;
  graph.update(node.id, { state: "FAILED" });
  logger.warn(
    `Download failed for ${node.normalizedUrl} after ${MAX_RETRY_ATTEMPTS} attempts`,
    undefined,
    "MATERIALIZE",
  );
}

/** Run a bounded worker pool over the queue of nodes to download. */
export async function materializeAll(
  graph: ResourceGraph,
  outputDir: string,
  logger: StructuredLogger,
  signal: AbortSignal | undefined,
  onProgress?: (done: number, total: number) => void,
): Promise<{ downloaded: number; failed: number; totalBytes: number }> {
  const targets = graph
    .all()
    .filter((n) => shouldDownload(n.classification) || n.classification === "FRAMER_ASSET" || n.classification === "FRAMER_RUNTIME" || n.classification === "THIRD_PARTY_STATIC_ASSET" || n.classification === "LOCAL_RESOURCE")
    // Skip nodes already downloaded in GRAPH pass
    .filter((n) => n.state !== "DOWNLOADED" && n.state !== "COMPLETED" && n.state !== "FAILED");

  // Deduplicate by id AND by localRelativePath (different URLs may map to same file)
  const unique = new Map<string, ResourceNode>();
  for (const n of targets) {
    const key = n.localRelativePath ?? n.id;
    if (!unique.has(key)) unique.set(key, n);
  }
  const queue = [...unique.values()];

  let done = 0;
  let failed = 0;
  let totalBytes = 0;
  const total = queue.length;
  onProgress?.(0, total);

  // Bounded pool
  let cursor = 0;
  const next = (): ResourceNode | undefined => queue[cursor++];
  const worker = async () => {
    while (true) {
      if (signal?.aborted) return;
      const node = next();
      if (!node) return;
      const before = node.state;
      await downloadNode(node, outputDir, graph, logger, signal);
      const updated = graph.getNode(node.id);
      if (updated?.state === "DOWNLOADED") {
        totalBytes += updated.sizeBytes;
      } else if (updated?.state === "FAILED") {
        failed++;
      }
      done++;
      if (totalBytes > MAX_TOTAL_ARCHIVE_BYTES) {
        logger.error(
          `Total archive size exceeds 2 GB cap — aborting further downloads`,
          { bytes: totalBytes },
          "MATERIALIZE",
        );
        return;
      }
      onProgress?.(done, total);
      void before;
    }
  };
  const workers = Array.from({ length: Math.min(MAX_CONCURRENCY, total) }, worker);
  await Promise.all(workers);
  return {
    downloaded: total - failed,
    failed,
    totalBytes,
  };
}

/** Reclassify at the end (used when content-type reveals a more specific category). */
export function refineClassification(node: ResourceNode): UrlClassification | null {
  if (node.contentType && node.contentType.includes("css") && node.classification === "FRAMER_RUNTIME") {
    return "FRAMER_ASSET";
  }
  return null;
}

/** Quick classifier shim for callers that only need a yes/no on a raw URL. */
export function shouldLocalizeUrl(raw: string, ctx: { targetOrigin: string; initiatorOrigin: string }): boolean {
  const c = classifyUrl(raw, ctx);
  return shouldDownload(c) || c === "FRAMER_ASSET" || c === "FRAMER_RUNTIME" || c === "THIRD_PARTY_STATIC_ASSET";
}

void SITE_ID_RE;
