/**
 * YesCode — Security & SSRF guard.
 *
 * Per rules.md SECURITY section:
 *  - Resolve target host to IP address via DNS lookup before initiating capture.
 *  - Reject private IP ranges (RFC 1918, loopback 127.0.0.0/8, link-local
 *    169.254.0.0/16, IPv6 ::1, AWS metadata 169.254.169.254).
 *  - Enforce max file size 100 MB per asset, max total archive 2 GB.
 *  - Hard watchdog per export job: 10 minutes.
 *  - Zip slip prevention: validate archive paths escape neither target root
 *    nor `..` traversal.
 */

import { promises as dns } from "node:dns";
import { isAbsolute, normalize, sep } from "node:path";
import { resolve } from "node:path";

export const MAX_FILE_SIZE_BYTES = 100 * 1024 * 1024; // 100 MB
export const MAX_TOTAL_ARCHIVE_BYTES = 2 * 1024 * 1024 * 1024; // 2 GB
export const MAX_JOB_DURATION_MS = 10 * 60 * 1000; // 10 minutes

export class SsrfError extends Error {
  constructor(message: string, public readonly code: string) {
    super(message);
    this.name = "SsrfError";
  }
}

/** Returns true if an IPv4 or IPv6 string is private/internal. */
export function isPrivateIp(ip: string): boolean {
  // IPv6 variants
  if (ip === "::1" || ip === "::" || ip.startsWith("fe80:") || ip.startsWith("fc") || ip.startsWith("fd")) {
    return true;
  }
  // IPv4
  if (ip.includes(".")) {
    const parts = ip.split(".").map((p) => parseInt(p, 10));
    if (parts.length !== 4 || parts.some((p) => Number.isNaN(p) || p < 0 || p > 255)) {
      return false;
    }
    const [a, b, c, d] = parts;
    // Loopback 127.0.0.0/8
    if (a === 127) return true;
    // 0.0.0.0/8
    if (a === 0) return true;
    // RFC 1918: 10/8, 172.16/12, 192.168/16
    if (a === 10) return true;
    if (a === 172 && b >= 16 && b <= 31) return true;
    if (a === 192 && b === 168) return true;
    // Link-local 169.254.0.0/16 (incl. AWS metadata 169.254.169.254)
    if (a === 169 && b === 254) return true;
    // Carrier-grade NAT 100.64.0.0/10
    if (a === 100 && b >= 64 && b <= 127) return true;
    // Multicast & reserved
    if (a >= 224) return true;
    // 255.255.255.255 broadcast
    if (a === 255 && b === 255 && c === 255 && d === 255) return true;
  }
  return false;
}

/**
 * Validate that `targetUrl` is well-formed, uses http(s), and does not
 * resolve to a private IP. Throws SsrfError on violation.
 */
export async function assertSafeTargetUrl(raw: string): Promise<URL> {
  let url: URL;
  try {
    url = new URL(raw);
  } catch {
    throw new SsrfError("Invalid URL syntax", "INVALID_URL");
  }
  if (url.protocol !== "http:" && url.protocol !== "https:") {
    throw new SsrfError("Only http/https protocols allowed", "BAD_PROTOCOL");
  }
  const host = url.hostname;
  if (!host) throw new SsrfError("Empty hostname", "EMPTY_HOST");

  // Quick reject for literal-IP private targets before DNS
  if (/^\d+\.\d+\.\d+\.\d+$/.test(host) && isPrivateIp(host)) {
    throw new SsrfError(`Target host ${host} resolves to a private IP`, "SSRF_PRIVATE_IP");
  }
  if (host === "localhost" || host.endsWith(".localhost")) {
    throw new SsrfError("Localhost targets are blocked", "SSRF_LOCALHOST");
  }

  // DNS resolve all A/AAAA records and reject if ANY is private
  let addrs: string[] = [];
  try {
    const a = await dns.resolve4(host).catch(() => [] as string[]);
    const aaaa = await dns.resolve6(host).catch(() => [] as string[]);
    addrs = [...a, ...aaaa];
  } catch {
    // DNS failure — let fetch handle the actual reachability downstream
  }
  if (addrs.length === 0) {
    // Could be a domain the sandbox can't resolve; we don't fail hard here —
    // the capture step will produce a clearer network error.
  } else {
    for (const a of addrs) {
      if (isPrivateIp(a)) {
        throw new SsrfError(
          `Target host ${host} resolves to private IP ${a}`,
          "SSRF_PRIVATE_IP",
        );
      }
    }
  }
  return url;
}

/**
 * Zip slip prevention: ensure `path` does not escape `root` via `..`
 * or absolute paths. Returns the resolved safe absolute path.
 */
export function safeJoin(root: string, ...parts: string[]): string {
  const dirty = parts.join(sep);
  if (dirty.includes("..")) {
    throw new SsrfError(
      `Path traversal detected: ${dirty}`,
      "ZIP_SLIP",
    );
  }
  // Normalize and ensure within root
  const candidate = isAbsolute(dirty) ? dirty : resolve(root, dirty);
  const normalizedRoot = resolve(root);
  if (!candidate.startsWith(normalizedRoot + sep) && candidate !== normalizedRoot) {
    throw new SsrfError(
      `Path escapes target root: ${candidate}`,
      "ZIP_SLIP",
    );
  }
  return candidate;
}

/** Sanity check that an archive entry path is safe to write. */
export function assertSafeArchivePath(entryPath: string): void {
  const normalized = normalize(entryPath);
  if (normalized.startsWith("..") || isAbsolute(normalized)) {
    throw new SsrfError(
      `Unsafe archive path: ${entryPath}`,
      "ZIP_SLIP",
    );
  }
}
