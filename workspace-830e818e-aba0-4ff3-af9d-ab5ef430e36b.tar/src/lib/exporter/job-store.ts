/**
 * YesCode — Prisma-backed Job persistence layer.
 *
 * The in-memory JobManager remains the source of truth for *running* jobs
 * (SSE bus, AbortController, watchdog). This module mirrors job state to
 * SQLite so that:
 *   - History survives dev server restarts.
 *   - Completed ZIPs remain downloadable after a restart.
 *   - The /api/export history endpoint can paginate without holding all
 *     jobs in memory.
 *
 * Persistence is best-effort: if the DB is unavailable (e.g., file locked),
 * the manager continues operating in-memory only and logs a warning.
 */

import { db } from "@/lib/db";
import type { Prisma } from "@prisma/client";
import type {
  JobState,
  ProgressEvent,
  ExportMetrics,
  ExportOptions,
} from "./pipeline";

/** Convert in-memory JobState → Prisma upsert payload. */
function toRow(state: JobState, options?: ExportOptions): Prisma.ExportJobUpsertArgs {
  return {
    where: { jobId: state.jobId },
    create: {
      jobId: state.jobId,
      targetUrl: state.targetUrl,
      status: state.status,
      stage: state.stage,
      overall: state.overall,
      message: state.message,
      error: state.error,
      metricsJson: state.metrics ? JSON.stringify(state.metrics) : null,
      optionsJson: options ? JSON.stringify(options) : null,
      outputZipPath: state.outputZipPath,
      logsJson: JSON.stringify(state.logs.slice(-5000)),
      createdAt: new Date(state.createdAt),
      updatedAt: new Date(state.updatedAt),
    },
    update: {
      status: state.status,
      stage: state.stage,
      overall: state.overall,
      message: state.message,
      error: state.error,
      metricsJson: state.metrics ? JSON.stringify(state.metrics) : null,
      outputZipPath: state.outputZipPath,
      logsJson: JSON.stringify(state.logs.slice(-5000)),
      updatedAt: new Date(state.updatedAt),
    },
  };
}

/** Convert a Prisma row → in-memory JobState. */
export function rowToState(row: {
  jobId: string;
  targetUrl: string;
  status: string;
  stage: string;
  overall: number;
  message: string;
  error: string | null;
  metricsJson: string | null;
  optionsJson: string | null;
  outputZipPath: string | null;
  logsJson: string;
  createdAt: Date;
  updatedAt: Date;
}): JobState {
  let metrics: ExportMetrics | null = null;
  if (row.metricsJson) {
    try {
      metrics = JSON.parse(row.metricsJson) as ExportMetrics;
    } catch {
      metrics = null;
    }
  }
  let logs: ProgressEvent[] = [];
  try {
    logs = JSON.parse(row.logsJson) as ProgressEvent[];
  } catch {
    logs = [];
  }
  return {
    jobId: row.jobId,
    targetUrl: row.targetUrl,
    status: row.status as JobState["status"],
    stage: row.stage as JobState["stage"],
    overall: row.overall,
    message: row.message,
    createdAt: row.createdAt.getTime(),
    updatedAt: row.updatedAt.getTime(),
    logs,
    metrics,
    error: row.error,
    outputZipPath: row.outputZipPath,
  };
}

/** Parse options JSON from a row, returning undefined on failure. */
export function rowToOptions(row: { optionsJson: string | null }): ExportOptions | undefined {
  if (!row.optionsJson) return undefined;
  try {
    return JSON.parse(row.optionsJson) as ExportOptions;
  } catch {
    return undefined;
  }
}

/** Upsert a job state to the DB (best-effort). */
export async function persistJobState(state: JobState, options?: ExportOptions): Promise<void> {
  try {
    await db.exportJob.upsert(toRow(state, options));
  } catch (err) {
    // Best-effort: don't crash the pipeline if DB write fails
    console.warn("[yescode] persistJobState failed:", err instanceof Error ? err.message : String(err));
  }
}

/** Load a single job state from the DB by jobId. Returns null if not found. */
export async function loadJobState(jobId: string): Promise<JobState | null> {
  try {
    const row = await db.exportJob.findUnique({ where: { jobId } });
    return row ? rowToState(row) : null;
  } catch (err) {
    console.warn("[yescode] loadJobState failed:", err instanceof Error ? err.message : String(err));
    return null;
  }
}

/** Load options for a job from the DB. */
export async function loadJobOptions(jobId: string): Promise<ExportOptions | undefined> {
  try {
    const row = await db.exportJob.findUnique({
      where: { jobId },
      select: { optionsJson: true },
    });
    return row ? rowToOptions(row) : undefined;
  } catch {
    return undefined;
  }
}

/** List recent jobs (newest first) — for the history panel + GET /api/export. */
export async function listRecentJobs(limit = 20): Promise<
  Array<{
    jobId: string;
    targetUrl: string;
    status: string;
    stage: string;
    overall: number;
    createdAt: Date;
    updatedAt: Date;
    metricsJson: string | null;
    outputZipPath: string | null;
  }>
> {
  try {
    return await db.exportJob.findMany({
      orderBy: { createdAt: "desc" },
      take: limit,
      select: {
        jobId: true,
        targetUrl: true,
        status: true,
        stage: true,
        overall: true,
        createdAt: true,
        updatedAt: true,
        metricsJson: true,
        outputZipPath: true,
      },
    });
  } catch (err) {
    console.warn("[yescode] listRecentJobs failed:", err instanceof Error ? err.message : String(err));
    return [];
  }
}

/** Delete a job from the DB (called when user clears history). */
export async function deleteJobRow(jobId: string): Promise<void> {
  try {
    await db.exportJob.delete({ where: { jobId } });
  } catch {
    // ignore not-found
  }
}

/** Count jobs by status (for diagnostics). */
export async function countJobs(): Promise<{ total: number; running: number; completed: number; failed: number }> {
  try {
    const [total, running, completed, failed] = await Promise.all([
      db.exportJob.count(),
      db.exportJob.count({ where: { status: "running" } }),
      db.exportJob.count({ where: { status: "completed" } }),
      db.exportJob.count({ where: { status: "failed" } }),
    ]);
    return { total, running, completed, failed };
  } catch {
    return { total: 0, running: 0, completed: 0, failed: 0 };
  }
}

const JOB_TTL_MS = 24 * 60 * 60 * 1000; // 24 hours
let lastCleanupTs = 0;
const CLEANUP_INTERVAL_MS = 5 * 60 * 1000; // at most every 5 min

/**
 * Delete jobs older than 24h AND their ZIP files from disk. Best-effort,
 * throttled to run at most once every 5 minutes. Called from listRecentJobs
 * so it piggybacks on the history polling.
 *
 * @returns the number of jobs deleted (0 if cleanup was skipped/throttled)
 */
export async function cleanupExpiredJobs(): Promise<number> {
  const now = Date.now();
  // Throttle: don't run more than once per 5 minutes
  if (now - lastCleanupTs < CLEANUP_INTERVAL_MS) return 0;
  lastCleanupTs = now;

  const cutoff = new Date(now - JOB_TTL_MS);
  let deleted = 0;
  try {
    // Find jobs older than TTL
    const expired = await db.exportJob.findMany({
      where: { createdAt: { lt: cutoff } },
      select: { jobId: true, outputZipPath: true },
    });
    if (expired.length === 0) return 0;

    // Delete ZIP files from disk (best-effort)
    const { promises: fs } = await import("node:fs");
    for (const row of expired) {
      if (row.outputZipPath) {
        try {
          await fs.unlink(row.outputZipPath);
        } catch {
          // ignore — file may already be gone
        }
      }
    }

    // Delete DB rows
    const result = await db.exportJob.deleteMany({
      where: { createdAt: { lt: cutoff } },
    });
    deleted = result.count;
    if (deleted > 0) {
      console.log(
        `[yescode] TTL cleanup: removed ${deleted} jobs older than 24h`,
      );
    }
  } catch (err) {
    console.warn(
      "[yescode] cleanupExpiredJobs failed:",
      err instanceof Error ? err.message : String(err),
    );
  }
  return deleted;
}
