/**
 * YesCode — Hybrid Job manager (in-memory + Prisma persistence).
 *
 * In-memory map is the source of truth for *running* jobs (SSE bus,
 * AbortController, watchdog). Prisma mirrors state to SQLite so history
 * survives restarts and completed ZIPs remain downloadable.
 *
 * Persistence is debounced: high-frequency progress events are buffered
 * and flushed every 800ms to avoid DB write storms. Terminal states
 * (completed/failed) flush immediately.
 */

import { EventEmitter } from "node:events";
import { randomUUID } from "node:crypto";
import type {
  JobState,
  ProgressEvent,
  ExportMetrics,
  ExportOptions,
} from "./pipeline";
import { computeOverall } from "./pipeline";
import {
  persistJobState,
  loadJobState,
  listRecentJobs,
  deleteJobRow,
} from "./job-store";

interface JobRecord {
  state: JobState;
  /** EventEmitter used to broadcast progress to SSE subscribers. */
  bus: EventEmitter;
  /** AbortController for the running pipeline. */
  abort: AbortController;
  /** Watchdog timeout. */
  watchdog: NodeJS.Timeout;
  startedAt: number;
  /** Export options used for this job. */
  options?: ExportOptions;
  /** Debounce timer for DB persistence. */
  flushTimer: NodeJS.Timeout | null;
  /** True if state has changed since last DB flush. */
  dirty: boolean;
}

const FLUSH_INTERVAL_MS = 800;
const MAX_LOGS_IN_MEMORY = 5000;

class JobManager {
  private jobs = new Map<string, JobRecord>();
  private buses = new Map<string, EventEmitter>();
  public readonly downloadsDir = "/tmp/yescode/downloads";
  public readonly tempDir = "/tmp/yescode/temp";

  createJob(targetUrl: string, options?: ExportOptions): { jobId: string; bus: EventEmitter; abort: AbortController } {
    const jobId = randomUUID();
    const bus = new EventEmitter();
    bus.setMaxListeners(0);
    const abort = new AbortController();
    const now = Date.now();
    const state: JobState = {
      jobId,
      targetUrl,
      status: "running",
      stage: "QUEUED",
      overall: 0,
      message: `Job ${jobId.slice(0, 8)} accepted, worker spinning up…`,
      createdAt: now,
      updatedAt: now,
      logs: [],
      metrics: null,
      error: null,
      outputZipPath: null,
    };
    const watchdog = setTimeout(() => {
      this.failJob(jobId, "Job exceeded 10 minute watchdog");
      abort.abort();
    }, 10 * 60 * 1000);
    const rec: JobRecord = {
      state,
      bus,
      abort,
      watchdog,
      startedAt: now,
      options,
      flushTimer: null,
      dirty: true,
    };
    this.jobs.set(jobId, rec);
    this.buses.set(jobId, bus);
    // Persist initial state immediately (best-effort, non-blocking)
    void persistJobState(state, options);
    return { jobId, bus, abort };
  }

  getOptions(jobId: string): ExportOptions | undefined {
    return this.jobs.get(jobId)?.options;
  }

  getJob(jobId: string): JobRecord | undefined {
    return this.jobs.get(jobId);
  }

  /**
   * Get the in-memory state for a job. Returns undefined if the job isn't
   * in memory (e.g., completed job from a previous server session). Use
   * `loadState` for an async version that falls back to Prisma.
   */
  getState(jobId: string): JobState | undefined {
    return this.jobs.get(jobId)?.state;
  }

  /**
   * Async state lookup: in-memory first, then Prisma. Used by API routes
   * that need to serve history across restarts.
   */
  async loadState(jobId: string): Promise<JobState | null> {
    const inMem = this.jobs.get(jobId)?.state;
    if (inMem) return inMem;
    return loadJobState(jobId);
  }

  getBus(jobId: string): EventEmitter | undefined {
    return this.buses.get(jobId);
  }

  /** Emit a progress event: store in logs + broadcast on the bus + mark dirty. */
  emitProgress(jobId: string, ev: Omit<ProgressEvent, "jobId" | "timestamp" | "overall"> & { overall?: number }): void {
    const rec = this.jobs.get(jobId);
    if (!rec) return;
    const overall = ev.overall ?? computeOverall(ev.stage, ev.progress);
    const fullEv: ProgressEvent = {
      ...ev,
      jobId,
      timestamp: Date.now(),
      overall,
    };
    rec.state.logs.push(fullEv);
    if (rec.state.logs.length > MAX_LOGS_IN_MEMORY) {
      rec.state.logs = rec.state.logs.slice(-4000);
    }
    rec.state.stage = ev.stage;
    rec.state.overall = overall;
    rec.state.message = ev.message;
    rec.state.updatedAt = Date.now();
    rec.dirty = true;
    rec.bus.emit("progress", fullEv);
    this.scheduleFlush(rec);
  }

  finishJob(jobId: string, metrics: ExportMetrics, zipPath: string): void {
    const rec = this.jobs.get(jobId);
    if (!rec) return;
    // Don't overwrite a terminal state (e.g., if cancel happened first)
    if (rec.state.status === "failed" || rec.state.status === "completed") return;
    rec.state.status = "completed";
    rec.state.metrics = metrics;
    rec.state.outputZipPath = zipPath;
    rec.state.stage = "COMPLETED";
    rec.state.overall = 100;
    rec.state.updatedAt = Date.now();
    clearTimeout(rec.watchdog);
    rec.dirty = true;
    rec.bus.emit("done", { metrics, zipPath });
    rec.bus.emit("close");
    // Flush immediately for terminal state
    void this.flushNow(rec);
  }

  failJob(jobId: string, error: string): void {
    const rec = this.jobs.get(jobId);
    if (!rec) return;
    // Don't overwrite a terminal state
    if (rec.state.status !== "running") return;
    rec.state.status = "failed";
    rec.state.error = error;
    rec.state.updatedAt = Date.now();
    clearTimeout(rec.watchdog);
    rec.dirty = true;
    rec.bus.emit("error", { error });
    rec.bus.emit("close");
    void this.flushNow(rec);
  }

  /** Cancel a running job (user request). */
  cancelJob(jobId: string): void {
    const rec = this.jobs.get(jobId);
    if (!rec) return;
    rec.abort.abort();
    this.failJob(jobId, "Cancelled by user");
  }

  /** Delete a job from memory + DB. */
  async deleteJob(jobId: string): Promise<void> {
    const rec = this.jobs.get(jobId);
    if (rec) {
      clearTimeout(rec.watchdog);
      if (rec.flushTimer) clearTimeout(rec.flushTimer);
      rec.abort.abort();
    }
    this.jobs.delete(jobId);
    this.buses.delete(jobId);
    await deleteJobRow(jobId);
  }

  /** List in-memory job IDs (newest first). */
  listJobs(): string[] {
    return [...this.jobs.entries()]
      .sort((a, b) => b[1].state.createdAt - a[1].state.createdAt)
      .map(([id]) => id);
  }

  /**
   * List recent jobs across both in-memory and DB. Deduplicates by jobId,
   * preferring in-memory (fresher). Used by GET /api/export.
   */
  async listAllRecentJobs(limit = 20): Promise<JobState[]> {
    const inMemJobs = [...this.jobs.values()].map((r) => r.state);
    const inMemIds = new Set(inMemJobs.map((j) => j.jobId));
    const dbRows = await listRecentJobs(limit);
    const dbJobs: JobState[] = [];
    for (const row of dbRows) {
      if (inMemIds.has(row.jobId)) continue; // prefer in-memory
      // Reconstruct minimal JobState from row
      let metrics: ExportMetrics | null = null;
      if (row.metricsJson) {
        try {
          metrics = JSON.parse(row.metricsJson) as ExportMetrics;
        } catch {
          metrics = null;
        }
      }
      dbJobs.push({
        jobId: row.jobId,
        targetUrl: row.targetUrl,
        status: row.status as JobState["status"],
        stage: row.stage as JobState["stage"],
        overall: row.overall,
        message: "",
        createdAt: row.createdAt.getTime(),
        updatedAt: row.updatedAt.getTime(),
        logs: [],
        metrics,
        error: null,
        outputZipPath: row.outputZipPath,
      });
    }
    // Merge + sort + limit
    const merged = [...inMemJobs, ...dbJobs]
      .sort((a, b) => b.createdAt - a.createdAt)
      .slice(0, limit);
    return merged;
  }

  /** Schedule a debounced DB flush for a job. */
  private scheduleFlush(rec: JobRecord): void {
    if (rec.flushTimer) return; // already scheduled
    rec.flushTimer = setTimeout(() => {
      rec.flushTimer = null;
      if (rec.dirty) void this.flushNow(rec);
    }, FLUSH_INTERVAL_MS);
  }

  /** Flush state to DB immediately. */
  private async flushNow(rec: JobRecord): Promise<void> {
    if (rec.flushTimer) {
      clearTimeout(rec.flushTimer);
      rec.flushTimer = null;
    }
    rec.dirty = false;
    await persistJobState(rec.state, rec.options);
  }
}

// Singleton: use globalThis to survive Next.js dev mode (Turbopack) hot
// reloads, which would otherwise re-import this module and create a fresh
// JobManager per route handler — losing all in-memory running jobs.
const globalForJobs = globalThis as unknown as {
  __yescodeJobManager?: JobManager;
};
export const jobManager =
  globalForJobs.__yescodeJobManager ?? new JobManager();
if (process.env.NODE_ENV !== "production") {
  globalForJobs.__yescodeJobManager = jobManager;
}
