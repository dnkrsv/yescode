/**
 * YesCode — Route discovery (sitemap.xml + BFS anchor crawl).
 *
 * Per rules.md ROUTE DISCOVERY section:
 *   - Seed from /sitemap.xml, parse <loc> tags matching origin.
 *   - DOM anchor crawl from each rendered page.
 *   - Canonical normalization: strip hash, strip utm/fbclid/gclid.
 *   - Editor barrier: discard /edit/, /canvas/, /projects/.
 *   - Max page cap default 250 (ceiling 1000), max depth 10.
 */

import type { ResourceGraph } from "./graph";
import type { ClassifyContext } from "./classifier";
import { classifyUrl } from "./classifier";
import { normalizeUrl, resolveUrl, fetchWithUa } from "./capture";
import { load as cheerioLoad } from "cheerio";
import type { StructuredLogger } from "./logger";

export interface DiscoveryOptions {
  maxPages: number;
  maxDepth: number;
  /** If false, skip the sitemap fetch. */
  useSitemap: boolean;
}

export const DEFAULT_DISCOVERY_OPTIONS: DiscoveryOptions = {
  maxPages: 250,
  maxDepth: 10,
  useSitemap: true,
};

export const ABSOLUTE_MAX_PAGES = 1000;
export const ABSOLUTE_MAX_DEPTH = 10;

// Editor barrier patterns — ONLY /edit/ and /canvas/ are genuine editor
// infrastructure paths. /projects/, /templates/, /blog/, /cases/, /news/
// are valid CMS collection paths on published sites and must NOT be excluded.
const EDITOR_BARRIER_PATTERNS = [
  /\/edit\//i,
  /\/canvas\//i,
];

const STATIC_ASSET_EXTENSIONS = new Set([
  "css", "js", "mjs", "cjs", "json", "svg", "png", "jpg", "jpeg", "webp",
  "gif", "ico", "avif", "woff", "woff2", "ttf", "otf", "eot", "mp4",
  "webm", "mov", "avi", "mp3", "pdf", "zip", "txt", "xml", "map",
]);

export interface DiscoveredRoute {
  url: string;
  depth: number;
  /** Discovered via sitemap or anchor crawl. */
  source: "sitemap" | "anchor";
}

/**
 * Pull routes from sitemap.xml. Returns a list of URLs that share the
 * target origin. Supports sitemap indexes (<sitemapindex>) by recursively
 * fetching child sitemaps.
 */
export async function fetchSitemapRoutes(
  origin: string,
  signal?: AbortSignal,
): Promise<string[]> {
  const candidates = [
    `${origin}/sitemap.xml`,
    `${origin}/sitemap_index.xml`,
  ];
  for (const url of candidates) {
    try {
      const { status, body } = await fetchWithUa(url, signal);
      if (status >= 200 && status < 300) {
        const xml = body.toString("utf8");
        const routes = parseSitemapXml(xml, origin, signal);
        if (routes.length > 0) return routes;
      }
    } catch {
      // Try next candidate
    }
  }
  return [];
}

/**
 * Parse sitemap XML — handles both <urlset> (regular sitemap with page URLs)
 * and <sitemapindex> (sitemap index with child sitemap URLs). Child sitemaps
 * are fetched recursively (max depth 3 to prevent infinite loops).
 */
async function parseSitemapXml(
  xml: string,
  origin: string,
  signal?: AbortSignal,
  depth = 0,
): Promise<string[]> {
  const $ = cheerioLoad(xml, { xmlMode: true });
  const routes: string[] = [];

  // Check if this is a sitemap index (<sitemapindex> with <sitemap> children)
  const isSitemapIndex = $("sitemapindex").length > 0;

  if (isSitemapIndex && depth < 3) {
    // Sitemap index: recursively fetch each child sitemap
    const childSitemaps: string[] = [];
    $("sitemap > loc").each((_, el) => {
      const text = $(el).text().trim();
      if (!text) return;
      try {
        const u = new URL(text);
        // Only fetch same-origin child sitemaps
        if (u.origin === origin) childSitemaps.push(u.toString());
      } catch {
        // ignore invalid
      }
    });

    // Fetch child sitemaps sequentially (respect rate limits)
    for (const childUrl of childSitemaps) {
      if (signal?.aborted) break;
      try {
        const { status, body } = await fetchWithUa(childUrl, signal);
        if (status >= 200 && status < 300) {
          const childRoutes = await parseSitemapXml(
            body.toString("utf8"),
            origin,
            signal,
            depth + 1,
          );
          routes.push(...childRoutes);
        }
      } catch {
        // skip failed child sitemap
      }
    }
  } else {
    // Regular sitemap (<urlset> with <url> children)
    $("url > loc").each((_, el) => {
      const text = $(el).text().trim();
      if (!text) return;
      try {
        const u = new URL(text);
        if (u.origin === origin) routes.push(u.toString());
      } catch {
        // ignore invalid
      }
    });
  }

  // Deduplicate
  return [...new Set(routes)];
}

/** Returns true if the URL should be excluded (editor, asset, external). */
function isExcludableRoute(
  url: string,
  targetOrigin: string,
  ctx: ClassifyContext,
): boolean {
  const c = classifyUrl(url, ctx);
  if (c !== "PUBLISHED_ROUTE") return true;
  // Editor barrier
  if (EDITOR_BARRIER_PATTERNS.some((p) => p.test(url))) return true;
  // Asset extension barrier (a .css URL is not a route)
  try {
    const u = new URL(url);
    const ext = u.pathname.split(".").pop()?.toLowerCase();
    if (ext && STATIC_ASSET_EXTENSIONS.has(ext) && !u.pathname.endsWith("/")) {
      return true;
    }
  } catch {
    return true;
  }
  // Origin must match
  try {
    const u = new URL(url);
    if (u.origin !== targetOrigin) return true;
  } catch {
    return true;
  }
  return false;
}

/**
 * BFS crawl: starting from the seed URL, fetch each route, extract anchors,
 * classify them, and queue new internal routes up to maxPages/maxDepth.
 *
 * Side-effectful: populates the ResourceGraph with PUBLISHED_ROUTE nodes and
 * returns the list of successfully fetched routes (URL + html).
 */
export async function bfsCrawl(
  seedUrl: string,
  ctx: ClassifyContext,
  options: DiscoveryOptions,
  graph: ResourceGraph,
  logger: StructuredLogger,
  signal: AbortSignal | undefined,
  onRouteFetched: (url: string, html: string, finalUrl: string) => Promise<void>,
): Promise<DiscoveredRoute[]> {
  const targetOrigin = new URL(seedUrl).origin;
  const queue: DiscoveredRoute[] = [];
  const visited = new Set<string>();
  const accepted: DiscoveredRoute[] = [];

  const enqueue = (url: string, depth: number, source: "sitemap" | "anchor") => {
    if (depth > options.maxDepth) return;
    const normalized = normalizeUrl(url);
    if (visited.has(normalized)) return;
    if (isExcludableRoute(normalized, targetOrigin, ctx)) return;
    if (accepted.length + queue.length >= options.maxPages) return;
    visited.add(normalized);
    queue.push({ url: normalized, depth, source });
  };

  // Seed with sitemap routes (depth 0)
  if (options.useSitemap) {
    try {
      const sm = await fetchSitemapRoutes(targetOrigin, signal);
      logger.info(`Sitemap returned ${sm.length} route candidates`, undefined, "DISCOVERY");
      for (const u of sm) enqueue(u, 0, "sitemap");
    } catch (err) {
      logger.warn("Sitemap fetch failed", { error: err instanceof Error ? err.message : String(err) }, "DISCOVERY");
    }
  }
  // Always include the seed
  enqueue(seedUrl, 0, "sitemap");

  while (queue.length > 0) {
    if (signal?.aborted) break;
    const route = queue.shift()!;
    try {
      const { status, body, finalUrl, contentType } = await fetchWithUa(route.url, signal);
      if (status >= 400) {
        logger.warn(`Route ${route.url} returned HTTP ${status}`, undefined, "DISCOVERY");
        continue;
      }
      const ct = (contentType ?? "").toLowerCase();
      if (!ct.includes("html") && !ct.includes("xhtml")) {
        // Non-HTML route — skip but mark as seen
        continue;
      }
      const html = body.toString("utf8");
      // Add to graph as a PUBLISHED_ROUTE
      const routeNode = graph.upsert({
        originalUrl: route.url,
        normalizedUrl: normalizeUrl(finalUrl || route.url),
        classification: "PUBLISHED_ROUTE",
        initiatorUrl: null,
        contentType,
        httpStatus: status,
      });
      void routeNode;
      accepted.push({ ...route, url: finalUrl || route.url });
      // Hand HTML to caller for asset harvesting
      await onRouteFetched(finalUrl || route.url, html, finalUrl || route.url);
      // Extract anchors and enqueue new internal routes
      const $ = cheerioLoad(html);
      const anchors = $('a[href]').map((_, el) => $(el).attr("href") ?? "").get();
      let newFromAnchors = 0;
      for (const href of anchors) {
        const abs = resolveUrl(href, route.url);
        if (!abs) continue;
        const u = new URL(abs);
        u.hash = "";
        ["utm_source", "utm_medium", "utm_campaign", "utm_term", "utm_content", "fbclid", "gclid", "msclkid"].forEach((p) => u.searchParams.delete(p));
        const cleanUrl = u.toString();
        if (visited.has(normalizeUrl(cleanUrl))) continue;
        if (isExcludableRoute(cleanUrl, targetOrigin, ctx)) continue;
        enqueue(cleanUrl, route.depth + 1, "anchor");
        newFromAnchors++;
      }

      // === CMS DETAIL PAGE DISCOVERY (P2 fix) ===
      // Framer CMS collections render as [data-framer-collection-list] with
      // item links inside. Also extract CMS item URLs from embedded JSON
      // scripts (Framer serializes collection data in <script type="application/json">).
      let cmsRoutesFound = 0;

      // 1. Collection list items: links inside [data-framer-collection-list]
      $('[data-framer-collection-list] a[href], [data-framer-cms-collection] a[href]').each((_, el) => {
        const href = $(el).attr("href");
        if (!href) return;
        const abs = resolveUrl(href, route.url);
        if (!abs) return;
        try {
          const u = new URL(abs);
          if (u.origin !== targetOrigin) return;
          u.hash = "";
          const cleanUrl = u.toString();
          if (visited.has(normalizeUrl(cleanUrl))) return;
          if (isExcludableRoute(cleanUrl, targetOrigin, ctx)) return;
          enqueue(cleanUrl, route.depth + 1, "anchor");
          cmsRoutesFound++;
        } catch {
          // skip
        }
      });

      // 2. Embedded JSON: Framer stores CMS data in <script type="application/json">
      //    with id like "__FRAMER_STATE__" or data attributes. Scan for URLs.
      $('script[type="application/json"]').each((_, el) => {
        const code = $(el).html() ?? "";
        // Find all same-origin absolute URLs in the JSON
        const urlRe = new RegExp(`"https?://[^"]*${targetOrigin.replace(/[/.*+?^${}()|[\\]\\\\]/g, "\\\\$&")}[^"]*"`, "g");
        let m: RegExpExecArray | null;
        while ((m = urlRe.exec(code))) {
          try {
            const u = new URL(JSON.parse(m[0]));
            u.hash = "";
            ["utm_source", "utm_medium", "utm_campaign", "utm_term", "utm_content", "fbclid", "gclid", "msclkid"].forEach((p) => u.searchParams.delete(p));
            const cleanUrl = u.toString();
            if (visited.has(normalizeUrl(cleanUrl))) continue;
            if (isExcludableRoute(cleanUrl, targetOrigin, ctx)) continue;
            enqueue(cleanUrl, route.depth + 1, "anchor");
            cmsRoutesFound++;
          } catch {
            // skip
          }
        }
      });

      // 3. Canonical URLs from <link rel="canonical"> — these often point to
      //    CMS detail pages that may not be linked from navigation.
      $('link[rel="canonical"][href]').each((_, el) => {
        const href = $(el).attr("href");
        if (!href) return;
        const abs = resolveUrl(href, route.url);
        if (!abs) return;
        try {
          const u = new URL(abs);
          if (u.origin !== targetOrigin) return;
          u.hash = "";
          const cleanUrl = u.toString();
          if (visited.has(normalizeUrl(cleanUrl))) return;
          if (isExcludableRoute(cleanUrl, targetOrigin, ctx)) return;
          enqueue(cleanUrl, route.depth + 1, "anchor");
          cmsRoutesFound++;
        } catch {
          // skip
        }
      });

      logger.info(
        `Crawled ${route.url} (depth ${route.depth}, ${anchors.length} anchors, ${newFromAnchors} new, ${cmsRoutesFound} CMS)`,
        undefined,
        "DISCOVERY",
      );
    } catch (err) {
      if (signal?.aborted) break;
      logger.warn(
        `Route ${route.url} fetch failed: ${err instanceof Error ? err.message : String(err)}`,
        undefined,
        "DISCOVERY",
      );
    }
  }

  logger.info(
    `Discovered ${accepted.length} routes (visited=${visited.size})`,
    undefined,
    "DISCOVERY",
  );
  return accepted;
}
