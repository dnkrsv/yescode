/**
 * YesCode — Static routing & host configs.
 *
 * Per rules.md STATIC ROUTING section:
 *   - Root: /index.html
 *   - Path /about: /about/index.html
 *   - Path /blog/post: /blog/post/index.html
 *   - Custom 404: /404.html
 *
 * Hosting files generated:
 *   - .htaccess (Apache): DirectoryIndex, RewriteEngine for clean URLs,
 *     explicit MIME types for .mjs and .woff2.
 *   - nginx.conf: try_files + .mjs/.js MIME.
 *   - _redirects (Netlify/Cloudflare Pages): clean URL mapping + 404 fallback.
 */

import { promises as fs } from "node:fs";
import { join, dirname } from "node:path";
import type { DiscoveredRoute } from "./discovery";
import type { StructuredLogger } from "./logger";

/** Convert a URL pathname into a directory-style /path/index.html. */
export function routePathToDiskPath(pathname: string): string {
  let p = pathname.replace(/\/+$/, "/");
  if (p === "" || p === "/") return "index.html";
  if (!p.endsWith("/")) p += "/";
  // strip leading slash for relative disk path
  return `${p.replace(/^\//, "")}index.html`;
}

/** Generate the .htaccess content.
 *
 * Per master prompt STATIC SERVER CONTRACT + .HTACCESS section:
 *   - AddType application/javascript .mjs (and .js)
 *   - Options -Indexes
 *   - DirectoryIndex index.html
 *   - Rewrite rules MUST preserve the invariant: static asset requests
 *     never resolve to an HTML route. Only extension-less paths (routes)
 *     may fall back to <dir>/index.html.
 */
export function htaccessContent(): string {
  return `# YesCode — Apache .htaccess
# Generated deterministically by the YesCode pipeline.

DirectoryIndex index.html

# Critical: serve JS modules with correct MIME type (else browsers reject them)
AddType text/javascript .js .mjs
AddType text/javascript .cjs

# === KILL PAGESPEED COMPLETELY ===
# myjino.ru and other shared hosts use Google PageSpeed which rewrites .js
# files into _tdss-XXX.js, breaking minified JS syntax. Try EVERY possible
# directive to disable it.
<IfModule mod_pagespeed.c>
  ModPagespeed off
  ModPagespeedDisableFilters rewrite_javascript,rewrite_css,minify_js,minify_css,combine_javascript,combine_css,rewrite_images,lazyload_images,extend_cache
  ModPagespeedDisallow "*"
</IfModule>
<IfModule mod_pagespeed_apache>
  ModPagespeed off
  ModPagespeedDisallow "*"
</IfModule>

# Per-file PageSpeed disable (some hosts only respect this)
<FilesMatch "\.(js|mjs|css|woff2|woff|ttf|otf|png|jpg|jpeg|webp|svg|gif|ico|json)$">
  <IfModule mod_pagespeed.c>
    ModPagespeed off
  </IfModule>
  <IfModule mod_headers.c>
    Header set X-ModPagespeed "off"
    Header unset X-Page-Speed
    Header set Cache-Control "no-transform"
  </IfModule>
</FilesMatch>

# Disable directory listing
Options -Indexes

# Security: prevent MIME sniffing
<IfModule mod_headers.c>
  Header set X-Content-Type-Options "nosniff"
  Header set Referrer-Policy "no-referrer-when-downgrade"
</IfModule>

RewriteEngine On

# === ASSET INVARIANT ===
# Static asset requests (with a file extension) must NEVER resolve to an
# HTML route. If the file does not exist, return a real 404 — do NOT fall
# back to index.html. This prevents the ".mjs returns text/html" failure.
RewriteCond %{REQUEST_FILENAME} -f [OR]
RewriteCond %{REQUEST_FILENAME} -d
RewriteRule ^ - [L]

# Only apply clean-URL routing to extension-less paths (routes).
# /about → /about/index.html  (only if /about/ is a directory)
# /projects/matti → /projects/matti/index.html
RewriteCond %{REQUEST_FILENAME} !-f
RewriteCond %{REQUEST_FILENAME}/index.html -f
RewriteRule ^([^./]+(?:/[^./]+)*)$ $1/index.html [L]

# 404 fallback (custom error page)
ErrorDocument 404 /404.html

# Strict MIME types for other modern web assets
<IfModule mod_mime.c>
  AddType text/css .css
  AddType application/json .json
  AddType image/svg+xml .svg
  AddType image/webp .webp
  AddType image/png .png
  AddType image/jpeg .jpg .jpeg
  AddType image/gif .gif
  AddType image/x-icon .ico
  AddType image/avif .avif
  AddType font/woff2 .woff2
  AddType font/woff .woff
  AddType font/ttf .ttf
  AddType font/otf .otf
  AddType application/font-woff .woff
  AddType application/manifest+json .webmanifest
  AddType application/wasm .wasm
</IfModule>
`;
}

/** Generate the nginx.conf location snippet. */
export function nginxContent(): string {
  return `# YesCode — nginx configuration (location block).
# Drop inside server { } block.

location / {
  try_files $uri $uri/ $uri/index.html =404;
}

location ~ \\.(mjs|js)$ {
  default_type text/javascript;
  charset utf-8;
  add_header Cache-Control "public, max-age=31536000, immutable";
}

location ~ \\.css$ {
  default_type text/css;
  charset utf-8;
}

location ~ \\.(woff2|woff|ttf|otf)$ {
  add_header Cache-Control "public, max-age=31536000, immutable";
}

error_page 404 /404.html;
`;
}

/** Generate Netlify/Cloudflare Pages _redirects. */
export function redirectsContent(): string {
  return `# YesCode — Netlify / Cloudflare Pages redirects
# Clean URL mapping with 404 fallback.

/*  /:splat  200
`;
}

/** Generate a minimal 404 page so try_files doesn't crash. */
export function notFoundPageContent(origin: string): string {
  return `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>404 — Not Found</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body{font-family:ui-sans-serif,system-ui,-apple-system,Segoe UI,Roboto,sans-serif;background:#0a0a0a;color:#f4f4f4;display:flex;align-items:center;justify-content:center;min-height:100vh;margin:0;}
main{text-align:center;padding:2rem;}
h1{font-size:4rem;margin:0;background:linear-gradient(90deg,#f59e0b,#fb7185);-webkit-background-clip:text;background-clip:text;color:transparent;}
p{color:#a1a1aa;font-family:ui-monospace,SFMono-Regular,monospace;margin:1rem 0 2rem;}
a{color:#f59e0b;text-decoration:none;font-family:ui-monospace,monospace;border:1px solid #f59e0b;padding:.5rem 1rem;border-radius:6px;}
</style>
</head>
<body>
<main>
<h1>404</h1>
<p>The page you requested does not exist on this YesCode-exported site.</p>
<a href="/">← back to home</a>
</main>
</body>
</html>
<!-- origin: ${origin} -->
`;
}

/** Write the host config files into the output directory. */
export async function writeHostConfigs(
  outputDir: string,
  routes: DiscoveredRoute[],
  origin: string,
  logger: StructuredLogger,
): Promise<{ configFiles: string[] }> {
  const writes: Promise<void>[] = [];
  const paths: string[] = [];

  const write = async (relPath: string, content: string) => {
    const target = join(outputDir, relPath);
    await fs.mkdir(dirname(target), { recursive: true });
    await fs.writeFile(target, content, "utf8");
    paths.push(relPath);
  };

  writes.push(write(".htaccess", htaccessContent()));
  writes.push(write("nginx.conf", nginxContent()));
  writes.push(write("_redirects", redirectsContent()));
  writes.push(write("404.html", notFoundPageContent(origin)));

  await Promise.all(writes);
  logger.info(
    `Wrote ${paths.length} host config files`,
    { files: paths, routeCount: routes.length },
    "ROUTING",
  );
  return { configFiles: paths };
}
