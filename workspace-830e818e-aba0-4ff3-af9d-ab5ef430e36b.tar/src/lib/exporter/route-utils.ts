/**
 * YesCode — Route canonicalization & URL classification utilities.
 *
 * Per master prompt ROUTE CANONICALIZATION + INTERNAL URL CLASSIFICATION:
 *   - One central function normalizes /contact, /contact/, /contact/index.html
 *     into canonical route identity "/contact".
 *   - Separately maps route identity → disk path "/contact/index.html".
 *   - Internal URL classification: SAME_ORIGIN_ROUTE, SAME_ORIGIN_ASSET,
 *     EXTERNAL_URL, MAILTO, TEL, JAVASCRIPT, HASH, DATA, BLOB, UNKNOWN.
 *
 * Used consistently by: route discovery, HTML rewriting, sitemap, CMS route
 * generation, validation, NIT, ZIP generation.
 */

/** Canonical route identity: always starts with "/", no trailing slash,
 *  no /index.html suffix. Root is "/". */
export type RouteIdentity = string;

/** URL classification for rewriting decisions. */
export type UrlClass =
  | "SAME_ORIGIN_ROUTE"
  | "SAME_ORIGIN_ASSET"
  | "EXTERNAL_URL"
  | "MAILTO"
  | "TEL"
  | "JAVASCRIPT"
  | "HASH"
  | "DATA"
  | "BLOB"
  | "UNKNOWN";

const ASSET_EXTENSIONS = new Set([
  "js", "mjs", "cjs", "css", "json", "svg", "png", "jpg", "jpeg", "webp",
  "gif", "ico", "avif", "woff", "woff2", "ttf", "otf", "eot", "mp4",
  "webm", "mov", "avi", "mp3", "wav", "ogg", "pdf", "zip", "txt", "xml",
  "webmanifest", "map", "wasm", "bin",
]);

/**
 * Canonicalize a route path into a stable identity.
 *
 *   /contact          → /contact
 *   /contact/         → /contact
 *   /contact/index.html → /contact
 *   /                 → /
 *   /projects/matti/  → /projects/matti
 *
 * Preserves query strings and fragments via separate fields.
 */
export function canonicalizeRoute(pathOrUrl: string): {
  route: RouteIdentity;
  query: string;
  hash: string;
} {
  let p = pathOrUrl;
  let query = "";
  let hash = "";

  // Split off hash
  const hashIdx = p.indexOf("#");
  if (hashIdx >= 0) {
    hash = p.slice(hashIdx);
    p = p.slice(0, hashIdx);
  }
  // Split off query
  const queryIdx = p.indexOf("?");
  if (queryIdx >= 0) {
    query = p.slice(queryIdx);
    p = p.slice(0, queryIdx);
  }

  // Strip /index.html suffix
  p = p.replace(/\/index\.html$/i, "/");
  // Strip .html suffix
  p = p.replace(/\.html$/i, "/");
  // Ensure leading slash
  if (!p.startsWith("/")) p = "/" + p;
  // Strip trailing slash (except root)
  if (p.length > 1 && p.endsWith("/")) p = p.slice(0, -1);

  return { route: p || "/", query, hash };
}

/**
 * Map a canonical route identity to its disk path inside the export.
 *
 *   /            → index.html
 *   /about       → about/index.html
 *   /projects/matti → projects/matti/index.html
 */
export function routeToDiskPath(route: RouteIdentity): string {
  if (route === "/" || route === "") return "index.html";
  // Strip leading slash for relative disk path
  const clean = route.replace(/^\/+/, "");
  return `${clean}/index.html`;
}

/**
 * Map a canonical route identity to its web path (root-absolute, no trailing
 * slash except for root). This is what href attributes should contain.
 *
 *   /            → /
 *   /about       → /about
 *   /projects/matti → /projects/matti
 */
export function routeToWebPath(route: RouteIdentity): string {
  return route === "/" ? "/" : route;
}

/**
 * Classify a URL found in an HTML attribute (href, src, content, srcset).
 * Uses the target origin to distinguish same-origin routes from assets.
 */
export function classifyInternalUrl(
  raw: string,
  targetOrigin: string,
): UrlClass {
  if (!raw) return "UNKNOWN";
  const trimmed = raw.trim().toLowerCase();

  if (trimmed.startsWith("mailto:")) return "MAILTO";
  if (trimmed.startsWith("tel:")) return "TEL";
  if (trimmed.startsWith("javascript:")) return "JAVASCRIPT";
  if (trimmed.startsWith("data:")) return "DATA";
  if (trimmed.startsWith("blob:")) return "BLOB";
  if (trimmed.startsWith("#")) return "HASH";

  // Absolute URL → check if same origin
  if (/^https?:\/\//i.test(raw)) {
    try {
      const u = new URL(raw);
      const target = new URL(targetOrigin);
      if (u.origin === target.origin) {
        // Same origin — is it a route or an asset?
        const lastSegment = u.pathname.split("/").pop() ?? "";
        const dotIdx = lastSegment.lastIndexOf(".");
        const ext = dotIdx >= 0 ? lastSegment.slice(dotIdx + 1).toLowerCase() : "";
        if (ext && ASSET_EXTENSIONS.has(ext) && !u.pathname.endsWith("/index.html") && !u.pathname.endsWith(".html")) {
          return "SAME_ORIGIN_ASSET";
        }
        return "SAME_ORIGIN_ROUTE";
      }
      return "EXTERNAL_URL";
    } catch {
      return "UNKNOWN";
    }
  }

  // Root-relative or document-relative
  if (raw.startsWith("/") || raw.startsWith("./") || raw.startsWith("../") || !raw.includes("://")) {
    // It's a relative URL — determine if route or asset by extension
    const pathPart = raw.split("?")[0].split("#")[0];
    // Extract the last segment after the final "/" and check for extension
    const lastSegment = pathPart.split("/").pop() ?? "";
    const dotIdx = lastSegment.lastIndexOf(".");
    const ext = dotIdx >= 0 ? lastSegment.slice(dotIdx + 1).toLowerCase() : "";
    // Check if it's an asset extension (but not /index.html which is a route)
    if (ext && ASSET_EXTENSIONS.has(ext) && !pathPart.endsWith("/index.html") && !pathPart.endsWith(".html")) {
      return "SAME_ORIGIN_ASSET";
    }
    // No extension, or .html/.htm → route
    if (ext === "" || ext === "html" || ext === "htm") {
      return "SAME_ORIGIN_ROUTE";
    }
    // Unknown extension → treat as asset
    return "SAME_ORIGIN_ASSET";
  }

  return "UNKNOWN";
}

/**
 * Rewrite an internal route link to root-absolute form.
 *
 * Per master prompt FAILURE CLASS B:
 *   - /about/ page with link "contact" → must become "/contact" (not "contact"
 *     which would resolve to /about/contact).
 *   - Preserve query strings: /projects/matti?foo=bar → /projects/matti?foo=bar
 *   - Preserve fragments: /projects/matti#section → /projects/matti#section
 *   - Current page hash: #section → #section (unchanged)
 *
 * The `knownRoutes` set (optional) contains canonical route identities
 * discovered by the BFS crawl. When provided, a relative link like "contact"
 * is matched against knownRoutes to determine if it's a top-level route
 * (/contact) rather than a document-relative path (/about/contact).
 *
 * Returns the rewritten href, or null if the input is not a same-origin route.
 */
export function rewriteInternalRouteLink(
  raw: string,
  baseUrl: string,
  targetOrigin: string,
  knownRoutes?: Set<string>,
): string | null {
  if (!raw) return null;
  const cls = classifyInternalUrl(raw, targetOrigin);
  if (cls !== "SAME_ORIGIN_ROUTE") return null;

  // For root-relative links (/contact, /about) or absolute same-origin URLs,
  // resolve and canonicalize directly.
  if (raw.startsWith("/") || /^https?:\/\//i.test(raw)) {
    let absUrl: URL;
    try {
      absUrl = new URL(raw, baseUrl);
    } catch {
      return null;
    }
    const target = new URL(targetOrigin);
    if (absUrl.origin !== target.origin) return null;
    const { route } = canonicalizeRoute(absUrl.pathname);
    const webPath = routeToWebPath(route);
    // Preserve query + hash from the URL object (not from canonicalizeRoute,
    // which only processes pathname)
    let result = webPath;
    if (absUrl.search) result += absUrl.search;
    if (absUrl.hash) result += absUrl.hash;
    return result;
  }

  // For document-relative links (contact, ../about), check if the link
  // matches a known top-level route. If "contact" is in knownRoutes as
  // "/contact", emit "/contact" — NOT the document-relative resolution.
  if (knownRoutes && knownRoutes.size > 0) {
    // Try interpreting the link as a root-relative path
    const asRootPath = "/" + raw.replace(/^\.?\//, "").split("?")[0].split("#")[0];
    const { route: candidateRoute } = canonicalizeRoute(asRootPath);
    if (knownRoutes.has(candidateRoute)) {
      // Preserve query + hash from the original link
      let query = "";
      let hash = "";
      const qIdx = raw.indexOf("?");
      if (qIdx >= 0) {
        const afterQ = raw.slice(qIdx);
        const hIdx = afterQ.indexOf("#");
        query = hIdx >= 0 ? afterQ.slice(0, hIdx) : afterQ;
        hash = hIdx >= 0 ? afterQ.slice(hIdx) : "";
      } else {
        const hIdx = raw.indexOf("#");
        hash = hIdx >= 0 ? raw.slice(hIdx) : "";
      }
      let result = routeToWebPath(candidateRoute);
      if (query) result += query;
      if (hash) result += hash;
      return result;
    }
  }

  // Fall back to document-relative resolution (no knownRoutes match)
  let absUrl: URL;
  try {
    absUrl = new URL(raw, baseUrl);
  } catch {
    return null;
  }
  const target = new URL(targetOrigin);
  if (absUrl.origin !== target.origin) return null;
  const { route, query, hash } = canonicalizeRoute(absUrl.pathname);
  const webPath = routeToWebPath(route);
  let result = webPath;
  if (query) result += query;
  if (hash) result += hash;
  return result;
}

/**
 * Rewrite an asset reference to root-absolute form.
 *
 * Per master prompt FAILURE CLASS A + ASSET PATH STRATEGY:
 *   - All asset refs must be root-absolute: /assets/...
 *   - From /about/ page, /assets/js/main.mjs must stay /assets/js/main.mjs
 *     (NOT /about/assets/js/main.mjs)
 *
 * Returns the rewritten URL (root-absolute), or null if not a same-origin asset.
 */
export function rewriteAssetRef(
  raw: string,
  baseUrl: string,
  targetOrigin: string,
  localPath?: string | null,
): string | null {
  if (!raw) return null;
  const cls = classifyInternalUrl(raw, targetOrigin);
  if (cls !== "SAME_ORIGIN_ASSET") return null;

  // If we have a localized path from the resource graph, use it
  if (localPath) {
    return "/" + localPath.replace(/^\/+/, "");
  }

  // Otherwise, resolve to root-absolute
  try {
    const abs = new URL(raw, baseUrl);
    const target = new URL(targetOrigin);
    if (abs.origin === target.origin) {
      return abs.pathname + (abs.search || "") + (abs.hash || "");
    }
  } catch {
    // fall through
  }
  return null;
}
