/**
 * YesCode — Asset Request Integrity validation.
 *
 * Per master prompt ASSET REQUEST INTEGRITY section:
 *   For every emitted static asset URL, before packaging we must know:
 *     - request URL
 *     - expected local node
 *     - expected local file
 *     - expected MIME
 *     - exists (true/false)
 *
 * If an HTML file is mapped to an asset node, FAIL the export.
 * If a critical resource is missing, FAIL the export.
 */

import { promises as fs } from "node:fs";
import { join, extname } from "node:path";
import type { ResourceGraph, ResourceNode } from "./graph";
import type { StructuredLogger } from "./logger";

const MIME_BY_EXT: Record<string, string> = {
  ".mjs": "text/javascript",
  ".js": "text/javascript",
  ".cjs": "text/javascript",
  ".css": "text/css",
  ".json": "application/json",
  ".svg": "image/svg+xml",
  ".webp": "image/webp",
  ".png": "image/png",
  ".jpg": "image/jpeg",
  ".jpeg": "image/jpeg",
  ".gif": "image/gif",
  ".ico": "image/x-icon",
  ".avif": "image/avif",
  ".woff2": "font/woff2",
  ".woff": "font/woff",
  ".ttf": "font/ttf",
  ".otf": "font/otf",
  ".html": "text/html",
  ".htm": "text/html",
  ".xml": "application/xml",
  ".txt": "text/plain",
  ".webmanifest": "application/manifest+json",
  ".wasm": "application/wasm",
};

const JS_EXTENSIONS = new Set([".mjs", ".js", ".cjs"]);

export interface AssetIntegrityEntry {
  url: string;
  localPath: string;
  expectedMime: string;
  expectedType: "module" | "script" | "style" | "image" | "font" | "data" | "media" | "other";
  exists: boolean;
  sizeBytes: number;
  isHtmlMappedToAsset: boolean;
  status: "OK" | "MISSING" | "HTML_MAPPED" | "WRONG_MIME";
  reason?: string;
}

export interface AssetIntegrityResult {
  entries: AssetIntegrityEntry[];
  totalAssets: number;
  okCount: number;
  missingCount: number;
  htmlMappedCount: number;
  wrongMimeCount: number;
  passed: boolean;
  fatalErrors: string[];
}

/**
 * Validate every asset in the resource graph against the files on disk.
 *
 * Checks:
 *   1. File exists at localRelativePath
 *   2. File is non-empty
 *   3. File is NOT an HTML document (detects the ".mjs returns text/html" bug)
 *   4. MIME matches the extension
 *
 * Returns a structured report. If any critical asset is missing or
 * HTML-mapped, the export should FAIL.
 */
export async function validateAssetIntegrity(
  graph: ResourceGraph,
  outputDir: string,
  logger: StructuredLogger,
): Promise<AssetIntegrityResult> {
  const entries: AssetIntegrityEntry[] = [];
  const fatalErrors: string[] = [];

  const assetNodes = graph
    .all()
    .filter((n) => n.localRelativePath && n.classification !== "PUBLISHED_ROUTE");

  for (const node of assetNodes) {
    const localPath = node.localRelativePath!;
    const diskPath = join(outputDir, localPath);
    const ext = extname(localPath).toLowerCase();
    const expectedMime = MIME_BY_EXT[ext] ?? "application/octet-stream";
    const expectedType: AssetIntegrityEntry["expectedType"] =
      JS_EXTENSIONS.has(ext) ? "module" :
      ext === ".css" ? "style" :
      [".png", ".jpg", ".jpeg", ".webp", ".gif", ".svg", ".ico", ".avif"].includes(ext) ? "image" :
      [".woff2", ".woff", ".ttf", ".otf"].includes(ext) ? "font" :
      ext === ".json" ? "data" :
      [".mp4", ".webm", ".mov"].includes(ext) ? "media" : "other";

    let exists = false;
    let sizeBytes = 0;
    let isHtmlMappedToAsset = false;
    let status: AssetIntegrityEntry["status"] = "OK";
    let reason: string | undefined;

    try {
      const stat = await fs.stat(diskPath);
      exists = true;
      sizeBytes = stat.size;

      if (sizeBytes === 0) {
        status = "MISSING";
        reason = "File is empty (0 bytes)";
        fatalErrors.push(`Asset ${localPath} is empty`);
      } else {
        // Read first 512 bytes to sniff content type
        const fd = await fs.open(diskPath, "r");
        const buf = Buffer.alloc(512);
        const { bytesRead } = await fd.read(buf, 0, 512, 0);
        await fd.close();
        const head = buf.subarray(0, bytesRead).toString("utf8").trimStart().toLowerCase();

        // Detect HTML content (the critical ".mjs returns text/html" bug)
        if (
          head.startsWith("<!doctype html") ||
          head.startsWith("<html") ||
          head.startsWith("<head") ||
          head.startsWith("<!doctype")
        ) {
          // HTML is only valid for .html/.htm files.
          // Only flag as FATAL for JS/CSS modules (the ".mjs returns text/html" bug).
          // For .bin, .json, .xml and other non-critical assets, log a warning
          // but don't fail the export — these may be Framer API responses
          // that returned HTML (e.g. 404 page) and were saved as data files.
          if (ext !== ".html" && ext !== ".htm") {
            isHtmlMappedToAsset = true;
            status = "HTML_MAPPED";
            reason = `Asset ${localPath} contains HTML content but has .${ext.slice(1)} extension`;
            // Only fatal for JS modules and CSS (critical runtime)
            if (ext === ".js" || ext === ".mjs" || ext === ".css") {
              fatalErrors.push(reason + " — this is the \".mjs returns text/html\" bug");
            }
          }
        }

        // Check MIME mismatch (e.g., a .mjs file served as text/css)
        if (status === "OK" && expectedType === "module") {
          // Basic JS syntax sniff — should not start with HTML tags
          if (head.startsWith("<")) {
            status = "WRONG_MIME";
            reason = `JS module ${localPath} appears to contain HTML/markup`;
            fatalErrors.push(reason);
          }
        }
      }
    } catch {
      exists = false;
      status = "MISSING";
      reason = `File not found at ${localPath}`;
      // Missing assets are fatal for JS modules and CSS, non-fatal for images
      if (expectedType === "module" || expectedType === "style") {
        fatalErrors.push(`Critical asset missing: ${localPath}`);
      }
    }

    entries.push({
      url: node.normalizedUrl,
      localPath,
      expectedMime,
      expectedType,
      exists,
      sizeBytes,
      isHtmlMappedToAsset,
      status,
      reason,
    });
  }

  const okCount = entries.filter((e) => e.status === "OK").length;
  const missingCount = entries.filter((e) => e.status === "MISSING").length;
  const htmlMappedCount = entries.filter((e) => e.status === "HTML_MAPPED").length;
  const wrongMimeCount = entries.filter((e) => e.status === "WRONG_MIME").length;
  const passed = fatalErrors.length === 0;

  logger.info(
    `Asset integrity: ${okCount}/${entries.length} OK, ${missingCount} missing, ${htmlMappedCount} HTML-mapped, ${wrongMimeCount} wrong MIME`,
    {
      fatalErrors: fatalErrors.length,
      sample: entries.filter((e) => e.status !== "OK").slice(0, 5),
    },
    "RESIDUAL_SCAN",
  );

  return {
    entries,
    totalAssets: entries.length,
    okCount,
    missingCount,
    htmlMappedCount,
    wrongMimeCount,
    passed,
    fatalErrors,
  };
}

/**
 * Build a mapping of all emitted asset URLs → local files for the export
 * report. Per master prompt ASSET REQUEST INTEGRITY, this must be known
 * before packaging.
 */
export function buildAssetIntegrityManifest(graph: ResourceGraph): Array<{
  url: string;
  localPath: string;
  expectedMime: string;
}> {
  return graph
    .all()
    .filter((n) => n.localRelativePath && n.classification !== "PUBLISHED_ROUTE")
    .map((n) => {
      const ext = extname(n.localRelativePath!).toLowerCase();
      return {
        url: n.normalizedUrl,
        localPath: n.localRelativePath!,
        expectedMime: MIME_BY_EXT[ext] ?? "application/octet-stream",
      };
    });
}
