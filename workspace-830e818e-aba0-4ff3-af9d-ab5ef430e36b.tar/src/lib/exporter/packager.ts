/**
 * YesCode — Deterministic ZIP packaging.
 *
 * Per rules.md ACCEPTANCE CRITERIA:
 *   - Output ZIP is named deterministically: <site-subdomain>-yescode.zip
 *   - All host configs (nginx.conf, .htaccess, _redirects, 404.html)
 *     included at the archive root.
 *
 * Uses archiver (no shell-out to zip(1)) and sorts entries for
 * deterministic byte output.
 */

import { ZipArchive } from "archiver";
import { createWriteStream, promises as fs } from "node:fs";
import { join } from "node:path";
import type { StructuredLogger } from "./logger";
import { assertSafeArchivePath } from "./security";

/** Derive the site subdomain from a URL — used for the deterministic zip name. */
export function deriveZipName(targetUrl: string): string {
  try {
    const u = new URL(targetUrl);
    let host = u.hostname;
    // Strip the leading "www." for cleanliness
    if (host.startsWith("www.")) host = host.slice(4);
    // Replace dots with dashes for a single-token file name component
    const safe = host.replace(/[^a-z0-9.-]/gi, "-").replace(/^-+|-+$/g, "").toLowerCase();
    return `${safe || "site"}-yescode.zip`;
  } catch {
    return "site-yescode.zip";
  }
}

/** Walk a directory tree and return a sorted, DEDUPLICATED list of entries.
 *  Multiple graph passes + materialize can write the same file multiple times
 *  to the same path. The filesystem only keeps the last write, but archiver
 *  may add duplicate entries if the same path appears multiple times. We
 *  deduplicate by relative path, keeping only the first (or last) occurrence. */
async function collectEntries(rootDir: string): Promise<{ rel: string; abs: string; isDir: boolean }[]> {
  const out: { rel: string; abs: string; isDir: boolean }[] = [];
  const seen = new Set<string>();
  async function walk(dir: string) {
    const entries = await fs.readdir(dir, { withFileTypes: true });
    for (const e of entries) {
      const abs = join(dir, e.name);
      const rel = abs.slice(rootDir.length + 1).replace(/\\/g, "/");
      if (e.isDirectory()) {
        const dirKey = rel + "/";
        if (!seen.has(dirKey)) {
          seen.add(dirKey);
          out.push({ rel: dirKey, abs, isDir: true });
        }
        await walk(abs);
      } else if (e.isFile()) {
        if (!seen.has(rel)) {
          seen.add(rel);
          out.push({ rel, abs, isDir: false });
        }
      }
    }
  }
  await walk(rootDir);
  // Sort for determinism — directories first then files, both alphabetical
  out.sort((a, b) => {
    if (a.isDir !== b.isDir) return a.isDir ? -1 : 1;
    return a.rel < b.rel ? -1 : a.rel > b.rel ? 1 : 0;
  });
  return out;
}

/** Create a deterministic ZIP archive of the output directory. */
export async function packageZip(
  outputDir: string,
  zipName: string,
  logger: StructuredLogger,
  downloadDir: string,
): Promise<{ zipPath: string; sizeBytes: number; entryCount: number }> {
  await fs.mkdir(downloadDir, { recursive: true });
  const zipPath = join(downloadDir, zipName);
  const entries = await collectEntries(outputDir);
  let entryCount = 0;

  await new Promise<void>((resolve, reject) => {
    const output = createWriteStream(zipPath);
    const archive = new ZipArchive({ zlib: { level: 6 } });
    output.on("close", () => resolve());
    output.on("error", reject);
    archive.on("error", reject);
    archive.on("warning", (err: unknown) => {
      // archiver emits warnings for non-fatal issues
      logger.warn(`archiver warning: ${err instanceof Error ? err.message : String(err)}`, undefined, "PACKAGING");
    });
    archive.pipe(output);

    for (const e of entries) {
      // Skip directories — archiver creates them automatically from file paths
      if (e.isDir) continue;
      // Zip slip prevention
      try {
        assertSafeArchivePath(e.rel);
      } catch {
        logger.warn(`Skipping unsafe archive path: ${e.rel}`, undefined, "PACKAGING");
        continue;
      }
      archive.file(e.abs, { name: e.rel });
      entryCount++;
    }
    void archive.finalize();
  });

  const stat = await fs.stat(zipPath);
  logger.info(
    `Packaged ${entryCount} file(s) into ${zipName} (${stat.size} bytes)`,
    undefined,
    "PACKAGING",
  );
  return { zipPath, sizeBytes: stat.size, entryCount };
}
