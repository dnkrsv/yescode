/**
 * YesCode — in-memory Resource Dependency Graph.
 *
 * Per rules.md RESOURCE GRAPH section: directed graph with SHA-256 node IDs,
 * 12-variant classification, state transitions, and edge typing. Supports
 * cycle detection and topological sort for rewriting order.
 */

import { createHash } from "node:crypto";
import type { UrlClassification } from "./classifier";

export type NodeState =
  | "DISCOVERED"
  | "DOWNLOADING"
  | "DOWNLOADED"
  | "REWRITING"
  | "COMPLETED"
  | "FAILED";

export type EdgeType =
  | "STATIC_IMPORT"
  | "DYNAMIC_IMPORT"
  | "CSS_URL"
  | "HTML_SRC"
  | "FETCH";

export interface ResourceNode {
  id: string;
  originalUrl: string;
  normalizedUrl: string;
  classification: UrlClassification;
  contentType: string | null;
  httpStatus: number | null;
  localRelativePath: string | null;
  diskPath: string | null;
  initiatorUrl: string | null;
  sizeBytes: number;
  state: NodeState;
  /** Raw bytes of downloaded content (kept in-memory for assets < 8 MB). */
  body: Buffer | null;
}

export interface ResourceEdge {
  fromId: string;
  toId: string;
  type: EdgeType;
}

export class ResourceGraph {
  private nodes = new Map<string, ResourceNode>();
  private edges: ResourceEdge[] = [];
  private readonly maxInMemoryBytes = 8 * 1024 * 1024;

  /** SHA-256 of normalized URL (first 12 hex chars), per rules.md. */
  static nodeIdFor(normalizedUrl: string): string {
    return createHash("sha256").update(normalizedUrl).digest("hex").slice(0, 12);
  }

  /** Get or create a node for a normalized URL. Returns the node. */
  upsert(args: {
    originalUrl: string;
    normalizedUrl: string;
    classification: UrlClassification;
    initiatorUrl?: string | null;
    contentType?: string | null;
    httpStatus?: number | null;
  }): ResourceNode {
    const id = ResourceGraph.nodeIdFor(args.normalizedUrl);
    let node = this.nodes.get(id);
    if (node) {
      // Merge missing metadata
      if (args.initiatorUrl && !node.initiatorUrl) node.initiatorUrl = args.initiatorUrl;
      if (args.contentType && !node.contentType) node.contentType = args.contentType;
      if (args.httpStatus != null && node.httpStatus == null) node.httpStatus = args.httpStatus;
      return node;
    }
    node = {
      id,
      originalUrl: args.originalUrl,
      normalizedUrl: args.normalizedUrl,
      classification: args.classification,
      contentType: args.contentType ?? null,
      httpStatus: args.httpStatus ?? null,
      localRelativePath: null,
      diskPath: null,
      initiatorUrl: args.initiatorUrl ?? null,
      sizeBytes: 0,
      state: "DISCOVERED",
      body: null,
    };
    this.nodes.set(id, node);
    return node;
  }

  getNode(id: string): ResourceNode | undefined {
    return this.nodes.get(id);
  }

  getByUrl(normalizedUrl: string): ResourceNode | undefined {
    return this.nodes.get(ResourceGraph.nodeIdFor(normalizedUrl));
  }

  addEdge(fromId: string, toId: string, type: EdgeType): void {
    // Avoid duplicates
    const exists = this.edges.some(
      (e) => e.fromId === fromId && e.toId === toId && e.type === type,
    );
    if (!exists) this.edges.push({ fromId, toId, type });
  }

  /** Update a node's state and content. */
  update(
    id: string,
    patch: Partial<
      Pick<
        ResourceNode,
        | "state"
        | "body"
        | "sizeBytes"
        | "contentType"
        | "httpStatus"
        | "localRelativePath"
        | "diskPath"
      >
    >,
  ): ResourceNode | undefined {
    const node = this.nodes.get(id);
    if (!node) return undefined;
    if (patch.state) node.state = patch.state;
    if (patch.body !== undefined) {
      if (patch.body && patch.body.length <= this.maxInMemoryBytes) {
        node.body = patch.body;
      }
      if (patch.body) node.sizeBytes = patch.body.length;
    }
    if (patch.sizeBytes != null) node.sizeBytes = patch.sizeBytes;
    if (patch.contentType != null) node.contentType = patch.contentType;
    if (patch.httpStatus != null) node.httpStatus = patch.httpStatus;
    if (patch.localRelativePath != null) node.localRelativePath = patch.localRelativePath;
    if (patch.diskPath != null) node.diskPath = patch.diskPath;
    return node;
  }

  /** All nodes as an array. */
  all(): ResourceNode[] {
    return [...this.nodes.values()];
  }

  /** Nodes matching a classification. */
  byClassification(c: UrlClassification): ResourceNode[] {
    return this.all().filter((n) => n.classification === c);
  }

  /** Outgoing edges of a node. */
  outgoing(id: string): ResourceEdge[] {
    return this.edges.filter((e) => e.fromId === id);
  }

  /**
   * Topological sort for rewriting order. Cycles tolerated — nodes in a cycle
   * are returned in arbitrary order at the end.
   */
  topologicalSort(): ResourceNode[] {
    const inDegree = new Map<string, number>();
    for (const n of this.nodes.values()) inDegree.set(n.id, 0);
    for (const e of this.edges) {
      inDegree.set(e.toId, (inDegree.get(e.toId) ?? 0) + 1);
    }
    const queue: string[] = [];
    for (const [id, deg] of inDegree) if (deg === 0) queue.push(id);
    const order: ResourceNode[] = [];
    while (queue.length) {
      const id = queue.shift()!;
      const n = this.nodes.get(id);
      if (n) order.push(n);
      for (const e of this.edges) {
        if (e.fromId === id) {
          inDegree.set(e.toId, (inDegree.get(e.toId) ?? 1) - 1);
          if (inDegree.get(e.toId) === 0) queue.push(e.toId);
        }
      }
    }
    // Cycle nodes — append at end
    for (const n of this.nodes.values()) {
      if (!order.find((o) => o.id === n.id)) order.push(n);
    }
    return order;
  }

  /** Simple statistics used by UI/metrics. */
  stats(): {
    total: number;
    downloaded: number;
    completed: number;
    failed: number;
    totalSizeBytes: number;
  } {
    let downloaded = 0,
      completed = 0,
      failed = 0,
      totalSize = 0;
    for (const n of this.nodes.values()) {
      if (n.state === "DOWNLOADED" || n.state === "COMPLETED") downloaded++;
      if (n.state === "COMPLETED") completed++;
      if (n.state === "FAILED") failed++;
      totalSize += n.sizeBytes;
    }
    return {
      total: this.nodes.size,
      downloaded,
      completed,
      failed,
      totalSizeBytes: totalSize,
    };
  }
}
