/**
 * YesCode — CSS token-level rewriter (PostCSS + postcss-value-parser).
 *
 * Per rules.md CSS REWRITING section:
 *   - Parse all @import rules and rewrite to local CSS paths.
 *   - Traverse all url(...) declarations (fonts, background images, masks).
 *   - Resolve path relative to the CSS file's output directory.
 *
 * Maintains a tiny postcss plugin that walks declarations & at-rules.
 */

import postcss, { type Plugin } from "postcss";
import valueParser from "postcss-value-parser";
import type { ResourceGraph } from "../graph";
import { normalizeUrl, resolveUrl } from "../capture";
import { classifyUrl, shouldStrip, type ClassifyContext } from "../classifier";

export interface CssRewriteResult {
  css: string;
  rewrittenUrls: number;
  rewrittenImports: number;
}

interface CssRewriteOptions {
  /** Absolute base URL the CSS file was originally served from. */
  baseUrl: string;
  ctx: ClassifyContext;
  graph: ResourceGraph;
}

/**
 * Rewrite a downloaded CSS file's url() and @import tokens against the
 * resource graph. Returns the new CSS and counts.
 */
export async function rewriteCss(
  css: string,
  opts: CssRewriteOptions,
): Promise<CssRewriteResult> {
  let rewrittenUrls = 0;
  let rewrittenImports = 0;

  const plugin: Plugin = {
    postcssPlugin: "yescode-css-rewriter",
    AtRule: {
      import(rule) {
        // @import "url"; or @import url(...);
        const params = rule.params;
        // Strip "url()" wrapper if present
        const match = params.match(/^(?:url\(\s*)?["']?([^"')]+)["']?\s*\)?\s*(.*)$/);
        if (!match) return;
        const raw = match[1];
        if (!raw) return;
        const abs = resolveUrl(raw, opts.baseUrl);
        if (!abs) return;
        const normalized = normalizeUrl(abs);
        const c = classifyUrl(raw, opts.ctx);
        if (c === "INFORMATIONAL_STRING" || c === "LOCAL_RESOURCE") return;
        if (shouldStrip(c)) {
          rule.remove();
          return;
        }
        const node = opts.graph.getByUrl(normalized);
        if (node && node.localRelativePath) {
          const local = "/" + node.localRelativePath.replace(/^\/+/, "");
          rule.params = `"${local}" ${match[2] ?? ""}`.trim();
          rewrittenImports++;
        }
      },
    },
    Declaration(decl) {
      // Skip declarations that obviously have no url()
      if (!/url\(/i.test(decl.value)) return;
      const parsed = valueParser(decl.value);
      parsed.walk((node) => {
        if (node.type !== "function" || node.value !== "url") return;
        const arg = node.nodes[0];
        if (!arg || arg.type !== "word" && arg.type !== "string") return;
        const raw = arg.type === "string" ? arg.value : (arg as { value: string }).value;
        if (!raw) return;
        const abs = resolveUrl(raw, opts.baseUrl);
        if (!abs) return;
        const normalized = normalizeUrl(abs);
        const c = classifyUrl(raw, opts.ctx);
        if (c === "INFORMATIONAL_STRING" || c === "LOCAL_RESOURCE") return;
        if (shouldStrip(c)) {
          // Replace with empty
          arg.value = "";
          rewrittenUrls++;
          return;
        }
        const assetNode = opts.graph.getByUrl(normalized);
        if (assetNode && assetNode.localRelativePath) {
          const local = "/" + assetNode.localRelativePath.replace(/^\/+/, "");
          arg.value = local;
          rewrittenUrls++;
        }
      });
      decl.value = parsed.toString();
    },
  };

  const result = await postcss([plugin]).process(css, { from: undefined });
  return {
    css: result.css,
    rewrittenUrls,
    rewrittenImports,
  };
}
