/**
 * YesCode — JavaScript AST module rewriter.
 *
 * Per rules.md JS DEPENDENCY RESOLVER & AST ENGINE section:
 *   - Parser: es-module-lexer for fast scanning of imports/exports.
 *   - Rewriter: magic-string for surgical replacements at character offsets.
 *   - Static imports → rewrite specifier to local relative path.
 *   - Dynamic imports → locate ImportExpression, extract target, rewrite.
 *   - Asset literals → strings matching framerusercontent.com image paths
 *     are registered in the graph and rewritten to local paths.
 *   - Informational strings (SVG namespaces, React display names) are NOT
 *     rewritten.
 *
 * NO blind regex. es-module-lexer gives accurate import offsets; magic-string
 * performs offset-accurate replacements preserving source map fidelity.
 */

import MagicString from "magic-string";
import { parse as babelParse } from "@babel/parser";
import { load as cheerioLoad } from "cheerio";
import type { ResourceGraph } from "../graph";
import { normalizeUrl, resolveUrl } from "../capture";
import { classifyUrl, shouldStrip, type ClassifyContext } from "../classifier";
import type { StructuredLogger } from "../logger";

export interface JsRewriteResult {
  code: string;
  rewrittenStaticImports: number;
  rewrittenDynamicImports: number;
  rewrittenAssetLiterals: number;
  parseErrors: number;
}

interface JsRewriteOptions {
  /** Absolute base URL the JS module was originally served from. */
  baseUrl: string;
  ctx: ClassifyContext;
  graph: ResourceGraph;
  logger?: StructuredLogger;
}

/**
 * Returns true if `s` is an SVG/XML namespace or other informational string
 * that must not be rewritten (per rules.md INFORMATIONAL_STRING invariant).
 */
function isInformationalString(s: string): boolean {
  return (
    s.startsWith("http://www.w3.org/") ||
    s.startsWith("https://www.w3.org/") ||
    s.startsWith("http://schema.org") ||
    s.startsWith("https://schema.org") ||
    s.startsWith("http://www.opengis.net") ||
    s.startsWith("http://www.mozilla.org") ||
    s.startsWith("http://example.com") ||
    s.startsWith("http://example.org") ||
    s.startsWith("http://purl.org")
  );
}

/** Walk a Babel AST and rewrite import() dynamic calls + string literals. */
async function rewriteWithBabel(
  code: string,
  ms: MagicString,
  opts: JsRewriteOptions,
  counters: JsRewriteResult,
): Promise<void> {
  let ast: ReturnType<typeof babelParse> | null = null;
  try {
    ast = babelParse(code, {
      sourceType: "unambiguous",
      allowReturnOutsideFunction: true,
      allowAwaitOutsideFunction: true,
      plugins: [
        "jsx",
        "objectRestSpread",
        "optionalChaining",
        "nullishCoalescingOperator",
        "asyncGenerators",
        "classProperties",
        "dynamicImport",
        "importMeta",
        "exportDefaultFrom",
        "logicalAssignment",
        "numericSeparator",
        "topLevelAwait",
        "typescript",
      ],
    });
  } catch (err) {
    counters.parseErrors++;
    opts.logger?.warn("Babel parse failed", {
      error: err instanceof Error ? err.message.slice(0, 200) : String(err),
    });
    return;
  }

  function visit(node: unknown, parent?: unknown): void {
    if (!node || typeof node !== "object") return;
    const n = node as { type?: string; [key: string]: unknown };

    // Dynamic import: ImportExpression
    // Handles BOTH StringLiteral import("...") and TemplateLiteral import(`...`)
    if (n.type === "ImportExpression") {
      const source = n.source as { type?: string; value?: string; start?: number; end?: number; quasis?: Array<{ value?: { cooked?: string; raw?: string }; start?: number; end?: number }> } | undefined;
      if (!source || typeof source.start !== "number" || typeof source.end !== "number") {
        // recurse
      } else if (source.type === "StringLiteral" && source.value) {
        // Regular string: import("./foo.mjs")
        const specifier = source.value;
        if (!isInformationalString(specifier)) {
          const abs = resolveUrl(specifier, opts.baseUrl);
          if (abs) {
            const normalized = normalizeUrl(abs);
            const c = classifyUrl(abs, opts.ctx);
            if (c !== "INFORMATIONAL_STRING") {
              if (shouldStrip(c)) {
                // Framer editor/telemetry — replace with a no-op module
                // Using "data:text/javascript,export default function(){}" 
                // instead of "" which causes "bare specifier" error
                ms.overwrite(source.start, source.end, "\"data:text/javascript,export default function(){return{}}\"");
                counters.rewrittenDynamicImports++;
              } else {
                const node2 = opts.graph.getByUrl(normalized);
                if (node2 && node2.localRelativePath) {
                  const local = "/" + node2.localRelativePath.replace(/^\/+/, "");
                  ms.overwrite(source.start, source.end, JSON.stringify(local));
                  counters.rewrittenDynamicImports++;
                }
              }
            }
          }
        }
      } else if (source.type === "TemplateLiteral" && Array.isArray(source.quasis) && source.quasis.length === 1) {
        // Template literal with no expressions: import(`./foo.mjs`)
        const quasi = source.quasis[0];
        const specifier = quasi.value?.cooked ?? quasi.value?.raw ?? "";
        if (specifier && !isInformationalString(specifier)) {
          const abs = resolveUrl(specifier, opts.baseUrl);
          if (abs) {
            const normalized = normalizeUrl(abs);
            const c = classifyUrl(abs, opts.ctx);
            if (c !== "INFORMATIONAL_STRING") {
              if (shouldStrip(c)) {
                // Framer editor/telemetry — replace with a no-op module
                // Using "data:text/javascript,export default function(){}" 
                // instead of "" which causes "bare specifier" error
                ms.overwrite(source.start, source.end, "\"data:text/javascript,export default function(){return{}}\"");
                counters.rewrittenDynamicImports++;
              } else {
                const node2 = opts.graph.getByUrl(normalized);
                if (node2 && node2.localRelativePath) {
                  const local = "/" + node2.localRelativePath.replace(/^\/+/, "");
                  // Replace the entire template literal with a regular string
                  ms.overwrite(source.start, source.end, JSON.stringify(local));
                  counters.rewrittenDynamicImports++;
                }
              }
            }
          }
        }
      }
    }

    // StringLiteral OR TemplateLiteral containing ANY Framer host URL
    // (critical bug fix #3). Catches framerusercontent.com/* (all paths),
    // framer.com/*, framer.ai/*, framer.app/* — with or without https://.
    // Handles both regular strings ("...") and template literals (`...`).
    const isFramerLiteral =
      (n.type === "StringLiteral" || n.type === "TemplateLiteral") &&
      typeof n.start === "number" &&
      typeof n.end === "number";
    if (isFramerLiteral) {
      // Extract the raw text from the node
      const rawText = code.slice(n.start!, n.end!);
      // Check if it contains a Framer host URL
      if (/(?:framerusercontent\.com|framer\.(?:com|ai|app))/i.test(rawText) &&
          !(parent && (parent as { type?: string }).type === "ImportExpression" && (parent as { source?: unknown }).source === node)) {
        // For StringLiteral, use .value; for TemplateLiteral, extract from quasis
        let value: string | null = null;
        if (n.type === "StringLiteral" && typeof n.value === "string") {
          value = n.value;
        } else if (n.type === "TemplateLiteral" && Array.isArray((n as { quasis?: Array<{ value?: { raw?: string; cooked?: string } }> }).quasis)) {
          // TemplateLiteral: concatenate all quasi cooked values
          const quasis = (n as { quasis: Array<{ value?: { raw?: string; cooked?: string } }> }).quasis;
          value = quasis.map((q) => q.value?.cooked ?? q.value?.raw ?? "").join("");
        }
        if (value && !isInformationalString(value)) {
          const abs = resolveUrl(value, opts.baseUrl);
          if (abs) {
            const normalized = normalizeUrl(abs);
            const c = classifyUrl(abs, opts.ctx);
            if (c !== "INFORMATIONAL_STRING") {
              if (shouldStrip(c)) {
                // FRAMER_EDITOR, FRAMER_TELEMETRY, FRAMER_BOOTSTRAP — neutralize
                // to empty string so no runtime call to Framer infrastructure.
                ms.overwrite(n.start!, n.end!, JSON.stringify("data:text/javascript,"));
                counters.rewrittenAssetLiterals++;
              } else {
                // FRAMER_ASSET, FRAMER_RUNTIME, THIRD_PARTY_STATIC_ASSET — localize
                const node2 = opts.graph.getByUrl(normalized);
                if (node2 && node2.localRelativePath) {
                  const local = "/" + node2.localRelativePath.replace(/^\/+/, "");
                  ms.overwrite(n.start!, n.end!, JSON.stringify(local));
                  counters.rewrittenAssetLiterals++;
                } else {
                  // Not in graph — neutralize
                  ms.overwrite(n.start!, n.end!, JSON.stringify(""));
                  counters.rewrittenAssetLiterals++;
                }
              }
            }
          }
        }
      }
    }

    // Recurse into children
    for (const key of Object.keys(n)) {
      if (key === "loc" || key === "start" || key === "end" || key === "range" || key === "leadingComments" || key === "trailingComments") continue;
      const child = (n as Record<string, unknown>)[key];
      if (Array.isArray(child)) {
        for (const c of child) {
          if (c && typeof c === "object") visit(c, node);
        }
      } else if (child && typeof child === "object") {
        visit(child, node);
      }
    }
  }

  visit(ast as unknown);
}

/** Walk inline-style HTML/CSS-like mask-image url() tokens inside a JS string. */
function rewriteInlineCssInJsString(
  raw: string,
  opts: JsRewriteOptions,
): { value: string; hits: number } {
  let hits = 0;
  const out = raw.replace(
    /url\(\s*(?:"([^"]*)"|'([^']*)'|([^)\s]+))\s*\)/gi,
    (m, q1, q2, q3) => {
      const u = q1 ?? q2 ?? q3;
      if (!u) return m;
      if (isInformationalString(u)) return m;
      const abs = resolveUrl(u, opts.baseUrl);
      if (!abs) return m;
      const normalized = normalizeUrl(abs);
      const c = classifyUrl(u, opts.ctx);
      if (c === "INFORMATIONAL_STRING" || c === "LOCAL_RESOURCE") return m;
      if (shouldStrip(c)) return "url('')";
      const node = opts.graph.getByUrl(normalized);
      if (node && node.localRelativePath) {
        const local = "/" + node.localRelativePath.replace(/^\/+/, "");
        hits++;
        return `url("${local}")`;
      }
      return m;
    },
  );
  return { value: out, hits };
}

/**
 * Rewrite a downloaded JS module. Combines es-module-lexer (fast) for static
 * imports with @babel/parser (full AST) for dynamic imports and asset literals.
 */
export async function rewriteJs(
  code: string,
  opts: JsRewriteOptions,
): Promise<JsRewriteResult> {
  const ms = new MagicString(code);
  const counters: JsRewriteResult = {
    code: "",
    rewrittenStaticImports: 0,
    rewrittenDynamicImports: 0,
    rewrittenAssetLiterals: 0,
    parseErrors: 0,
  };

  // Phase 1: es-module-lexer — fast & accurate for static + dynamic imports
  // NOTE: es-module-lexer v1.5+ uses `start`/`end`/`type`/`specifier` fields.
  // Older versions used `s`/`e`/`d` fields. We support both for compatibility.
  // CRITICAL: Skip "import-meta" type — import.meta.url must NOT be rewritten.
  // It's a browser built-in that resolves to the full URL of the current module.
  // Replacing it with a root-relative path breaks new URL("./foo", import.meta.url).
  try {
    const mod = await import("es-module-lexer");
    const result = mod.parse(code);
    const imports = result[0];
    for (const imp of imports) {
      // Support both old (s/e/d) and new (start/end/type/specifier) API
      const s = imp.s ?? imp.start;
      const e = imp.e ?? imp.end;
      const impType = imp.type ?? (imp.d !== undefined ? (imp.d > -1 ? "dynamic" : "static") : "static");
      // SKIP import-meta — don't touch import.meta.url
      if (impType === "import-meta") continue;
      const isDynamic = impType === "dynamic";
      // Use pre-extracted specifier if available (v1.5+), otherwise slice from code
      const specifier = imp.specifier ?? code.slice(s, e);
      if (!specifier) continue;
      if (isInformationalString(specifier)) continue;
      const c = classifyUrl(specifier, opts.ctx);
      if (c === "INFORMATIONAL_STRING") continue;
      const abs = resolveUrl(specifier, opts.baseUrl);
      if (!abs) continue;
      const normalized = normalizeUrl(abs);
      const node = opts.graph.getByUrl(normalized);
      if (node && node.localRelativePath) {
        const local = "/" + node.localRelativePath.replace(/^\/+/, "");
        // NOTE: s/e point to the specifier WITHOUT surrounding quotes.
        // Do NOT use JSON.stringify (it would add extra quotes).
        ms.overwrite(s, e, local);
        if (isDynamic) counters.rewrittenDynamicImports++;
        else counters.rewrittenStaticImports++;
      }
    }
  } catch (err) {
    opts.logger?.warn("es-module-lexer parse failed", {
      error: err instanceof Error ? err.message : String(err),
    });
    counters.parseErrors++;
  }

  // Phase 2: Babel AST — dynamic imports + asset literals
  await rewriteWithBabel(code, ms, opts, counters);

  // Phase 3: Inline url() tokens inside string literals (CSS-in-JS patterns)
  // — surgical replacement of framerusercontent.com URLs inside url() calls
  // that appear within JS string literals. This catches patterns like:
  //   backgroundImage:"url('https://framerusercontent.com/images/foo.png')"
  //   backgroundImage:"url(https://framerusercontent.com/images/foo.png)"
  //   backgroundImage:"url(framerusercontent.com/images/foo.png)"
  // The pattern matches url(...) with any quoting inside, as long as the
  // URL contains framerusercontent.com (with or without protocol).
  let inlineUrlHits = 0;
  const urlInJsPattern = /url\(\s*["']?([^"')\s]*framerusercontent\.com[^"')\s]*)["']?\s*\)/gi;
  const codeBeforePhase3 = ms.toString();
  const newCode = codeBeforePhase3.replace(urlInJsPattern, (m, url) => {
    if (isInformationalString(url)) return m;
    const abs = resolveUrl(url, opts.baseUrl);
    if (!abs) return m;
    const normalized = normalizeUrl(abs);
    const node = opts.graph.getByUrl(normalized);
    if (node && node.localRelativePath) {
      const local = "/" + node.localRelativePath.replace(/^\/+/, "");
      inlineUrlHits++;
      return `url("${local}")`;
    }
    // URL not in graph — neutralize to empty url()
    inlineUrlHits++;
    return `url("")`;
  });
  counters.rewrittenAssetLiterals += inlineUrlHits;

  // Phase 4: Fix new URL(x, base) where base is a root-relative path.
  // Our FramerLit handler replaces framerusercontent.com URLs with local
  // paths like "/assets/js/modules/foo.js". But these paths are NOT valid
  // URL bases — new URL("./bar", "/assets/js/modules/foo.js") throws
  // "URL constructor: /assets/... is not a valid URL".
  // Fix: replace new URL(x, "/assets/...") with new URL(x, import.meta.url)
  // which correctly resolves to the current module's full URL in the browser.
  const finalCode = newCode.replace(
    /new URL\((([^,)]+)),\s*("\/assets\/[^"]*")\)/gi,
    (match, firstArg, _secondArg, _basePath) => {
      return `new URL(${firstArg},import.meta.url)`;
    },
  );

  counters.code = finalCode;
  return counters;
}

/**
 * Detect whether a JS module's body, when stringified, contains a hydrated
 * React DOM root. Used by NIT to ensure we preserved the React tree instead
 * of leaving a blank <div>.
 */
export function jsBodyHasReactHydration(code: string): boolean {
  return (
    /hydrateRoot\s*\(/.test(code) ||
    /ReactDOM\.hydrate/.test(code) ||
    /__FRamer_HYDRATE/.test(code) ||
    /data-framer-hydrate-id/.test(code) ||
    /createRoot\s*\(/.test(code)
  );
}

/** Cheap heuristic: does this chunk contain "use client" or "use server"? */
export function isRscDirectiveChunk(code: string): boolean {
  return /^\s*["']use client["']/m.test(code) || /^\s*["']use server["']/m.test(code);
}

/** Helper used by other modules to walk HTML/CSS-like strings inside JS. */
export function cheerioIsHtml(s: string): boolean {
  try {
    const $ = cheerioLoad(s);
    return $("*").length > 0;
  } catch {
    return false;
  }
}
