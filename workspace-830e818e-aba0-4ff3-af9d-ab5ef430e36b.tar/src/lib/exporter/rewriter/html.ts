/**
 * YesCode — HTML rewriter & DOM cleaner (Cheerio).
 *
 * Per rules.md HTML REWRITING section + critical bug fixes:
 *   - Rewrite <link rel=stylesheet|preload|prefetch|modulepreload|icon|manifest>
 *   - Rewrite <script type=module src>
 *   - Rewrite <img src> and srcset
 *   - Rewrite <picture><source srcset>
 *   - Rewrite inline style="" url(...)
 *
 * CLEANUP stage (critical bug fix #2):
 *   - Remove "Made in Framer" badge (#framer-badge, a[href*=framer.com?utm_campaign=])
 *   - Strip <script> tags referencing events.framer.com / telemetry
 *   - Strip __framer_canvas_bridge / preview communication scripts
 *   - Strip editor-check scripts (__framer_force_showing_editorbar_since, framer.com/edit/init.mjs)
 *   - Remove <!-- Made in Framer ... --> HTML comments
 *   - Remove <meta name="generator" content="Framer ...">
 *   - Localize meta[name=framer-search-index] + framer-search-index-fallback JSON
 *   - Localize meta[property=og:image] + meta[name=twitter:image]
 *   - Rewrite link[rel=canonical] + meta[property=og:url] to strip *.framer.ai/*.framer.app
 *
 * CRITICAL bug fix #3 — preserve Framer internals:
 *   - NEVER remove framer-* CSS classes (needed for styles)
 *   - NEVER remove data-framer-* attributes (needed for animations/hydration)
 *   - Localize ALL framerusercontent.com + framer.com links in src/href/content/srcset
 */

import { load as cheerioLoad } from "cheerio";
import type { ResourceGraph } from "../graph";
import { normalizeUrl, resolveUrl } from "../capture";
import { classifyUrl, shouldStrip, type ClassifyContext } from "../classifier";
import { rewriteInternalRouteLink } from "../route-utils";

interface RewriteOptions {
  baseUrl: string;
  ctx: ClassifyContext;
  graph: ResourceGraph;
  logger?: import("../logger").StructuredLogger;
  /** Set of canonical route identities (e.g. "/contact", "/about") discovered
   *  by the BFS crawl. Used to rewrite document-relative links to root-absolute. */
  knownRoutes?: Set<string>;
}

const FRAMER_BADGE_SELECTORS = [
  'a[href*="framer.com?utm_campaign="]',
  'a[href*="framer.com&utm_campaign="]',
  "#framer-badge",
  "[id^='__framer_badge']",
  ".framer-badge",
];

const FRAMER_BRIDGE_PATTERNS = [
  /__framer_canvas_bridge/i,
  /framer\.com\/api\/preview/i,
  /framerusercontent\.com\/.*\/preview/i,
  /framer\.com\/projects\//i,
  /__framer_force_showing_editorbar_since/i,
  /framer\.com\/edit\/init\.mjs/i,
  /framer\.com\/edit\//i,
];

/** Editor-check + telemetry inline script patterns — remove entirely. */
const EDITOR_SCRIPT_PATTERNS = [
  /__framer_force_showing_editorbar_since/,
  /framer\.com\/edit\/init\.mjs/,
  /framer\.com\/edit\//,
  /__framer_canvas_bridge/,
  /framer\.com\/api\/preview/,
  /events\.framer\.com/,
  /stats\.framer\.com/,
  /telemetry\.framer\.com/,
];

export interface HtmlRewriteResult {
  html: string;
  removedBadges: number;
  removedScripts: number;
  removedComments: number;
  removedGenerator: number;
  rewrittenAttributes: number;
  rewrittenMetaTags: number;
}

const STRIPPED = "__STRIPPED__";

/** Check if a URL points to a Framer host that must be localized/removed. */
function isFramerHostUrl(url: string): boolean {
  return (
    /framerusercontent\.com/i.test(url) ||
    /(^|\.)framer\.com/i.test(url) ||
    /(^|\.)framer\.ai/i.test(url) ||
    /(^|\.)framer\.app/i.test(url) ||
    /(^|\.)framerstatic\.com/i.test(url) ||
    /(^|\.)framercanvas\.com/i.test(url)
  );
}

/**
 * Rewrite a single HTML document against the resource graph. Resources that
 * have been downloaded & localised will be referenced by their localRelativePath;
 * telemetry/editor/bootstrap references are stripped.
 */
export function rewriteHtml(html: string, opts: RewriteOptions): HtmlRewriteResult {
  const $ = cheerioLoad(html, { decodeEntities: false });
  let removedBadges = 0;
  let removedScripts = 0;
  let removedComments = 0;
  let removedGenerator = 0;
  let rewrittenAttributes = 0;
  let rewrittenMetaTags = 0;

  // CLEANUP: remove Framer badges
  for (const sel of FRAMER_BADGE_SELECTORS) {
    $(sel).each((_, el) => {
      $(el).remove();
      removedBadges++;
    });
  }
  $("[style*='position:fixed'], [style*='position: fixed']").each((_, el) => {
    const $el = $(el);
    const txt = ($el.text() || "").toLowerCase();
    if (txt.includes("made with framer") || txt.includes("built with framer")) {
      $el.remove();
      removedBadges++;
    }
  });

  // CLEANUP: strip telemetry/preview-bridge/editor-check scripts
  $("script[src]").each((_, el) => {
    const $el = $(el);
    const src = $el.attr("src") ?? "";
    if (!src) return;
    if (FRAMER_BRIDGE_PATTERNS.some((p) => p.test(src))) {
      $el.remove();
      removedScripts++;
      return;
    }
    const c = classifyUrl(src, opts.ctx);
    if (shouldStrip(c)) {
      $el.remove();
      removedScripts++;
    }
  });
  // Inline scripts: check for editor-check + telemetry patterns
  $("script:not([src])").each((_, el) => {
    const $el = $(el);
    const code = $el.html() ?? "";
    if (FRAMER_BRIDGE_PATTERNS.some((p) => p.test(code)) ||
        EDITOR_SCRIPT_PATTERNS.some((p) => p.test(code))) {
      $el.remove();
      removedScripts++;
    }
  });

  // CLEANUP: remove <!-- Made in Framer ... --> HTML comments
  // Cheerio exposes comments via this.type === "comment"
  const removeFramerComments = (idx: number, node: unknown) => {
    const n = node as { type?: string; data?: string };
    if (n.type !== "comment") return;
    const text = n.data ?? "";
    if (/made in framer/i.test(text) || /built with framer/i.test(text)) {
      $(node).remove();
      removedComments++;
    }
  };
  $("*").contents().filter(function () {
    return this.type === "comment";
  }).each(removeFramerComments);
  $.root().contents().filter(function () {
    return this.type === "comment";
  }).each(removeFramerComments);

  // CLEANUP: remove <meta name="generator" content="Framer ...">
  $('meta[name="generator"]').each((_, el) => {
    const $el = $(el);
    const content = ($el.attr("content") ?? "").toLowerCase();
    if (content.includes("framer")) {
      $el.remove();
      removedGenerator++;
    }
  });

  /** Rewrite a URL attribute value against the graph. Returns STRIPPED for removal. */
  const rewriteAttrUrl = (raw: string): string | null => {
    if (!raw) return null;
    const abs = resolveUrl(raw, opts.baseUrl);
    if (!abs) return raw;
    const normalized = normalizeUrl(abs);
    const c = classifyUrl(raw, opts.ctx);
    if (shouldStrip(c)) return STRIPPED;
    if (c === "INFORMATIONAL_STRING" || c === "LOCAL_RESOURCE") return null;
    const node = opts.graph.getByUrl(normalized);
    if (node && node.localRelativePath) {
      rewrittenAttributes++;
      return "/" + node.localRelativePath.replace(/^\/+/, "");
    }
    // If it's a Framer host URL but not in the graph (e.g., wasn't downloaded),
    // still strip it to avoid leaving external Framer references.
    if (isFramerHostUrl(raw)) return STRIPPED;
    return null;
  };

  $('link[href]').each((_, el) => {
    const $el = $(el);
    const href = $el.attr("href") ?? "";
    const next = rewriteAttrUrl(href);
    if (next === STRIPPED) $el.remove();
    else if (next) $el.attr("href", next);
  });

  $('script[src]').each((_, el) => {
    const $el = $(el);
    const src = $el.attr("src") ?? "";
    const next = rewriteAttrUrl(src);
    if (next === STRIPPED) $el.remove();
    else if (next) $el.attr("src", next);
  });

  $('img[src]').each((_, el) => {
    const $el = $(el);
    const src = $el.attr("src") ?? "";
    const next = rewriteAttrUrl(src);
    if (next && next !== STRIPPED) $el.attr("src", next);
    else if (next === STRIPPED) $el.remove();
  });
  $('img[srcset]').each((_, el) => {
    const $el = $(el);
    const srcset = $el.attr("srcset") ?? "";
    const candidates = srcset.split(",").map((c) => c.trim());
    const rewritten = candidates.map((cand) => {
      const [u, descriptor] = cand.split(/\s+/);
      if (!u) return cand;
      const next = rewriteAttrUrl(u);
      if (next && next !== STRIPPED) return [next, descriptor].filter(Boolean).join(" ");
      return cand;
    }).join(", ");
    $el.attr("srcset", rewritten);
  });

  $('source[srcset]').each((_, el) => {
    const $el = $(el);
    const srcset = $el.attr("srcset") ?? "";
    const candidates = srcset.split(",").map((c) => c.trim());
    const rewritten = candidates.map((cand) => {
      const [u, descriptor] = cand.split(/\s+/);
      if (!u) return cand;
      const next = rewriteAttrUrl(u);
      if (next && next !== STRIPPED) return [next, descriptor].filter(Boolean).join(" ");
      return cand;
    }).join(", ");
    $el.attr("srcset", rewritten);
  });

  $('source[src]').each((_, el) => {
    const $el = $(el);
    const src = $el.attr("src") ?? "";
    const next = rewriteAttrUrl(src);
    if (next && next !== STRIPPED) $el.attr("src", next);
  });
  $('video[poster]').each((_, el) => {
    const $el = $(el);
    const poster = $el.attr("poster") ?? "";
    const next = rewriteAttrUrl(poster);
    if (next && next !== STRIPPED) $el.attr("poster", next);
  });

  // CRITICAL bug fix #2: meta tag content localization
  $('meta[content]').each((_, el) => {
    const $el = $(el);
    const content = $el.attr("content") ?? "";
    if (!content) return;
    const name = ($el.attr("name") ?? "").toLowerCase();
    const property = ($el.attr("property") ?? "").toLowerCase();

    // framer-search-index / framer-search-index-fallback → localize JSON
    if (name === "framer-search-index" || name === "framer-search-index-fallback") {
      if (/^https?:\/\//i.test(content)) {
        const next = rewriteAttrUrl(content);
        if (next && next !== STRIPPED) {
          $el.attr("content", next);
          rewrittenMetaTags++;
        } else if (next === STRIPPED) {
          $el.remove();
        }
      }
      return;
    }

    // og:image / twitter:image → localize image
    if (property === "og:image" || name === "twitter:image" ||
        property === "og:image:secure_url" || property === "og:image:url") {
      if (/^https?:\/\//i.test(content)) {
        const next = rewriteAttrUrl(content);
        if (next && next !== STRIPPED) {
          $el.attr("content", next);
          rewrittenMetaTags++;
        } else if (next === STRIPPED) {
          $el.remove();
        }
      }
      return;
    }

    // og:url → strip *.framer.ai / *.framer.app, replace with path
    if (property === "og:url") {
      if (isFramerHostUrl(content)) {
        try {
          const u = new URL(content);
          // Replace with path only (drop framer host)
          const newPath = u.pathname === "/" ? "/" : u.pathname.replace(/\/+$/, "/");
          $el.attr("content", newPath);
          rewrittenMetaTags++;
        } catch {
          // If URL parse fails, remove the meta tag
          $el.remove();
          rewrittenMetaTags++;
        }
      }
      return;
    }
  });

  // CRITICAL bug fix #2: link[rel=canonical] → strip *.framer.ai / *.framer.app
  $('link[rel="canonical"]').each((_, el) => {
    const $el = $(el);
    const href = $el.attr("href") ?? "";
    if (!href) return;
    if (isFramerHostUrl(href)) {
      try {
        const u = new URL(href);
        const newPath = u.pathname === "/" ? "/" : u.pathname.replace(/\/+$/, "/");
        $el.attr("href", newPath);
        rewrittenAttributes++;
      } catch {
        // Remove canonical if it can't be parsed
        $el.remove();
      }
    }
  });

  $("style").each((_, el) => {
    const $el = $(el);
    const css = $el.html() ?? "";
    const rewritten = rewriteInlineCssUrls(css, opts);
    $el.html(rewritten);
  });
  $("[style]").each((_, el) => {
    const $el = $(el);
    const css = $el.attr("style") ?? "";
    const rewritten = rewriteInlineCssUrls(css, opts);
    $el.attr("style", rewritten);
  });

  // Anchor <a href> — same-origin routes → ROOT-ABSOLUTE (per master prompt
  // FAILURE CLASS B): /about/ page with link "contact" → "/contact" (not "contact"
  // which would resolve to /about/contact).
  $('a[href]').each((_, el) => {
    const $el = $(el);
    const href = $el.attr("href") ?? "";
    if (!href || href.startsWith("#") || href.startsWith("mailto:") || href.startsWith("tel:")) return;
    // Use central route canonicalization — produces root-absolute paths
    const rewritten = rewriteInternalRouteLink(href, opts.baseUrl, opts.ctx.targetOrigin, opts.knownRoutes);
    if (rewritten !== null && rewritten !== href) {
      $el.attr("href", rewritten);
      rewrittenAttributes++;
    }
  });

  const out = $.html();
  return {
    html: out,
    removedBadges,
    removedScripts,
    removedComments,
    removedGenerator,
    rewrittenAttributes,
    rewrittenMetaTags,
  };
}

/** Rewrite url(...) and @import tokens in an inline CSS string. */
export function rewriteInlineCssUrls(css: string, opts: RewriteOptions): string {
  let out = css;
  out = out.replace(
    /url\(\s*(?:"([^"]*)"|'([^']*)'|([^)\s]+))\s*\)/gi,
    (m, q1, q2, q3) => {
      const u = q1 ?? q2 ?? q3;
      if (!u) return m;
      const abs = resolveUrl(u, opts.baseUrl);
      if (!abs) return m;
      const normalized = normalizeUrl(abs);
      const c = classifyUrl(u, opts.ctx);
      if (c === "INFORMATIONAL_STRING" || c === "LOCAL_RESOURCE") return m;
      if (shouldStrip(c)) return "url('')";
      const node = opts.graph.getByUrl(normalized);
      if (node && node.localRelativePath) {
        const local = "/" + node.localRelativePath.replace(/^\/+/, "");
        return `url("${local}")`;
      }
      // If it's a Framer host URL but not in the graph, blank it out
      if (isFramerHostUrl(u)) return "url('')";
      return m;
    },
  );
  out = out.replace(
    /@import\s+(?:url\(\s*)?["']?([^"')]+)["']?\s*\)?\s*;/gi,
    (m, g1) => {
      if (!g1) return m;
      const abs = resolveUrl(g1, opts.baseUrl);
      if (!abs) return m;
      const normalized = normalizeUrl(abs);
      const c = classifyUrl(g1, opts.ctx);
      if (c === "INFORMATIONAL_STRING" || c === "LOCAL_RESOURCE") return m;
      if (shouldStrip(c)) return "/* stripped */";
      const node = opts.graph.getByUrl(normalized);
      if (node && node.localRelativePath) {
        const local = "/" + node.localRelativePath.replace(/^\/+/, "");
        return `@import "${local}";`;
      }
      if (isFramerHostUrl(g1)) return "/* stripped */";
      return m;
    },
  );
  return out;
}
