/**
 * YesCode — Pipeline orchestrator.
 *
 * Drives the 14-stage pipeline sequentially, emitting ProgressEvents at
 * each stage boundary and intra-stage. Reuses all engine modules.
 *
 * Stage map:
 *   QUEUED → PREFLIGHT → DISCOVERY → CAPTURE → GRAPH → MATERIALIZE →
 *   REWRITE → CLEANUP → ROUTING → SEO → RESIDUAL_SCAN → NIT →
 *   PACKAGING → COMPLETED
 */

import { promises as fs } from "node:fs";
import { join, dirname, basename } from "node:path";
import { tmpdir } from "node:os";
import { ResourceGraph } from "./graph";
import { StructuredLogger } from "./logger";
import { jobManager } from "./jobs";
import {
  assertSafeTargetUrl,
  MAX_JOB_DURATION_MS,
} from "./security";
import {
  classifyUrl,
  type ClassifyContext,
} from "./classifier";
import {
  bfsCrawl,
  DEFAULT_DISCOVERY_OPTIONS,
  type DiscoveredRoute,
} from "./discovery";
import {
  fetchWithUa,
  harvestHtmlResources,
  harvestCssUrls,
  harvestJsResources,
  normalizeUrl,
  resolveUrl,
  inferExtension,
} from "./capture";
import { materializeAll, buildLocalPath } from "./materialize";
import { rewriteHtml } from "./rewriter/html";
import { rewriteCss } from "./rewriter/css";
import { rewriteJs } from "./rewriter/js";
import { writeHostConfigs, routePathToDiskPath } from "./routing";
import { writeSeoFiles, injectCanonical } from "./seo";
import { scanForResiduals } from "./scanner";
import { runStaticNIT, startInternalServer, type NitResult } from "./nit";
import { validateAssetIntegrity } from "./asset-integrity";
import { buildAssetManifest, validateHttpResponses } from "./asset-manifest";
import { packageZip, deriveZipName } from "./packager";
import type { ExportMetrics } from "./pipeline";
import { computeOverall } from "./pipeline";
import type { PipelineStageName } from "./pipeline";

export interface RunOptions {
  url: string;
  maxPages?: number;
  maxDepth?: number;
  /** Production domain used for canonical & sitemap URLs (e.g. https://prod.com). */
  customDomain?: string;
  /** If true, skip the NIT stage. */
  skipNIT?: boolean;
  /** If true, keep Framer badge & telemetry instead of stripping. */
  keepFramerBranding?: boolean;
}

const CLEANUP_EXT = [".html", ".htm", ".css", ".js", ".mjs", ".cjs"];

/** Walk output dir for files matching one of the given extensions. */
async function collectFiles(
  root: string,
  exts: string[],
): Promise<string[]> {
  const out: string[] = [];
  async function walk(d: string) {
    const entries = await fs.readdir(d, { withFileTypes: true });
    for (const e of entries) {
      const full = join(d, e.name);
      if (e.isDirectory()) await walk(full);
      else if (e.isFile() && exts.some((x) => e.name.endsWith(x))) out.push(full);
    }
  }
  await walk(root);
  return out;
}

/** Recursively harvest resources from a CSS file's body (graph fill). */
async function harvestCssFile(
  css: string,
  baseUrl: string,
  ctx: ClassifyContext,
  graph: ResourceGraph,
  fromNodeId: string,
): Promise<void> {
  harvestCssUrls(css, baseUrl, ctx, graph, fromNodeId);
}

/** Recursively harvest resources from a JS module's body (graph fill). */
async function harvestJsFile(
  code: string,
  baseUrl: string,
  ctx: ClassifyContext,
  graph: ResourceGraph,
  fromNodeId: string,
  logger: StructuredLogger,
): Promise<void> {
  await harvestJsResources(code, baseUrl, ctx, graph, fromNodeId, logger);
}

/** Emit progress with stage name + overall % pre-computed. */
function emit(jobId: string, stage: PipelineStageName, progress: number, message: string, level: "INFO" | "WARN" | "ERROR" | "DEBUG" = "INFO", metadata?: Record<string, unknown>) {
  jobManager.emitProgress(jobId, {
    stage,
    progress,
    message,
    level,
    metadata,
    overall: computeOverall(stage, progress),
  });
}

export async function runPipelineForJob(jobId: string, opts: RunOptions): Promise<void> {
  const rec = jobManager.getJob(jobId);
  if (!rec) throw new Error(`Job ${jobId} not found`);
  const signal = rec.abort.signal;

  // Per rules.md ROUTE DISCOVERY: max page cap default 250 (ceiling 1000),
  // max depth 10.
  const maxPages = Math.min(opts.maxPages ?? DEFAULT_DISCOVERY_OPTIONS.maxPages, 1000);
  const maxDepth = Math.min(opts.maxDepth ?? DEFAULT_DISCOVERY_OPTIONS.maxDepth, 10);

  // Create logger bound to this job
  let currentStage: PipelineStageName = "QUEUED";
  const logger = new StructuredLogger(jobId, () => currentStage, jobManager.getBus(jobId)!);

  // Working directories
  const workRoot = join(tmpdir(), "yescode", jobId);
  const tempDir = join(workRoot, "temp");
  const outputDir = join(workRoot, "out");
  await fs.mkdir(tempDir, { recursive: true });
  await fs.mkdir(outputDir, { recursive: true });

  const startedAt = Date.now();
  const hardDeadline = startedAt + MAX_JOB_DURATION_MS;

  try {
    // ────────────────────────────────────────────────────────────────────
    // 1. PREFLIGHT
    // ────────────────────────────────────────────────────────────────────
    currentStage = "PREFLIGHT";
    emit(jobId, "PREFLIGHT", 5, "Validating target URL…");
    const targetUrlObj = await assertSafeTargetUrl(opts.url);
    const targetOrigin = targetUrlObj.origin;
    const ctx: ClassifyContext = {
      targetOrigin,
      initiatorOrigin: targetOrigin,
    };
    emit(jobId, "PREFLIGHT", 30, `Resolved host: ${targetUrlObj.hostname}`, "INFO");
    // Try a quick HEAD reachability check
    try {
      const probe = await fetchWithUa(targetUrlObj.toString(), signal);
      if (probe.status >= 400) {
        throw new Error(`Target returned HTTP ${probe.status}`);
      }
      emit(jobId, "PREFLIGHT", 80, `Reachable (HTTP ${probe.status})`, "INFO");
    } catch (err) {
      throw new Error(
        `Target unreachable: ${err instanceof Error ? err.message : String(err)}`,
      );
    }
    emit(jobId, "PREFLIGHT", 100, "Preflight checks passed");

    // ────────────────────────────────────────────────────────────────────
    // 2. DISCOVERY
    // ────────────────────────────────────────────────────────────────────
    currentStage = "DISCOVERY";
    const graph = new ResourceGraph();
    emit(jobId, "DISCOVERY", 5, "Starting BFS crawl + sitemap seed…");

    // Root route node must exist before crawl populates the graph
    const rootRoute = graph.upsert({
      originalUrl: opts.url,
      normalizedUrl: normalizeUrl(targetUrlObj.toString()),
      classification: "PUBLISHED_ROUTE",
      initiatorUrl: null,
    });

    // Map from route URL → final HTML string
    const routeHtml = new Map<string, string>();
    const discoveredRoutes: DiscoveredRoute[] = [];

    // CAPTURE happens inline with DISCOVERY: as we discover each route, we
    // fetch its HTML and harvest its resources into the graph.
    currentStage = "CAPTURE";
    const crawlRoutes = await bfsCrawl(
      targetUrlObj.toString(),
      ctx,
      { maxPages, maxDepth, useSitemap: true },
      graph,
      logger,
      signal,
      async (url, html, finalUrl) => {
        const routeNode = graph.upsert({
          originalUrl: url,
          normalizedUrl: normalizeUrl(finalUrl || url),
          classification: "PUBLISHED_ROUTE",
          initiatorUrl: null,
        });
        harvestHtmlResources(html, finalUrl || url, ctx, graph, routeNode.id);
        routeHtml.set(normalizeUrl(finalUrl || url), html);
        discoveredRoutes.push({ url: finalUrl || url, depth: 0, source: "sitemap" });
        emit(
          jobId,
          "CAPTURE",
          Math.min(95, (discoveredRoutes.length / maxPages) * 100),
          `Captured ${discoveredRoutes.length}/${maxPages} routes`,
        );
      },
    );
    void rootRoute;
    void crawlRoutes;

    if (discoveredRoutes.length === 0) {
      throw new Error("No routes discovered — site may be a SPA without crawlable anchors.");
    }
    emit(
      jobId,
      "DISCOVERY",
      100,
      `Discovered ${discoveredRoutes.length} route(s)`,
    );

    // ────────────────────────────────────────────────────────────────────
    // 4. GRAPH (post-crawl pass: fetch & harvest CSS / JS module bodies to
    //    capture transitive dependencies — @import, import(), url(), asset
    //    literals)
    // ────────────────────────────────────────────────────────────────────
    currentStage = "GRAPH";
    emit(jobId, "GRAPH", 5, "Resolving CSS & JS module transitive dependencies…");

    // RECURSIVE JS/CSS module resolution: fetch each module body, harvest its
    // imports/url()/@import, then process any NEWLY discovered modules.
    // This loops until no new JS/CSS modules are found — critical for
    // resolving transitive dependencies like:
    //   script_main.mjs → rolldown-runtime.mjs → react.mjs → framer.mjs → motion.mjs
    // Without this loop, only the entry module's direct imports are captured,
    // and all transitive chunks (react.*, framer.*, motion.*, etc.) are MISSING
    // from the export — causing the ".mjs returns text/html" production failure
    // (files don't exist → hosting fallback → HTML → browser rejects module).
    const processedUrls = new Set<string>();
    let graphPass = 0;
    const MAX_GRAPH_PASSES = 20; // safety cap

    while (graphPass < MAX_GRAPH_PASSES) {
      graphPass++;
      // Find JS/CSS modules that haven't been fetched yet.
      // CRITICAL: Include LOCAL_RESOURCE classification — relative imports
      // like `import("./foo.mjs")` are classified as LOCAL_RESOURCE, but their
      // normalizedUrl points to the Framer CDN (after resolveUrl). Without
      // including LOCAL_RESOURCE, dynamically imported chunks are never
      // downloaded, causing "module not found" → HTML fallback → text/html.
      const pendingNodes = graph
        .all()
        .filter(
          (n) =>
            n.classification === "FRAMER_RUNTIME" ||
            n.classification === "FRAMER_ASSET" ||
            n.classification === "THIRD_PARTY_STATIC_ASSET" ||
            n.classification === "FRAMER_BOOTSTRAP" ||
            n.classification === "LOCAL_RESOURCE",
        )
        .filter((n) => {
          const ext = inferExtension(n.originalUrl, n.contentType);
          return (ext === "css" || ext === "js" || ext === "mjs") &&
            n.state !== "DOWNLOADED" &&
            n.state !== "COMPLETED" &&
            n.state !== "FAILED" &&
            !processedUrls.has(n.normalizedUrl);
        });

      if (pendingNodes.length === 0) break;

      emit(
        jobId,
        "GRAPH",
        Math.min(90, 10 + graphPass * 10),
        `Graph pass ${graphPass}: resolving ${pendingNodes.length} new module(s)`,
        "INFO",
      );

      // Fetch each module body (small concurrency) and harvest imports
      const queue = [...pendingNodes];
      const workers = Array.from({ length: Math.min(4, queue.length) }, async () => {
        while (queue.length > 0) {
          if (signal?.aborted) return;
          const node = queue.shift();
          if (!node) return;
          processedUrls.add(node.normalizedUrl);
          try {
            const { body, status, contentType } = await fetchWithUa(node.normalizedUrl, signal);
            if (status >= 400) {
              graph.update(node.id, { state: "FAILED" });
              continue;
            }
            graph.update(node.id, { state: "DOWNLOADED", body, contentType, httpStatus: status });
            const code = body.toString("utf8");
            const ext = inferExtension(node.originalUrl, contentType);
            if (ext === "css") {
              await harvestCssFile(code, node.normalizedUrl, ctx, graph, node.id);
            } else {
              await harvestJsFile(code, node.normalizedUrl, ctx, graph, node.id, logger);
            }
          } catch (err) {
            graph.update(node.id, { state: "FAILED" });
            logger.warn(
              `Graph pass ${graphPass} failed for ${node.normalizedUrl}: ${err instanceof Error ? err.message : String(err)}`,
              undefined,
              "GRAPH",
            );
          }
        }
      });
      await Promise.all(workers);

      const totalNodes = graph.all().length;
      logger.info(
        `Graph pass ${graphPass} complete: ${totalNodes} total nodes, ${processedUrls.size} modules processed`,
        undefined,
        "GRAPH",
      );
    }

    emit(jobId, "GRAPH", 100, `Graph populated: ${graph.all().length} nodes (${graphPass} passes)`);

    // ────────────────────────────────────────────────────────────────────
    // 5. MATERIALIZE
    // ────────────────────────────────────────────────────────────────────
    currentStage = "MATERIALIZE";
    emit(jobId, "MATERIALIZE", 5, "Materializing assets (≤8 workers)…");
    const targets = graph
      .all()
      .filter((n) =>
        n.classification === "FRAMER_ASSET" ||
        n.classification === "FRAMER_RUNTIME" ||
        n.classification === "THIRD_PARTY_STATIC_ASSET" ||
        n.classification === "FRAMER_BOOTSTRAP" ||
        n.classification === "LOCAL_RESOURCE"
      )
      .filter((n) => n.state !== "DOWNLOADED" && n.state !== "COMPLETED");
    // Nodes that were downloaded in the GRAPH pass already have their disk path;
    // compute their localRelativePath now.
    for (const n of graph.all()) {
      if (n.state === "DOWNLOADED" && !n.localRelativePath) {
        const lp = buildLocalPath(n);
        if (lp) {
          const diskPath = join(outputDir, lp);
          await fs.mkdir(dirname(diskPath), { recursive: true });
          await fs.writeFile(diskPath, n.body ?? Buffer.alloc(0));
          graph.update(n.id, { localRelativePath: lp, diskPath });
        }
      }
    }
    void targets;
    const mat = await materializeAll(graph, outputDir, logger, signal, (done, total) => {
      emit(jobId, "MATERIALIZE", total === 0 ? 100 : (done / total) * 100, `Materialized ${done}/${total} assets`);
    });
    // Persist newly downloaded nodes to disk — deduplicate by disk path
    const writtenAssetPaths = new Set<string>();
    for (const n of graph.all()) {
      if (n.state === "DOWNLOADED" && n.body && n.localRelativePath) {
        const diskPath = join(outputDir, n.localRelativePath);
        if (writtenAssetPaths.has(diskPath)) continue;
        writtenAssetPaths.add(diskPath);
        await fs.mkdir(dirname(diskPath), { recursive: true });
        await fs.writeFile(diskPath, n.body);
        graph.update(n.id, { state: "COMPLETED", diskPath });
      }
    }
    emit(jobId, "MATERIALIZE", 100, `Materialized ${mat.downloaded} assets (${mat.failed} failed, ${mat.totalBytes} bytes)`);

    // ────────────────────────────────────────────────────────────────────
    // 6. REWRITE
    // ────────────────────────────────────────────────────────────────────
    currentStage = "REWRITE";
    emit(jobId, "REWRITE", 5, "AST-rewriting JS, HTML, CSS…");

    // JS modules first (topological order)
    const order = graph.topologicalSort();
    const jsNodes = order.filter((n) => {
      if (n.classification !== "FRAMER_RUNTIME" && n.classification !== "THIRD_PARTY_STATIC_ASSET" && n.classification !== "FRAMER_BOOTSTRAP" && n.classification !== "LOCAL_RESOURCE") return false;
      const ext = inferExtension(n.originalUrl, n.contentType);
      return ext === "js" || ext === "mjs";
    });
    let jsRewritten = 0;
    const writtenJsPaths = new Set<string>();
    for (const node of jsNodes) {
      if (signal?.aborted) break;
      if (!node.body || !node.localRelativePath) continue;
      const diskPath = join(outputDir, node.localRelativePath);
      // Skip if already written (multiple graph passes can produce same file)
      if (writtenJsPaths.has(diskPath)) continue;
      writtenJsPaths.add(diskPath);
      try {
        const result = await rewriteJs(node.body.toString("utf8"), {
          baseUrl: node.normalizedUrl,
          ctx,
          graph,
          logger,
        });
        await fs.writeFile(diskPath, result.code);
        graph.update(node.id, { state: "COMPLETED" });
        jsRewritten++;
        emit(jobId, "REWRITE", 5 + (jsRewritten / Math.max(1, jsNodes.length)) * 40, `Rewrote JS module ${jsRewritten}/${jsNodes.length}`);
      } catch (err) {
        logger.warn(
          `JS rewrite failed for ${node.normalizedUrl}: ${err instanceof Error ? err.message : String(err)}`,
          undefined,
          "REWRITE",
        );
      }
    }

    // CSS
    const cssNodes = order.filter((n) => {
      const ext = inferExtension(n.originalUrl, n.contentType);
      if (ext !== "css") return false;
      return n.classification === "FRAMER_RUNTIME" || n.classification === "THIRD_PARTY_STATIC_ASSET" || n.classification === "FRAMER_ASSET";
    });
    let cssRewritten = 0;
    const writtenCssPaths = new Set<string>();
    for (const node of cssNodes) {
      if (signal?.aborted) break;
      if (!node.body || !node.localRelativePath) continue;
      const diskPath = join(outputDir, node.localRelativePath);
      if (writtenCssPaths.has(diskPath)) continue;
      writtenCssPaths.add(diskPath);
      try {
        const result = await rewriteCss(node.body.toString("utf8"), {
          baseUrl: node.normalizedUrl,
          ctx,
          graph,
        });
        await fs.writeFile(diskPath, result.css);
        graph.update(node.id, { state: "COMPLETED" });
        cssRewritten++;
        emit(jobId, "REWRITE", 45 + (cssRewritten / Math.max(1, cssNodes.length)) * 30, `Rewrote CSS ${cssRewritten}/${cssNodes.length}`);
      } catch (err) {
        logger.warn(
          `CSS rewrite failed for ${node.normalizedUrl}: ${err instanceof Error ? err.message : String(err)}`,
          undefined,
          "REWRITE",
        );
      }
    }

    // HTML routes (last so any localised asset path is in the graph)
    // Build knownRoutes set for root-absolute link rewriting (P1 fix)
    const knownRoutes = new Set<string>();
    for (const r of discoveredRoutes) {
      try {
        const u = new URL(r.url);
        const path = u.pathname.replace(/\/index\.html$/, "/").replace(/\.html$/, "/");
        const route = path === "/" ? "/" : path.replace(/\/+$/, "");
        knownRoutes.add(route);
      } catch {
        // skip
      }
    }
    logger.info(`Known routes for link rewriting: ${knownRoutes.size}`, undefined, "REWRITE");

    let htmlRewritten = 0;
    const writtenHtmlPaths = new Set<string>();
    for (const [routeUrl, html] of routeHtml.entries()) {
      if (signal?.aborted) break;
      try {
        const result = rewriteHtml(html, { baseUrl: routeUrl, ctx, graph, logger, knownRoutes });
        const routePath = new URL(routeUrl).pathname.replace(/\/+$/, "") || "/";
        const canonicalUrl = opts.customDomain
          ? opts.customDomain + routePath
          : routePath;
        const finalHtml = injectCanonical(result.html, canonicalUrl);
        const diskPath = join(outputDir, routePathToDiskPath(new URL(routeUrl).pathname));
        // Skip if already written (deduplicate by disk path — multiple URLs
        // can map to the same index.html, e.g. /about and /about/)
        if (writtenHtmlPaths.has(diskPath)) {
          continue;
        }
        writtenHtmlPaths.add(diskPath);
        await fs.mkdir(dirname(diskPath), { recursive: true });
        await fs.writeFile(diskPath, finalHtml);
        htmlRewritten++;
        emit(jobId, "REWRITE", 75 + (htmlRewritten / Math.max(1, routeHtml.size)) * 25, `Rewrote HTML ${htmlRewritten}/${routeHtml.size}`);
      } catch (err) {
        logger.warn(
          `HTML rewrite failed for ${routeUrl}: ${err instanceof Error ? err.message : String(err)}`,
          undefined,
          "REWRITE",
        );
      }
    }
    emit(jobId, "REWRITE", 100, `Rewrote ${jsRewritten} JS, ${cssRewritten} CSS, ${htmlRewritten} HTML files`);

    // ────────────────────────────────────────────────────────────────────
    // 7. CLEANUP — already performed inline during HTML rewrite, but we do
    //    a second pass over inline scripts in HTML to strip telemetry.
    // ────────────────────────────────────────────────────────────────────
    currentStage = "CLEANUP";
    emit(jobId, "CLEANUP", 10, "Verifying telemetry & badge removal…");
    // Re-walk HTML files for any lingering telemetry scripts (should be 0).
    const htmlFiles = await collectFiles(outputDir, [".html", ".htm"]);
    for (const f of htmlFiles) {
      if (signal?.aborted) break;
      let html = await fs.readFile(f, "utf8");
      // keepFramerBranding: skip all stripping (badge & telemetry preserved)
      if (!opts.keepFramerBranding) {
        // Strip remaining script tags referencing telemetry
        html = html.replace(
          /<script\b[^>]*\bsrc=["'][^"']*(?:events\.framer\.com|stats\.framer\.com|telemetry\.framer\.com)[^"']*["'][^>]*>\s*<\/script>/gi,
          "",
        );
        // CRITICAL bug fix #2: remove editor-check inline scripts
        // (__framer_force_showing_editorbar_since, framer.com/edit/init.mjs)
        html = html.replace(
          /<script\b(?![^>]*\bsrc=)[^>]*>[\s\S]*?(?:__framer_force_showing_editorbar_since|framer\.com\/edit\/init\.mjs|__framer_canvas_bridge|framer\.com\/api\/preview)[\s\S]*?<\/script>/gi,
          "",
        );
        // CRITICAL bug fix #2: remove editor-check script tags with src
        html = html.replace(
          /<script\b[^>]*\bsrc=["'][^"']*(?:framer\.com\/edit\/|__framer_canvas_bridge|framer\.com\/api\/preview)[^"']*["'][^>]*>\s*<\/script>/gi,
          "",
        );
        // CRITICAL bug fix #2: remove <!-- Made in Framer ... --> comments
        html = html.replace(
          /<!--[^>]*\b(?:Made in Framer|Built with Framer)\b[\s\S]*?-->/gi,
          "",
        );
        // CRITICAL bug fix #2: remove <meta name="generator" content="Framer ...">
        html = html.replace(
          /<meta\b[^>]*\bname=["']generator["'][^>]*\bcontent=["'][^"']*Framer[^"']*["'][^>]*>/gi,
          "",
        );
        html = html.replace(
          /<meta\b[^>]*\bcontent=["'][^"']*Framer[^"']*["'][^>]*\bname=["']generator["'][^>]*>/gi,
          "",
        );
        // Remove "Made with Framer" link containers
        html = html.replace(
          /<a\b[^>]*href=["'][^"']*framer\.com\?utm_campaign=[^"']*["'][^>]*>[\s\S]*?<\/a>/gi,
          "",
        );
      }
      await fs.writeFile(f, html);
    }
    emit(
      jobId,
      "CLEANUP",
      100,
      opts.keepFramerBranding
        ? `Skipped badge/telemetry stripping (keepFramerBranding=true) — swept ${htmlFiles.length} files`
        : `Swept ${htmlFiles.length} HTML files`,
    );

    // ────────────────────────────────────────────────────────────────────
    // 8. ROUTING
    // ────────────────────────────────────────────────────────────────────
    currentStage = "ROUTING";
    emit(jobId, "ROUTING", 10, "Writing host configs (.htaccess, nginx, _redirects, 404)…");
    await writeHostConfigs(outputDir, discoveredRoutes, targetOrigin, logger);
    emit(jobId, "ROUTING", 100, "Host configs written");

    // ────────────────────────────────────────────────────────────────────
    // 9. SEO — use customDomain for canonical/sitemap if provided
    // ────────────────────────────────────────────────────────────────────
    currentStage = "SEO";
    const seoOrigin = opts.customDomain ?? targetOrigin;
    emit(
      jobId,
      "SEO",
      10,
      opts.customDomain
        ? `Generating sitemap.xml & robots.txt (canonical: ${seoOrigin})…`
        : "Generating sitemap.xml & robots.txt…",
    );
    await writeSeoFiles(outputDir, discoveredRoutes, seoOrigin, logger);
    emit(jobId, "SEO", 100, `SEO files written for ${discoveredRoutes.length} route(s)`);

    // ────────────────────────────────────────────────────────────────────
    // 10. RESIDUAL_SCAN
    // ────────────────────────────────────────────────────────────────────
    currentStage = "RESIDUAL_SCAN";
    emit(jobId, "RESIDUAL_SCAN", 10, "Scanning for residual Framer references…");
    const scan = await scanForResiduals(outputDir, logger, targetOrigin);
    if (scan.hits.length > 0) {
      logger.warn(
        `Residual scan found ${scan.hits.length} hit(s)`,
        { sample: scan.hits.slice(0, 5) },
        "RESIDUAL_SCAN",
      );
    }
    emit(jobId, "RESIDUAL_SCAN", 100, `${scan.hits.length} residual hit(s) across ${scan.filesScanned} files`);

    // ────────────────────────────────────────────────────────────────────
    // 10b. ASSET INTEGRITY VALIDATION (P0 fix)
    // Verify every emitted asset URL → local file exists + correct MIME.
    // CRITICAL: detect the ".mjs returns text/html" bug before packaging.
    // ────────────────────────────────────────────────────────────────────
    emit(jobId, "RESIDUAL_SCAN", 100, "Validating asset integrity…");
    const integrity = await validateAssetIntegrity(graph, outputDir, logger);
    if (!integrity.passed) {
      const msg = `Asset integrity validation FAILED: ${integrity.fatalErrors.length} fatal error(s). First: ${integrity.fatalErrors[0] ?? "unknown"}`;
      logger.error(msg, { fatalErrors: integrity.fatalErrors.slice(0, 5) }, "RESIDUAL_SCAN");
      emit(jobId, "RESIDUAL_SCAN", 100, msg, "ERROR");
      // Fail the export — do NOT package a broken site
      jobManager.failJob(jobId, msg);
      return;
    }
    emit(
      jobId,
      "RESIDUAL_SCAN",
      100,
      `Asset integrity OK: ${integrity.okCount}/${integrity.totalAssets} assets valid`,
    );

    // ────────────────────────────────────────────────────────────────────
    // 10c. ASSET MANIFEST + HTTP VALIDATION (P0 fix from master prompt #2)
    // Build a machine-readable manifest of every localized resource, then
    // start an HTTP server over the extracted output and request every asset
    // to verify status + MIME + body type. FAIL if any asset returns HTML.
    // ────────────────────────────────────────────────────────────────────
    emit(jobId, "RESIDUAL_SCAN", 100, "Building asset manifest + HTTP validation…");
    const manifest = await buildAssetManifest(graph, outputDir);
    logger.info(
      `Asset manifest: ${manifest.totalEntries} entries, ${manifest.missingCount} missing`,
      undefined,
      "RESIDUAL_SCAN",
    );

    // Start internal HTTP server for validation
    const validationServer = await startInternalServer(outputDir);
    emit(jobId, "RESIDUAL_SCAN", 100, `HTTP validation: requesting ${manifest.totalEntries} assets…`);

    const httpResult = await validateHttpResponses(manifest, validationServer.url);
    await validationServer.close();

    if (!httpResult.passed_validation) {
      const failures = httpResult.failures.slice(0, 5);
      const msg = `HTTP validation FAILED: ${httpResult.failed}/${httpResult.checked} assets failed. First: ${failures[0]?.publicPath} — ${failures[0]?.reason}`;
      logger.error(msg, { failures }, "RESIDUAL_SCAN");
      emit(jobId, "RESIDUAL_SCAN", 100, msg, "ERROR");
      jobManager.failJob(jobId, msg);
      return;
    }
    emit(
      jobId,
      "RESIDUAL_SCAN",
      100,
      `HTTP validation OK: ${httpResult.passed}/${httpResult.checked} assets served correctly`,
    );

    // ────────────────────────────────────────────────────────────────────
    // 11. NIT (skippable via options.skipNIT)
    // ────────────────────────────────────────────────────────────────────
    currentStage = "NIT";
    let nitResult: NitResult;
    if (opts.skipNIT) {
      emit(jobId, "NIT", 50, "NIT skipped (skipNIT=true)", "WARN");
      nitResult = {
        prohibitedCalls: [],
        consoleErrors: [],
        passed: true,
        routesTested: 0,
        rootContainerPopulated: true,
        scrollOk: true,
        reason: "NIT skipped by user option",
      };
    } else {
      emit(jobId, "NIT", 5, "Spinning up internal HTTP server & blocking Framer hosts…");
      try {
        nitResult = await runStaticNIT(outputDir, discoveredRoutes, logger);
      } catch (err) {
        nitResult = {
          prohibitedCalls: [],
          consoleErrors: [`NIT crashed: ${err instanceof Error ? err.message : String(err)}`],
          passed: false,
          routesTested: 0,
          rootContainerPopulated: false,
          scrollOk: false,
          reason: "NIT runtime error",
        };
      }
    }
    emit(
      jobId,
      "NIT",
      100,
      opts.skipNIT
        ? "NIT skipped"
        : `NIT ${nitResult.passed ? "PASSED" : "FAILED"} — ${nitResult.prohibitedCalls.length} prohibited, ${nitResult.consoleErrors.length} errors`,
      opts.skipNIT ? "WARN" : nitResult.passed ? "INFO" : "WARN",
    );

    // ────────────────────────────────────────────────────────────────────
    // 12. PACKAGING
    // ────────────────────────────────────────────────────────────────────
    currentStage = "PACKAGING";
    emit(jobId, "PACKAGING", 10, "Building deterministic ZIP archive…");
    const zipName = deriveZipName(opts.url);
    const zipInfo = await packageZip(outputDir, zipName, logger, jobManager.downloadsDir);
    emit(jobId, "PACKAGING", 100, `Packaged ${zipInfo.entryCount} entries into ${zipName}`);

    // ────────────────────────────────────────────────────────────────────
    // 13. COMPLETED — assemble metrics & finish
    // ────────────────────────────────────────────────────────────────────
    currentStage = "COMPLETED";
    const stats = graph.stats();
    const totalSize = stats.totalSizeBytes + zipInfo.sizeBytes;
    const durationMs = Date.now() - startedAt;
    const metrics: ExportMetrics = {
      totalRoutes: discoveredRoutes.length,
      totalAssets: stats.total,
      totalSizeBytes: totalSize,
      totalJsModules: graph.byClassification("FRAMER_RUNTIME").length + graph.byClassification("THIRD_PARTY_STATIC_ASSET").filter((n) => inferExtension(n.originalUrl, n.contentType) === "js" || inferExtension(n.originalUrl, n.contentType) === "mjs").length,
      totalCssFiles: graph.all().filter((n) => inferExtension(n.originalUrl, n.contentType) === "css").length,
      totalImages: graph.byClassification("FRAMER_ASSET").length,
      totalFonts: graph.all().filter((n) => {
        const ext = inferExtension(n.originalUrl, n.contentType);
        return ext === "woff2" || ext === "woff" || ext === "ttf" || ext === "otf" || ext === "eot";
      }).length,
      nitStatus: nitResult.passed ? "PASSED" : "FAILED",
      nitProhibitedCalls: nitResult.prohibitedCalls.length,
      nitConsoleErrors: nitResult.consoleErrors.length,
      durationMs,
      outputZipName: zipName,
      outputZipSizeBytes: zipInfo.sizeBytes,
    };
    jobManager.finishJob(jobId, metrics, zipInfo.zipPath);
    if (Date.now() > hardDeadline) {
      // We technically exceeded the watchdog but still produced output — warn.
      logger.warn("Job exceeded hard deadline but completed", undefined, "COMPLETED");
    }
    void CLEANUP_EXT;
    void basename;
    void classifyUrl;
    void resolveUrl;
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    jobManager.failJob(jobId, msg);
  } finally {
    // Clean up tempDir — keep outputDir? We ZIP'd it so we can drop.
    try {
      await fs.rm(workRoot, { recursive: true, force: true });
    } catch {
      // ignore
    }
  }
}
