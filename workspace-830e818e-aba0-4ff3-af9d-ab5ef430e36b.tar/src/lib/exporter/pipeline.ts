/**
 * YesCode — shared pipeline types & constants.
 *
 * Used by both the Next.js UI (page.tsx) and the backend API routes
 * under src/app/api/export/*. Decoupled per the rules.md Separation
 * of Concerns invariant: UI never imports engine internals, only this
 * contract module.
 */

export const PIPELINE_STAGES = [
  "QUEUED",
  "PREFLIGHT",
  "DISCOVERY",
  "CAPTURE",
  "GRAPH",
  "MATERIALIZE",
  "REWRITE",
  "CLEANUP",
  "ROUTING",
  "SEO",
  "RESIDUAL_SCAN",
  "NIT",
  "PACKAGING",
  "COMPLETED",
] as const;

export type PipelineStageName = (typeof PIPELINE_STAGES)[number];

/** A short human-readable description for each pipeline stage (UI copy). */
export const STAGE_DESCRIPTIONS: Record<PipelineStageName, string> = {
  QUEUED: "Job accepted, waiting for worker",
  PREFLIGHT: "URL validation, SSRF guard, target reachability",
  DISCOVERY: "Sitemap + BFS anchor crawl for route enumeration",
  CAPTURE: "Fetch & hydrate HTML, harvest linked assets",
  GRAPH: "Build resource dependency graph (12-variant taxonomy)",
  MATERIALIZE: "Concurrent download of assets (≤8 workers)",
  REWRITE: "AST-rewrite JS imports, HTML src/srcset, CSS url()",
  CLEANUP: "Strip Framer badge & telemetry scripts",
  ROUTING: "Emit /route/index.html, .htaccess, nginx, _redirects",
  SEO: "Generate sitemap.xml, robots.txt, canonical tags",
  RESIDUAL_SCAN: "Scan for any remaining framerusercontent.com refs",
  NIT: "Network Independence Test (block all Framer hosts)",
  PACKAGING: "Deterministic ZIP archive: <sub>-yescode.zip",
  COMPLETED: "Export finished, ZIP ready for download",
};

export type JobStatus = "running" | "completed" | "failed";

export interface ProgressEvent {
  jobId: string;
  stage: PipelineStageName;
  progress: number; // 0..100 within current stage
  overall: number; // 0..100 across full pipeline
  message: string;
  timestamp: number;
  level?: "INFO" | "WARN" | "ERROR" | "DEBUG";
  metadata?: Record<string, unknown>;
}

export interface ExportMetrics {
  totalRoutes: number;
  totalAssets: number;
  totalSizeBytes: number;
  totalJsModules: number;
  totalCssFiles: number;
  totalImages: number;
  totalFonts: number;
  nitStatus: "PASSED" | "FAILED" | "NOT_RUN";
  nitProhibitedCalls: number;
  nitConsoleErrors: number;
  durationMs: number;
  outputZipName: string;
  outputZipSizeBytes: number;
}

export interface JobState {
  jobId: string;
  targetUrl: string;
  status: JobStatus;
  stage: PipelineStageName;
  overall: number;
  message: string;
  createdAt: number;
  updatedAt: number;
  logs: ProgressEvent[];
  metrics: ExportMetrics | null;
  error: string | null;
  outputZipPath: string | null;
}

export interface CreateExportResponse {
  jobId: string;
}

export interface ApiError {
  error: string;
  code?: string;
}

/** Compute overall pipeline progress (0..100) from stage + intra-stage progress. */
export function computeOverall(stage: PipelineStageName, intra: number): number {
  const idx = PIPELINE_STAGES.indexOf(stage);
  if (idx < 0) return 0;
  // Treat each of 14 stages as an equal slice of the pipeline.
  const slice = 100 / PIPELINE_STAGES.length;
  const base = idx * slice;
  return Math.min(100, base + (intra / 100) * slice);
}

/** Helper to map a stage to its index (1-based for UI display). */
export function stageIndex(stage: PipelineStageName): number {
  return PIPELINE_STAGES.indexOf(stage) + 1;
}

/**
 * User-facing export options passed via POST /api/export body. Defaults are
 * applied in the API route when omitted.
 */
export interface ExportOptions {
  /** Max pages to crawl (1..1000). Default 250. */
  maxPages?: number;
  /** Max crawl depth (1..10). Default 10. */
  maxDepth?: number;
  /** Production domain for canonical/sitemap URLs. Defaults to target origin. */
  customDomain?: string;
  /** If true, skip the NIT stage (faster but unverified). Default false. */
  skipNIT?: boolean;
  /** If true, include the "Made with Framer" badge & telemetry (default false = strip). */
  keepFramerBranding?: boolean;
}

/** Default options applied when the UI doesn't override them. */
export const DEFAULT_EXPORT_OPTIONS: Required<Omit<ExportOptions, "customDomain">> = {
  maxPages: 250,
  maxDepth: 10,
  skipNIT: false,
  keepFramerBranding: false,
};
