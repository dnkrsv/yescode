/**
 * YesCode — Static Residual Scanner.
 *
 * Per rules.md ACCEPTANCE CRITERIA:
 *   - "Static Residual Scan reports zero unlocalized Framer CDN dependencies."
 *
 * Walks the output directory tree, reads every text file, and scans for
 * references to framer.com / framerusercontent.com / framer.ai hosts that
 * would imply a runtime call back to Framer infrastructure.
 *
 * Excludes:
 *   - The sitemap.xml (origin host is allowed there).
 *   - The robots.txt (origin host is allowed there).
 *   - The 404.html (origin comment is allowed).
 *
 * Reports each hit with file path, line number, and a short context.
 */

import { promises as fs } from "node:fs";
import { join, relative, sep } from "node:path";
import type { StructuredLogger } from "./logger";

// CRITICAL bug fix #3: catch ALL references to Framer infrastructure hosts.
// Per spec: no external links to framerusercontent.com or framer.com may
// remain in the final output (src/href/content/srcset + JS AST).
// Matches framer.com, framer.ai, framer.app including subdomains
// (e.g. example.framer.ai, example.framer.app).
const FRAMER_HOST_RES = [
  /framerusercontent\.com/gi,
  /framer\.com\b/gi,        // framer.com (any context — root or subdomain)
  /framer\.ai\b/gi,          // framer.ai (including subdomain.framer.ai)
  /framer\.app\b/gi,         // framer.app (including subdomain.framer.app)
  /framerstatic\.com/gi,     // framerstatic.com (Framer CDN for fonts)
  /framercanvas\.com/gi,     // framercanvas.com (editor infrastructure)
  /events\.framer\.com/gi,
  /stats\.framer\.com/gi,
  /telemetry\.framer\.com/gi,
];

const SKIP_FILES = new Set([
  "sitemap.xml",
  "robots.txt",
]);

const TEXTUAL_EXT = new Set([
  "html", "htm", "css", "js", "mjs", "cjs", "json", "txt", "xml", "svg",
  "webmanifest", "map", "ts", "tsx", "jsx",
]);

export interface ResidualHit {
  file: string;
  line: number;
  column: number;
  match: string;
  context: string;
}

export interface ScanResult {
  hits: ResidualHit[];
  filesScanned: number;
  totalBytes: number;
}

/** Walk a directory tree and yield text-file paths. */
async function* walk(dir: string): AsyncGenerator<{ path: string; rel: string }> {
  const entries = await fs.readdir(dir, { withFileTypes: true });
  for (const e of entries) {
    const full = join(dir, e.name);
    if (e.isDirectory()) {
      yield* walk(full);
    } else if (e.isFile()) {
      const ext = e.name.split(".").pop()?.toLowerCase() ?? "";
      if (TEXTUAL_EXT.has(ext) && !SKIP_FILES.has(e.name)) {
        yield { path: full, rel: relative(dir, full) };
      }
    }
  }
}

/**
 * Scan the entire output directory for residual Framer references.
 * Returns the full list of hits — the orchestrator decides whether to
 * mark the job FAILED.
 */
export async function scanForResiduals(
  outputDir: string,
  logger: StructuredLogger,
  targetOrigin: string,
): Promise<ScanResult> {
  const hits: ResidualHit[] = [];
  let filesScanned = 0;
  let totalBytes = 0;

  for await (const { path, rel } of walk(outputDir)) {
    filesScanned++;
    let content: string;
    try {
      const buf = await fs.readFile(path);
      totalBytes += buf.length;
      // Skip non-text files fast (presence of NUL byte)
      if (buf.includes(0)) continue;
      content = buf.toString("utf8");
    } catch {
      continue;
    }

    const targetHost = new URL(targetOrigin).host;
    const lines = content.split("\n");
    for (let i = 0; i < lines.length; i++) {
      const line = lines[i];
      for (const re of FRAMER_HOST_RES) {
        re.lastIndex = 0;
        let m: RegExpExecArray | null;
        while ((m = re.exec(line))) {
          // Skip if it matches the target origin (allowed in informational contexts)
          const context = line.slice(Math.max(0, m.index - 30), m.index + m[0].length + 30);
          if (context.includes(targetHost)) continue;
          hits.push({
            file: rel.split(sep).join("/"),
            line: i + 1,
            column: m.index + 1,
            match: m[0],
            context,
          });
        }
      }
    }
  }

  logger.info(
    `Residual scan: ${hits.length} hit(s) across ${filesScanned} files (${totalBytes} bytes scanned)`,
    hits.length > 0 ? { sample: hits.slice(0, 5) } : undefined,
    "RESIDUAL_SCAN",
  );
  return { hits, filesScanned, totalBytes };
}
