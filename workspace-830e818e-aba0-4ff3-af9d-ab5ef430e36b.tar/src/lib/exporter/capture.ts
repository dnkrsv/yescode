/**
 * YesCode — Capture engine.
 *
 * In a fully-faithful rules.md implementation this would use Playwright
 * Chromium with hydration polling, scroll simulation, and a network
 * snooper. The sandbox environment does not ship a working Chromium
 * runtime, so we fall back to a fetch-based capture that:
 *
 *   1. Fetches the HTML with a desktop Chrome user-agent.
 *   2. Follows redirects (≤10).
 *   3. Extracts all <link>, <script>, <img>, <source>, <style>, inline
 *      style="" references and registers them in the Resource Graph.
 *   4. Recursively fetches linked CSS and JS modules to discover their
 *      transitive dependencies (CSS @import / url(), JS import()).
 *
 * The rewriter (rewriter/html.ts) and AST engine (rewriter/js.ts) handle
 * the actual localisation; this module is purely capture & graph building.
 */

import { load as cheerioLoad } from "cheerio";
import type { ResourceGraph } from "./graph";
import type { ClassifyContext } from "./classifier";
import { classifyUrl } from "./classifier";
import type { StructuredLogger } from "./logger";

const UA =
  "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 " +
  "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36";

export interface FetchedRoute {
  url: string;
  finalUrl: string;
  status: number;
  contentType: string | null;
  html: string;
}

/** Normalize a URL for graph dedup: strip hash, lowercase host, default port. */
export function normalizeUrl(raw: string): string {
  try {
    const u = new URL(raw);
    u.hash = "";
    // Strip common tracking params
    const tracking = ["utm_source", "utm_medium", "utm_campaign", "utm_term", "utm_content", "fbclid", "gclid", "msclkid"];
    for (const t of tracking) u.searchParams.delete(t);
    return u.toString().replace(/\/+$/, "/") || u.toString();
  } catch {
    return raw;
  }
}

/** Resolve a (possibly relative) URL against a base. Returns null on bad input. */
export function resolveUrl(maybe: string, base: string): string | null {
  if (!maybe) return null;
  try {
    return new URL(maybe, base).toString();
  } catch {
    return null;
  }
}

/** Fetch a URL with a desktop UA, following redirects. */
export async function fetchWithUa(
  url: string,
  signal?: AbortSignal,
): Promise<{ status: number; finalUrl: string; contentType: string | null; body: Buffer }> {
  const res = await fetch(url, {
    redirect: "follow",
    signal,
    headers: {
      "User-Agent": UA,
      Accept: "*/*",
      "Accept-Language": "en-US,en;q=0.9",
    },
  });
  // Convert ReadableStream to Buffer
  const ab = await res.arrayBuffer();
  const body = Buffer.from(ab);
  const contentType = res.headers.get("content-type");
  return {
    status: res.status,
    finalUrl: res.url || url,
    contentType,
    body,
  };
}

/** Extract the file extension implied by content-type or URL. */
export function inferExtension(
  url: string,
  contentType: string | null,
): string {
  const ct = (contentType ?? "").split(";")[0].trim().toLowerCase();
  const ctMap: Record<string, string> = {
    "text/html": "html",
    "application/xhtml+xml": "html",
    "text/css": "css",
    "text/javascript": "js",
    "application/javascript": "js",
    "text/ecmascript": "mjs",
    "application/ecmascript": "mjs",
    "application/json": "json",
    "image/svg+xml": "svg",
    "image/png": "png",
    "image/jpeg": "jpg",
    "image/webp": "webp",
    "image/gif": "gif",
    "image/x-icon": "ico",
    "image/vnd.microsoft.icon": "ico",
    "image/avif": "avif",
    "font/woff2": "woff2",
    "font/woff": "woff",
    "application/font-woff": "woff",
    "application/vnd.ms-fontobject": "eot",
    "application/octet-stream": "bin",
    "video/mp4": "mp4",
    "video/webm": "webm",
    "audio/mpeg": "mp3",
    "application/xml": "xml",
    "text/xml": "xml",
    "text/plain": "txt",
  };
  if (ct && ctMap[ct]) return ctMap[ct];
  const urlExt = url.split("?")[0].split(".").pop();
  if (urlExt && /^[a-z0-9]{2,5}$/i.test(urlExt)) return urlExt.toLowerCase();
  return "bin";
}

/**
 * Parse an HTML document and register every referenced resource in the graph.
 * Adds edges of type HTML_SRC from the route node to each discovered resource.
 */
export function harvestHtmlResources(
  html: string,
  baseUrl: string,
  ctx: ClassifyContext,
  graph: ResourceGraph,
  routeNodeId: string,
): { discovered: number } {
  const $ = cheerioLoad(html);
  let discovered = 0;

  const record = (raw: string, attr: "HTML_SRC" | "CSS_URL" = "HTML_SRC") => {
    const abs = resolveUrl(raw, baseUrl);
    if (!abs) return;
    const normalized = normalizeUrl(abs);
    const classification = classifyUrl(raw, ctx);
    if (classification === "INFORMATIONAL_STRING") return;
    const node = graph.upsert({
      originalUrl: raw,
      normalizedUrl: normalized,
      classification,
      initiatorUrl: baseUrl,
    });
    graph.addEdge(routeNodeId, node.id, attr);
    discovered++;
  };

  // <link rel="stylesheet|preload|prefetch|modulepreload|icon|apple-touch-icon|manifest">
  $('link[href]').each((_, el) => {
    const href = $(el).attr("href");
    if (href) record(href);
  });
  // <script src> (including type=module)
  $('script[src]').each((_, el) => {
    const src = $(el).attr("src");
    if (src) record(src);
  });
  // <img src> and srcset candidates
  $('img[src]').each((_, el) => {
    const src = $(el).attr("src");
    if (src) record(src);
  });
  $('img[srcset]').each((_, el) => {
    const srcset = $(el).attr("srcset") ?? "";
    for (const cand of srcset.split(",")) {
      const u = cand.trim().split(/\s+/)[0];
      if (u) record(u);
    }
  });
  // <source srcset> (picture element)
  $('source[srcset]').each((_, el) => {
    const srcset = $(el).attr("srcset") ?? "";
    for (const cand of srcset.split(",")) {
      const u = cand.trim().split(/\s+/)[0];
      if (u) record(u);
    }
  });
  // <source src> for audio/video
  $('source[src]').each((_, el) => {
    const src = $(el).attr("src");
    if (src) record(src);
  });
  // <video poster>, <audio src>
  $("video[poster]").each((_, el) => {
    const p = $(el).attr("poster");
    if (p) record(p);
  });
  // <a href> — recorded for route discovery (PUBLISHED_ROUTE classification)
  $('a[href]').each((_, el) => {
    const href = $(el).attr("href");
    if (href) record(href);
  });
  // <meta> tags with URL content — harvest for localization.
  // Per critical bug fix: framer-search-index, framer-search-index-fallback,
  // og:image, twitter:image all reference external resources that must be
  // downloaded and rewritten to local paths.
  $('meta[content]').each((_, el) => {
    const $el = $(el);
    const content = $el.attr("content");
    if (!content) return;
    const name = ($el.attr("name") ?? "").toLowerCase();
    const property = ($el.attr("property") ?? "").toLowerCase();
    // Search index JSON files
    if (name === "framer-search-index" || name === "framer-search-index-fallback") {
      if (/^https?:\/\//i.test(content)) record(content);
      return;
    }
    // Social share images
    if (property === "og:image" || name === "twitter:image") {
      if (/^https?:\/\//i.test(content)) record(content);
      return;
    }
  });
  // Inline <style> blocks & style="" attributes
  $("style").each((_, el) => {
    const css = $(el).html() ?? "";
    harvestCssUrls(css, baseUrl, ctx, graph, routeNodeId);
  });
  $("[style]").each((_, el) => {
    const css = $(el).attr("style") ?? "";
    harvestCssUrls(css, baseUrl, ctx, graph, routeNodeId);
  });

  return { discovered };
}

/** Find url(...) and @import tokens inside a CSS string and register them. */
export function harvestCssUrls(
  css: string,
  baseUrl: string,
  ctx: ClassifyContext,
  graph: ResourceGraph,
  fromNodeId: string,
): void {
  // url(...) — supports double, single, and unquoted variants
  const urlRe = /url\(\s*(?:"([^"]*)"|'([^']*)'|([^)\s]+))\s*\)/gi;
  let m: RegExpExecArray | null;
  while ((m = urlRe.exec(css))) {
    const u = m[1] ?? m[2] ?? m[3];
    if (!u) continue;
    const abs = resolveUrl(u, baseUrl);
    if (!abs) continue;
    const normalized = normalizeUrl(abs);
    const c = classifyUrl(u, ctx);
    if (c === "INFORMATIONAL_STRING") continue;
    const node = graph.upsert({
      originalUrl: u,
      normalizedUrl: normalized,
      classification: c,
      initiatorUrl: baseUrl,
    });
    graph.addEdge(fromNodeId, node.id, "CSS_URL");
  }
  // @import "x";  @import url(x);
  const importRe = /@import\s+(?:url\(\s*)?["']?([^"')]+)["']?\s*\)?\s*;/gi;
  while ((m = importRe.exec(css))) {
    const u = m[1];
    if (!u) continue;
    const abs = resolveUrl(u, baseUrl);
    if (!abs) continue;
    const normalized = normalizeUrl(abs);
    const c = classifyUrl(u, ctx);
    if (c === "INFORMATIONAL_STRING") continue;
    const node = graph.upsert({
      originalUrl: u,
      normalizedUrl: normalized,
      classification: c,
      initiatorUrl: baseUrl,
    });
    graph.addEdge(fromNodeId, node.id, "CSS_URL");
  }
}

/**
 * Parse a JS module text and harvest:
 *  - static imports: import x from "..." / import "..."
 *  - dynamic imports: import("...")
 *  - asset-like string literals hosted on framerusercontent.com
 * Adds STATIC_IMPORT / DYNAMIC_IMPORT edges accordingly.
 *
 * Uses es-module-lexer for accurate offset scanning of imports/exports.
 */
export async function harvestJsResources(
  code: string,
  baseUrl: string,
  ctx: ClassifyContext,
  graph: ResourceGraph,
  fromNodeId: string,
  logger?: StructuredLogger,
): Promise<{ staticImports: number; dynamicImports: number; assetLiterals: number }> {
  let staticImports = 0;
  let dynamicImports = 0;
  let assetLiterals = 0;

  let imports: ReadonlyArray<Record<string, unknown>>;
  try {
    const mod = await import("es-module-lexer");
    const result = mod.parse(code);
    imports = result[0] as unknown as ReadonlyArray<Record<string, unknown>>;
  } catch (err) {
    logger?.warn("es-module-lexer parse failed, falling back to regex", {
      error: err instanceof Error ? err.message : String(err),
    });
    // Fallback: very conservative regex for static imports only
    const re = /import\s+(?:[\s\S]*?\s+from\s+|)\s*["']([^"']+)["']/g;
    let mm: RegExpExecArray | null;
    while ((mm = re.exec(code))) {
      const u = mm[1];
      const c = classifyUrl(u, ctx);
      if (c === "INFORMATIONAL_STRING") continue;
      const abs = resolveUrl(u, baseUrl);
      if (!abs) continue;
      const node = graph.upsert({
        originalUrl: u,
        normalizedUrl: normalizeUrl(abs),
        classification: c,
        initiatorUrl: baseUrl,
      });
      graph.addEdge(fromNodeId, node.id, "STATIC_IMPORT");
      staticImports++;
    }
    return { staticImports, dynamicImports, assetLiterals };
  }

  for (const imp of imports) {
    // Support both old (s/e/d) and new (start/end/type/specifier) es-module-lexer API
    const s = (imp.s as number) ?? (imp.start as number);
    const e = (imp.e as number) ?? (imp.end as number);
    const impType = (imp.type as string) ?? (imp.d !== undefined ? ((imp.d as number) > -1 ? "dynamic" : "static") : "static");
    // SKIP import-meta — don't harvest import.meta.url as a dependency
    if (impType === "import-meta") continue;
    const isDynamic = impType === "dynamic";
    const specifier = (imp.specifier as string) ?? code.slice(s, e);
    if (!specifier) continue;
    const c = classifyUrl(specifier, ctx);
    if (c === "INFORMATIONAL_STRING") continue;
    const abs = resolveUrl(specifier, baseUrl);
    if (!abs) continue;
    const node = graph.upsert({
      originalUrl: specifier,
      normalizedUrl: normalizeUrl(abs),
      classification: c,
      initiatorUrl: baseUrl,
    });
    graph.addEdge(fromNodeId, node.id, isDynamic ? "DYNAMIC_IMPORT" : "STATIC_IMPORT");
    if (isDynamic) dynamicImports++;
    else staticImports++;
  }

  // Asset literals: scan for quoted strings that look like framerusercontent URLs
  const strRe = /["'`]([^"'`\n]{0,512}?)["'`]/g;
  let mm: RegExpExecArray | null;
  while ((mm = strRe.exec(code))) {
    const s = mm[1];
    if (!s) continue;
    if (!/framerusercontent\.com\/(?:images|media|static|sites|modules)/i.test(s)) {
      continue;
    }
    const c = classifyUrl(s, ctx);
    if (c === "INFORMATIONAL_STRING" || c === "FRAMER_EDITOR" || c === "FRAMER_TELEMETRY") continue;
    const abs = resolveUrl(s, baseUrl);
    if (!abs) continue;
    const node = graph.upsert({
      originalUrl: s,
      normalizedUrl: normalizeUrl(abs),
      classification: c,
      initiatorUrl: baseUrl,
    });
    graph.addEdge(fromNodeId, node.id, "STATIC_IMPORT");
    assetLiterals++;
  }

  // CMS data files: scan for .framercms references in new URL() calls.
  // These are Framer CMS data files that the runtime loads via:
  //   new URL("./YhHwar7TQ-chunk-default-0.framercms", import.meta.url)
  //   .href.replace("/modules/", "/cms/")
  // The runtime fetches from /assets/js/cms/*.framercms
  // We need to download them from the Framer CDN (same directory as the module)
  // and place them at /assets/js/cms/ (the runtime's /modules/ → /cms/ replacement
  // happens at browser time, not at download time).
  const cmsRe = /["'`]([^"'`]*?\.framercms)["'`]/g;
  while ((mm = cmsRe.exec(code))) {
    const s = mm[1];
    if (!s) continue;
    // Resolve relative to the module's base URL (Framer CDN)
    const abs = resolveUrl(s, baseUrl);
    if (!abs) continue;
    // Download from the resolved URL (same directory as the JS module on Framer CDN)
    const node = graph.upsert({
      originalUrl: s,
      normalizedUrl: normalizeUrl(abs),
      classification: "FRAMER_ASSET",
      initiatorUrl: baseUrl,
    });
    graph.addEdge(fromNodeId, node.id, "FETCH");
    assetLiterals++;
  }

  return { staticImports, dynamicImports, assetLiterals };
}
