/**
 * YesCode — Structured JSON logger with real-time event bus forwarding.
 *
 * Per rules.md OBSERVABILITY section: each log event carries timestamp,
 * level, jobId, stage, message, and metadata. The event bus forwards
 * events to the SSE progress stream.
 */

import type { EventEmitter } from "node:events";
import type { PipelineStageName } from "./pipeline";

export type LogLevel = "INFO" | "WARN" | "ERROR" | "DEBUG";

export interface LogEvent {
  timestamp: number;
  level: LogLevel;
  jobId: string;
  stage: PipelineStageName;
  message: string;
  metadata?: Record<string, unknown>;
}

export class StructuredLogger {
  constructor(
    private readonly jobId: string,
    private readonly stage: () => PipelineStageName,
    private readonly bus: EventEmitter,
  ) {}

  log(
    level: LogLevel,
    message: string,
    metadata?: Record<string, unknown>,
    stage?: PipelineStageName,
  ): LogEvent {
    const ev: LogEvent = {
      timestamp: Date.now(),
      level,
      jobId: this.jobId,
      stage: stage ?? this.stage(),
      message,
      metadata,
    };
    this.bus.emit("log", ev);
    // Console mirror for dev server logs
    const meta = metadata ? " " + JSON.stringify(metadata) : "";
    // eslint-disable-next-line no-console
    console.log(
      `[yescode][${ev.stage}][${level}] ${message}${meta}`,
    );
    return ev;
  }

  info(m: string, meta?: Record<string, unknown>, stage?: PipelineStageName) {
    return this.log("INFO", m, meta, stage);
  }
  warn(m: string, meta?: Record<string, unknown>, stage?: PipelineStageName) {
    return this.log("WARN", m, meta, stage);
  }
  error(m: string, meta?: Record<string, unknown>, stage?: PipelineStageName) {
    return this.log("ERROR", m, meta, stage);
  }
  debug(m: string, meta?: Record<string, unknown>, stage?: PipelineStageName) {
    return this.log("DEBUG", m, meta, stage);
  }
}
