/**
 * YesCode — URL Classifier (12-variant taxonomy).
 *
 * Per rules.md, every URL discovered anywhere (HTML, CSS, JS, Network, Headers)
 * must be classified into exactly one of these 12 categories. This module is
 * pure and side-effect free so it can be unit-tested in isolation.
 */

export type UrlClassification =
  | "PUBLISHED_ROUTE"
  | "FRAMER_ASSET"
  | "FRAMER_RUNTIME"
  | "FRAMER_TELEMETRY"
  | "FRAMER_EDITOR"
  | "FRAMER_BOOTSTRAP"
  | "THIRD_PARTY_STATIC_ASSET"
  | "THIRD_PARTY_API"
  | "USER_CODE"
  | "EXTERNAL_UNSUPPORTED"
  | "LOCAL_RESOURCE"
  | "INFORMATIONAL_STRING";

const FRAMER_HOSTS = [
  "framer.com",
  "framerusercontent.com",
  "framer.ai",
  "framer.app",
  "framerstatic.com",
  "framercanvas.com",
] as const;

const THIRD_PARTY_STATIC_HOSTS = [
  "fonts.googleapis.com",
  "fonts.gstatic.com",
  "cdn.jsdelivr.net",
  "unpkg.com",
  "cdnjs.cloudflare.com",
  "fonts.bunny.net",
] as const;

const THIRD_PARTY_API_HOSTS = [
  "api.stripe.com",
  "formspree.io",
  "api.formbucket.com",
  "api.convertkit.com",
  "api.mailchimp.com",
  "api.hubapi.com",
  "api.sanity.io",
] as const;

/** Third-party analytics hosts — classified as THIRD_PARTY_API but with a
 *  special "analytics" flag so the NIT doesn't fail when they're unreachable.
 *  Per master prompt P5: "The exported site must remain fully functional
 *  without Yandex Metrica. NIT must NOT fail merely because optional
 *  analytics are unavailable." */
const THIRD_PARTY_ANALYTICS_HOSTS = [
  "mc.yandex.ru",
  "mc.yandex.com",
  "www.google-analytics.com",
  "google-analytics.com",
  "www.googletagmanager.com",
  "googletagmanager.com",
  "connect.facebook.net",
  "www.facebook.com",
  "analytics.google.com",
  "hm.baidu.com",
  "clarity.ms",
  "www.clarity.ms",
  "plausible.io",
  "stats.g.doubleclick.net",
] as const;

/** Check if a host is a known third-party analytics provider. */
export function isThirdPartyAnalytics(host: string): boolean {
  const h = host.toLowerCase();
  return THIRD_PARTY_ANALYTICS_HOSTS.some((ah) => h === ah || h.endsWith("." + ah));
}

/** True if `s` looks like a real fetch URL (not an SVG namespace, schema.org, etc.). */
export function looksLikeRealUrl(s: string): boolean {
  if (!s) return false;
  if (!/^https?:\/\//i.test(s)) return false;
  // Common informational namespaces that match URL regex but are never fetched.
  const informational = [
    "http://www.w3.org/",
    "http://schema.org",
    "https://schema.org",
    "http://purl.org/",
    "http://www.opengis.net/",
    "http://www.mozilla.org/",
    "http://example.com/",
    "http://example.org/",
  ];
  return !informational.some((p) => s.startsWith(p));
}

function hostMatches(host: string, list: readonly string[]): boolean {
  return list.some((h) => host === h || host.endsWith("." + h));
}

export interface ClassifyContext {
  /** Origin of the target Framer site, e.g. https://example.framer.website */
  targetOrigin: string;
  /** Origin of the page that referenced this URL (for relative path resolution). */
  initiatorOrigin: string;
}

/**
 * Classify a raw URL string. `raw` may be relative or absolute.
 * Returns LOCAL_RESOURCE for already-local relative paths and
 * INFORMATIONAL_STRING for namespaces that look like URLs but aren't fetches.
 */
export function classifyUrl(raw: string, ctx: ClassifyContext): UrlClassification {
  const trimmed = raw.trim();
  if (!trimmed) return "INFORMATIONAL_STRING";

  // Already-local relative path
  if (
    trimmed.startsWith("/") ||
    trimmed.startsWith("./") ||
    trimmed.startsWith("../")
  ) {
    return "LOCAL_RESOURCE";
  }

  // data: URIs are local
  if (trimmed.startsWith("data:")) return "LOCAL_RESOURCE";

  // Fallback: if not absolute http(s), treat as informational
  if (!/^https?:\/\//i.test(trimmed)) {
    return "INFORMATIONAL_STRING";
  }

  if (!looksLikeRealUrl(trimmed)) return "INFORMATIONAL_STRING";

  let url: URL;
  try {
    url = new URL(trimmed);
  } catch {
    return "INFORMATIONAL_STRING";
  }

  const host = url.hostname.toLowerCase();
  const path = url.pathname.toLowerCase();
  const fullHref = url.href.toLowerCase();

  // Editor barrier — never crawl.
  // CRITICAL FIX per CMS Route Discovery Patch: do NOT use /projects/ or
  // /templates/ as editor barriers — these are valid CMS collection paths
  // on published sites (e.g. /projects/matti, /blog/article, /cases/foo).
  // Only /edit/ and /canvas/ are genuine editor infrastructure paths.
  // The distinction is origin-based, not pathname-based:
  //   https://example.framer.ai/projects/matti → PUBLISHED_ROUTE (not editor)
  //   https://example.framercanvas.com/projects/matti → FRAMER_EDITOR (canvas origin)
  if (
    hostMatches(host, FRAMER_HOSTS) &&
    (/\/edit\//.test(path) ||
      /\/canvas\//.test(path) ||
      path.startsWith("/edit") ||
      path.startsWith("/canvas"))
  ) {
    return "FRAMER_EDITOR";
  }

  // All other framer.com/* paths (pricing, m/, functions/, api/, etc.)
  // are Framer platform infrastructure — classify as FRAMER_EDITOR so they
  // get stripped from JS and don't cause runtime calls to Framer.
  if (host === "framer.com" || host === "www.framer.com") {
    // Only the root "/" is informational (e.g. "https://www.framer.com/")
    // Everything else is platform infrastructure
    if (path !== "/" && path !== "") {
      return "FRAMER_EDITOR";
    }
  }

  // Telemetry & API
  if (
    host === "events.framer.com" ||
    host === "api.framer.com" ||
    host === "stats.framer.com" ||
    host === "telemetry.framer.com"
  ) {
    return "FRAMER_TELEMETRY";
  }

  // Framer static assets (images, media)
  if (host === "framerusercontent.com") {
    if (path.startsWith("/images/") || path.startsWith("/media/")) {
      return "FRAMER_ASSET";
    }
    if (path.startsWith("/sites/") || path.startsWith("/modules/")) {
      return "FRAMER_RUNTIME";
    }
    // Fallback: treat other framerusercontent paths as assets
    return "FRAMER_ASSET";
  }

  // framerstatic.com — Framer CDN for fonts (Inter, etc.)
  if (host === "framerstatic.com" || host === "app.framerstatic.com") {
    return "FRAMER_ASSET";
  }

  // framercanvas.com — editor/canvas infrastructure, never crawl
  if (host === "framercanvas.com" || host.endsWith(".framercanvas.com")) {
    return "FRAMER_EDITOR";
  }

  // Framer bootstrap inline-script targets — usually framer.ai live preview
  if (host.endsWith("framer.ai") && /\/static|\/bootstrap|\/preview/i.test(path)) {
    return "FRAMER_BOOTSTRAP";
  }

  // Third-party static assets
  if (hostMatches(host, THIRD_PARTY_STATIC_HOSTS)) {
    return "THIRD_PARTY_STATIC_ASSET";
  }

  // Third-party APIs (server-backed dynamic)
  if (hostMatches(host, THIRD_PARTY_API_HOSTS)) {
    return "THIRD_PARTY_API";
  }

  // External unsupported server-backed infra (heuristic: path contains
  // common dynamic API keywords and not a static asset extension)
  const ext = path.split(".").pop() ?? "";
  const staticExt = [
    "js", "mjs", "css", "json", "svg", "png", "jpg", "jpeg", "webp",
    "gif", "ico", "woff", "woff2", "ttf", "otf", "eot", "mp4", "webm",
    "mov", "avi", "txt", "xml", "html", "htm", "map", "webmanifest",
  ];
  if (!staticExt.includes(ext)) {
    if (/\/api\/|\/v1\/|\/v2\/|\/graphql|\/auth\//i.test(path)) {
      return "EXTERNAL_UNSUPPORTED";
    }
  }

  // Same-origin route on the target site
  const targetHost = new URL(ctx.targetOrigin).hostname.toLowerCase();
  if (host === targetHost || host.endsWith("." + targetHost)) {
    return "PUBLISHED_ROUTE";
  }

  // Same-origin (initiator) but not the target — unusual, treat as route
  const initiatorHost = new URL(ctx.initiatorOrigin).hostname.toLowerCase();
  if (host === initiatorHost) {
    return "PUBLISHED_ROUTE";
  }

  // Anything else absolute — informational (string literal that matched URL regex)
  // We only get here for things like https://schema.org which is already filtered,
  // so this is conservative.
  return "INFORMATIONAL_STRING";
}

/** Quick predicate: is this classification something we should download & localize? */
export function shouldDownload(c: UrlClassification): boolean {
  return (
    c === "FRAMER_ASSET" ||
    c === "FRAMER_RUNTIME" ||
    c === "THIRD_PARTY_STATIC_ASSET" ||
    c === "FRAMER_BOOTSTRAP"
  );
}

/** Predicate: should this URL be stripped entirely (telemetry, editor, bootstrap)? */
export function shouldStrip(c: UrlClassification): boolean {
  return (
    c === "FRAMER_TELEMETRY" ||
    c === "FRAMER_EDITOR" ||
    c === "FRAMER_BOOTSTRAP"
  );
}

/** Predicate: should this URL be preserved verbatim (third-party API)? */
export function shouldPreserve(c: UrlClassification): boolean {
  return (
    c === "THIRD_PARTY_API" ||
    c === "EXTERNAL_UNSUPPORTED" ||
    c === "USER_CODE"
  );
}

/** Returns true when the host is on the Framer blacklist (used by NIT). */
export function isFramerHost(host: string): boolean {
  const h = host.toLowerCase();
  return FRAMER_HOSTS.some((fh) => h === fh || h.endsWith("." + fh));
}
