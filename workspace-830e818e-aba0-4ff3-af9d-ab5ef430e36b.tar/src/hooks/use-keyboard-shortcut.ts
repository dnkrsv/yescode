"use client";

import { useEffect } from "react";

interface ShortcutOptions {
  /** Key combination, e.g. "mod+enter" (mod = ctrl on win/linux, cmd on mac). */
  combo: string;
  handler: () => void;
  /** If false, shortcut is disabled. */
  enabled?: boolean;
  /** Don't trigger when focus is inside these tag names. Default: ["input","textarea","select"] unless allowInInput. */
  allowInInput?: boolean;
  /** Prevent default browser behavior. Default: true. */
  preventDefault?: boolean;
}

function isMac(): boolean {
  if (typeof navigator === "undefined") return false;
  return /Mac|iPhone|iPad/.test(navigator.platform || navigator.userAgent);
}

function matchesCombo(e: KeyboardEvent, combo: string): boolean {
  const parts = combo.toLowerCase().split("+").map((p) => p.trim());
  const wantMod = parts.includes("mod");
  const wantCtrl = parts.includes("ctrl");
  const wantShift = parts.includes("shift");
  const wantAlt = parts.includes("alt");
  const key = parts.find((p) => !["mod", "ctrl", "shift", "alt"].includes(p));
  if (!key) return false;

  const mac = isMac();
  const modOk = wantMod ? (mac ? e.metaKey : e.ctrlKey) : true;
  const ctrlOk = wantCtrl ? e.ctrlKey : true;
  const shiftOk = wantShift ? e.shiftKey : true;
  const altOk = wantAlt ? e.altKey : true;
  // When mod not wanted, ensure neither meta nor ctrl is pressed (avoid hijack)
  const noMod = !wantMod && !wantCtrl ? !e.metaKey && !e.ctrlKey : true;

  return (
    modOk &&
    ctrlOk &&
    shiftOk &&
    altOk &&
    noMod &&
    e.key.toLowerCase() === key
  );
}

/**
 * Global keyboard shortcut hook. Registers a single shortcut on mount.
 *
 * Example:
 *   useKeyboardShortcut("mod+enter", () => submit(), { enabled: !disabled });
 */
export function useKeyboardShortcut({
  combo,
  handler,
  enabled = true,
  allowInInput = false,
  preventDefault = true,
}: ShortcutOptions) {
  useEffect(() => {
    if (!enabled) return;
    const onKeyDown = (e: KeyboardEvent) => {
      if (!matchesCombo(e, combo)) return;
      if (!allowInInput) {
        const el = e.target as HTMLElement | null;
        const tag = el?.tagName?.toLowerCase();
        if (tag === "input" || tag === "textarea" || tag === "select" || el?.isContentEditable) {
          // Allow mod+enter inside inputs (common submit pattern) — re-check
          if (!(combo.includes("mod") || combo.includes("ctrl"))) return;
        }
      }
      if (preventDefault) e.preventDefault();
      handler();
    };
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, [combo, handler, enabled, allowInInput, preventDefault]);
}
