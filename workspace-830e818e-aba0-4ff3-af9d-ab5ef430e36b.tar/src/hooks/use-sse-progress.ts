"use client";

import { useEffect, useRef } from "react";
import { useJobStore } from "@/stores/job-store";
import type { ProgressEvent, ExportMetrics } from "@/lib/exporter/pipeline";

/**
 * Subscribes to the SSE progress stream for the active jobId and forwards
 * events into the Zustand store. Uses the standard browser EventSource API.
 *
 * The Next.js API route GET /api/export/[jobId]/progress emits `text/event-stream`
 * with one `data:` line per ProgressEvent (JSON-encoded).
 */
export function useSSEProgress(jobId: string | null) {
  const ingestEvent = useJobStore((s) => s.ingestEvent);
  const finishJob = useJobStore((s) => s.finishJob);
  const failJob = useJobStore((s) => s.failJob);
  const sourceRef = useRef<EventSource | null>(null);

  useEffect(() => {
    if (!jobId) return;
    const source = new EventSource(`/api/export/${jobId}/progress`);
    sourceRef.current = source;

    const onMessage = (e: MessageEvent) => {
      try {
        const payload = JSON.parse(e.data) as
          | ProgressEvent
          | { kind: "done"; metrics: ExportMetrics; zipPath: string }
          | { kind: "error"; error: string };
        if ("kind" in payload) {
          if (payload.kind === "done") {
            finishJob(payload.metrics, payload.zipPath);
            source.close();
          } else if (payload.kind === "error") {
            failJob(payload.error);
            source.close();
          }
          return;
        }
        ingestEvent(payload);
        if (
          payload.stage === "COMPLETED" &&
          payload.progress >= 100
        ) {
          // Wait for the explicit `done` event with metrics; keep stream open.
        }
      } catch (err) {
        // Ignore malformed line
        console.warn("SSE parse error:", err);
      }
    };

    const onError = () => {
      // EventSource will auto-reconnect; we only fail if store is still running.
      const s = useJobStore.getState();
      if (s.status === "running" && source.readyState === EventSource.CLOSED) {
        failJob("Connection to progress stream lost.");
      }
    };

    source.addEventListener("message", onMessage as EventListener);
    source.addEventListener("error", onError as EventListener);

    return () => {
      source.removeEventListener("message", onMessage as EventListener);
      source.removeEventListener("error", onError as EventListener);
      source.close();
      sourceRef.current = null;
    };
  }, [jobId, ingestEvent, finishJob, failJob]);
}
