"use client";

import { Hero } from "@/components/yescode/hero";
import { ExportForm } from "@/components/yescode/export-form";
import { StageTracker } from "@/components/yescode/stage-tracker";
import { LogDrawer } from "@/components/yescode/log-drawer";
import { ResultCards } from "@/components/yescode/result-cards";
import { JobHistoryPanel } from "@/components/yescode/job-history-panel";
import { ShortcutsHelp } from "@/components/yescode/shortcuts-help";
import { OnboardingHint } from "@/components/yescode/onboarding-hint";
import { SiteFooter } from "@/components/yescode/site-footer";
import { useJobStore } from "@/stores/job-store";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { motion, AnimatePresence } from "framer-motion";
import { ArrowRight, FileArchive, ScanLine, Network, Cpu } from "lucide-react";

const FEATURE_POINTS = [
  {
    icon: FileArchive,
    title: "Self-contained archive",
    body: "HTML, CSS, JS, fonts, media — all rewritten to local paths. No external CDN.",
  },
  {
    icon: ScanLine,
    title: "Residual scan",
    body: "Post-rewrite sweep guarantees zero framerusercontent.com references remain.",
  },
  {
    icon: Network,
    title: "NIT-gated",
    body: "Network Independence Test runs every route with Framer hosts blocked at the firewall.",
  },
  {
    icon: Cpu,
    title: "AST rewriting",
    body: "es-module-lexer + @babel/parser + magic-string for surgical JS module rewrites.",
  },
];

export default function Home() {
  const status = useJobStore((s) => s.status);
  const showProgress = status === "running";

  return (
    <div className="min-h-screen flex flex-col bg-background text-foreground">
      <Hero />

      <main className="flex-1 mx-auto w-full max-w-6xl px-4 sm:px-6 py-8 sm:py-12 space-y-10">
        {/* Input + live panel */}
        <section
          aria-label="Export input"
          className="rounded-2xl border border-border bg-card/60 backdrop-blur shadow-sm p-5 sm:p-7"
        >
          <ExportForm />

          <AnimatePresence>
            {showProgress && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: "auto" }}
                exit={{ opacity: 0, height: 0 }}
                transition={{ duration: 0.3 }}
                className="overflow-hidden"
              >
                <div className="mt-7 grid grid-cols-1 lg:grid-cols-5 gap-5">
                  <Card className="lg:col-span-2 shadow-sm">
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm font-mono uppercase tracking-wider">
                        Pipeline
                      </CardTitle>
                      <CardDescription className="text-[11px] font-mono">
                        14 sequential stages
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <StageTracker />
                    </CardContent>
                  </Card>
                  <div className="lg:col-span-3">
                    <LogDrawer />
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          <div className="mt-8">
            <ResultCards />
          </div>
        </section>

        {/* Job history panel — always visible when there are past jobs */}
        <JobHistoryPanel />

        {/* Feature strip (hidden during active export) */}
        {!showProgress && status !== "completed" && (
          <section
            aria-label="How it works"
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4"
          >
            {FEATURE_POINTS.map((f, i) => (
              <motion.div
                key={f.title}
                initial={{ opacity: 0, y: 10 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.4, delay: i * 0.08 }}
              >
                <Card className="h-full hover:border-accent/40 transition-colors hover:shadow-md group">
                  <CardHeader className="pb-3">
                    <div className="flex items-center gap-3">
                      <div className="rounded-md bg-accent/15 p-2 group-hover:bg-accent/25 transition-colors">
                        <f.icon className="h-4 w-4 text-accent" />
                      </div>
                      <CardTitle className="text-base">{f.title}</CardTitle>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-muted-foreground leading-relaxed">
                      {f.body}
                    </p>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </section>
        )}

        {/* Pipeline diagram */}
        {!showProgress && status !== "completed" && (
          <section aria-label="Pipeline overview" className="rounded-2xl border border-border bg-card/40 p-6">
            <h2 className="font-mono text-xs uppercase tracking-wider text-muted-foreground mb-4">
              Pipeline · 14 stages
            </h2>
            <div className="yescode-scroll overflow-x-auto -mx-2 px-2">
              <div className="flex items-center gap-1 min-w-max">
                {[
                  "PREFLIGHT",
                  "DISCOVERY",
                  "CAPTURE",
                  "GRAPH",
                  "MATERIALIZE",
                  "REWRITE",
                  "CLEANUP",
                  "ROUTING",
                  "SEO",
                  "RESIDUAL",
                  "NIT",
                  "PACKAGING",
                ].map((s, i, arr) => (
                  <div key={s} className="flex items-center gap-1">
                    <span className="rounded-md border border-border bg-background px-2.5 py-1.5 font-mono text-[10px] uppercase tracking-tight whitespace-nowrap">
                      {s}
                    </span>
                    {i < arr.length - 1 && (
                      <ArrowRight className="h-3 w-3 text-muted-foreground/60" />
                    )}
                  </div>
                ))}
              </div>
            </div>
          </section>
        )}
      </main>

      <ShortcutsHelp />
      <OnboardingHint />
      <SiteFooter />
    </div>
  );
}
