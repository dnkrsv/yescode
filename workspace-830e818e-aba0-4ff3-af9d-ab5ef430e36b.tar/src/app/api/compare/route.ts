/**
 * YesCode — GET /api/compare?jobA=X&jobB=Y
 *
 * Compares the file contents of two completed job ZIPs. Returns:
 *   - added: files in B not in A
 *   - removed: files in A not in B
 *   - changed: files in both but different size or content
 *   - unchanged: files in both with identical content
 *
 * Used by the CompareExportsDialog to show a visual diff.
 */

import { NextRequest, NextResponse } from "next/server";
import { promises as fs } from "node:fs";
import yauzl from "yauzl";
import { jobManager } from "@/lib/exporter/jobs";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

interface ZipEntry {
  fileName: string;
  buffer: Buffer;
  uncompressedSize: number;
}

function readZipAll(zipPath: string): Promise<Map<string, ZipEntry>> {
  return new Promise((resolve, reject) => {
    const entries = new Map<string, ZipEntry>();
    yauzl.open(zipPath, { lazyEntries: true, autoClose: true }, (err, zip) => {
      if (err || !zip) {
        reject(err ?? new Error("Failed to open ZIP"));
        return;
      }
      zip.on("entry", (entry: yauzl.Entry) => {
        if (entry.fileName.endsWith("/")) {
          zip.readEntry();
          return;
        }
        zip.openReadStream(entry, (e, stream) => {
          if (e || !stream) {
            zip.readEntry();
            return;
          }
          const chunks: Buffer[] = [];
          stream.on("data", (c: Buffer) => chunks.push(c));
          stream.on("end", () => {
            entries.set(entry.fileName, {
              fileName: entry.fileName,
              buffer: Buffer.concat(chunks),
              uncompressedSize: entry.uncompressedSize,
            });
            zip.readEntry();
          });
          stream.on("error", () => zip.readEntry());
        });
      });
      zip.on("end", () => resolve(entries));
      zip.on("error", reject);
      zip.readEntry();
    });
  });
}

function simpleHash(buf: Buffer): string {
  // FNV-1a hash for quick content comparison
  let hash = 0x811c9dc5;
  for (let i = 0; i < buf.length; i++) {
    hash ^= buf[i];
    hash = Math.imul(hash, 0x01000193);
  }
  return (hash >>> 0).toString(16).padStart(8, "0");
}

export async function GET(req: NextRequest) {
  const jobA = req.nextUrl.searchParams.get("jobA");
  const jobB = req.nextUrl.searchParams.get("jobB");
  if (!jobA || !jobB) {
    return NextResponse.json(
      { error: "Both jobA and jobB query params required" },
      { status: 422 },
    );
  }
  if (jobA === jobB) {
    return NextResponse.json(
      { error: "Cannot compare a job with itself" },
      { status: 422 },
    );
  }

  const [stateA, stateB] = await Promise.all([
    jobManager.loadState(jobA),
    jobManager.loadState(jobB),
  ]);
  if (!stateA || !stateB) {
    return NextResponse.json(
      { error: "Job not found", missing: !stateA ? jobA : jobB },
      { status: 404 },
    );
  }
  if (stateA.status !== "completed" || stateB.status !== "completed") {
    return NextResponse.json(
      { error: "Both jobs must be completed" },
      { status: 409 },
    );
  }
  if (!stateA.outputZipPath || !stateB.outputZipPath) {
    return NextResponse.json(
      { error: "ZIP path missing" },
      { status: 409 },
    );
  }

  try {
    await Promise.all([
      fs.access(stateA.outputZipPath),
      fs.access(stateB.outputZipPath),
    ]);
  } catch {
    return NextResponse.json(
      { error: "ZIP file missing on disk" },
      { status: 404 },
    );
  }

  try {
    const [entriesA, entriesB] = await Promise.all([
      readZipAll(stateA.outputZipPath),
      readZipAll(stateB.outputZipPath),
    ]);

    const allFiles = new Set([...entriesA.keys(), ...entriesB.keys()]);
    const added: Array<{ path: string; size: number }> = [];
    const removed: Array<{ path: string; size: number }> = [];
    const changed: Array<{ path: string; sizeA: number; sizeB: number }> = [];
    const unchanged: string[] = [];

    for (const file of allFiles) {
      const a = entriesA.get(file);
      const b = entriesB.get(file);
      if (a && !b) {
        removed.push({ path: file, size: a.uncompressedSize });
      } else if (!a && b) {
        added.push({ path: file, size: b.uncompressedSize });
      } else if (a && b) {
        // Compare by hash for accurate content diff
        if (simpleHash(a.buffer) === simpleHash(b.buffer)) {
          unchanged.push(file);
        } else {
          changed.push({ path: file, sizeA: a.uncompressedSize, sizeB: b.uncompressedSize });
        }
      }
    }

    added.sort((a, b) => a.path < b.path ? -1 : 1);
    removed.sort((a, b) => a.path < b.path ? -1 : 1);
    changed.sort((a, b) => a.path < b.path ? -1 : 1);

    return NextResponse.json({
      jobA: { jobId: jobA, targetUrl: stateA.targetUrl, zipName: stateA.metrics?.outputZipName },
      jobB: { jobId: jobB, targetUrl: stateB.targetUrl, zipName: stateB.metrics?.outputZipName },
      summary: {
        added: added.length,
        removed: removed.length,
        changed: changed.length,
        unchanged: unchanged.length,
        total: allFiles.size,
      },
      added,
      removed,
      changed,
      unchanged,
    });
  } catch (err) {
    return NextResponse.json(
      { error: "Failed to compare ZIPs", details: err instanceof Error ? err.message : String(err) },
      { status: 500 },
    );
  }
}
