/**
 * YesCode — GET /api/stats
 *
 * Returns aggregate dashboard metrics across all jobs:
 *   - total / completed / failed / running counts
 *   - average + max duration (ms)
 *   - total archive size (bytes)
 *   - success rate (%)
 *   - top hosts (by export count, top 5)
 *   - nit pass rate (%)
 *   - avg routes per export
 *
 * Used by the LiveStatsBar + future dashboard widgets.
 */

import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { countJobs } from "@/lib/exporter/job-store";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

interface StatsRow {
  status: string;
  metricsJson: string | null;
  targetUrl: string;
  outputZipPath: string | null;
}

export async function GET() {
  try {
    const counts = await countJobs();
    // Fetch all jobs for metric aggregation
    const rows = await db.exportJob.findMany({
      select: {
        status: true,
        metricsJson: true,
        targetUrl: true,
        outputZipPath: true,
      },
    });

    let totalDuration = 0;
    let maxDuration = 0;
    let durationCount = 0;
    let totalSize = 0;
    let totalRoutes = 0;
    let routeCount = 0;
    let nitPassed = 0;
    let nitTotal = 0;
    const hostCounts = new Map<string, number>();

    for (const row of rows as StatsRow[]) {
      if (row.metricsJson) {
        try {
          const m = JSON.parse(row.metricsJson) as {
            durationMs?: number;
            totalRoutes?: number;
            totalSizeBytes?: number;
            nitStatus?: string;
            outputZipSizeBytes?: number;
          };
          if (typeof m.durationMs === "number" && m.durationMs > 0) {
            totalDuration += m.durationMs;
            maxDuration = Math.max(maxDuration, m.durationMs);
            durationCount++;
          }
          if (typeof m.totalRoutes === "number" && m.totalRoutes > 0) {
            totalRoutes += m.totalRoutes;
            routeCount++;
          }
          if (typeof m.outputZipSizeBytes === "number") {
            totalSize += m.outputZipSizeBytes;
          }
          if (m.nitStatus && m.nitStatus !== "NOT_RUN") {
            nitTotal++;
            if (m.nitStatus === "PASSED") nitPassed++;
          }
        } catch {
          // skip malformed metrics
        }
      }
      // Host aggregation
      try {
        const host = new URL(row.targetUrl).hostname.replace(/^www\./, "");
        hostCounts.set(host, (hostCounts.get(host) ?? 0) + 1);
      } catch {
        // skip invalid URL
      }
    }

    const topHosts = [...hostCounts.entries()]
      .sort((a, b) => b[1] - a[1])
      .slice(0, 5)
      .map(([host, count]) => ({ host, count }));

    return NextResponse.json(
      {
        counts,
        successRate:
          counts.total > 0
            ? Math.round((counts.completed / counts.total) * 100)
            : 0,
        avgDurationMs:
          durationCount > 0 ? Math.round(totalDuration / durationCount) : 0,
        maxDurationMs: maxDuration,
        totalArchiveSizeBytes: totalSize,
        avgRoutesPerExport:
          routeCount > 0 ? Math.round((totalRoutes / routeCount) * 10) / 10 : 0,
        nitPassRate:
          nitTotal > 0 ? Math.round((nitPassed / nitTotal) * 100) : 0,
        topHosts,
        generatedAt: Date.now(),
      },
      {
        headers: {
          "Cache-Control": "no-store",
          "Content-Type": "application/json; charset=utf-8",
        },
      },
    );
  } catch (err) {
    return NextResponse.json(
      {
        error: "Failed to compute stats",
        details: err instanceof Error ? err.message : String(err),
      },
      { status: 500 },
    );
  }
}
