/**
 * YesCode — GET /api/stats/history
 *
 * Returns time-series data for the stats dashboard:
 *   - exports over time (grouped by day, last 30 days)
 *   - duration trend (per export, last 50)
 *   - success rate over time (grouped by day)
 *   - size distribution
 *
 * Used by the StatsDashboardModal to render charts.
 */

import { NextResponse } from "next/server";
import { db } from "@/lib/db";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

interface HistoryRow {
  jobId: string;
  targetUrl: string;
  status: string;
  createdAt: Date;
  updatedAt: Date;
  metricsJson: string | null;
}

interface Metrics {
  durationMs?: number;
  totalSizeBytes?: number;
  outputZipSizeBytes?: number;
  totalRoutes?: number;
  nitStatus?: string;
}

export async function GET() {
  try {
    const rows = (await db.exportJob.findMany({
      orderBy: { createdAt: "desc" },
      take: 500,
      select: {
        jobId: true,
        targetUrl: true,
        status: true,
        createdAt: true,
        updatedAt: true,
        metricsJson: true,
      },
    })) as HistoryRow[];

    // Parse metrics
    const parsed = rows.map((r) => {
      let m: Metrics = {};
      if (r.metricsJson) {
        try {
          m = JSON.parse(r.metricsJson) as Metrics;
        } catch {
          // skip
        }
      }
      return { ...r, metrics: m };
    });

    // 1. Exports over time (group by day, last 30 days)
    const now = new Date();
    const thirtyDaysAgo = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
    const byDay = new Map<string, { total: number; completed: number; failed: number }>();
    for (let i = 0; i < 30; i++) {
      const d = new Date(now.getTime() - i * 24 * 60 * 60 * 1000);
      const key = d.toISOString().slice(0, 10);
      byDay.set(key, { total: 0, completed: 0, failed: 0 });
    }
    for (const r of parsed) {
      if (r.createdAt < thirtyDaysAgo) continue;
      const key = r.createdAt.toISOString().slice(0, 10);
      const entry = byDay.get(key);
      if (!entry) continue;
      entry.total++;
      if (r.status === "completed") entry.completed++;
      else if (r.status === "failed") entry.failed++;
    }
    const exportsOverTime = [...byDay.entries()]
      .sort((a, b) => a[0] < b[0] ? -1 : 1)
      .map(([date, counts]) => ({ date, ...counts }));

    // 2. Duration trend (last 50 completed exports with duration data)
    const durationTrend = parsed
      .filter((r) => r.status === "completed" && typeof r.metrics.durationMs === "number" && r.metrics.durationMs > 0)
      .slice(0, 50)
      .reverse()
      .map((r) => ({
        jobId: r.jobId,
        host: hostOf(r.targetUrl),
        durationMs: r.metrics.durationMs!,
        createdAt: r.createdAt.getTime(),
      }));

    // 3. Size distribution (buckets)
    const sizeBuckets = { "<1KB": 0, "1-10KB": 0, "10-100KB": 0, "100KB-1MB": 0, "1-10MB": 0, ">10MB": 0 };
    for (const r of parsed) {
      const size = r.metrics.outputZipSizeBytes ?? 0;
      if (size === 0) continue;
      if (size < 1024) sizeBuckets["<1KB"]++;
      else if (size < 10 * 1024) sizeBuckets["1-10KB"]++;
      else if (size < 100 * 1024) sizeBuckets["10-100KB"]++;
      else if (size < 1024 * 1024) sizeBuckets["100KB-1MB"]++;
      else if (size < 10 * 1024 * 1024) sizeBuckets["1-10MB"]++;
      else sizeBuckets[">10MB"]++;
    }

    // 4. Success rate over time (7-day rolling windows)
    const successRateTrend: Array<{ window: string; rate: number; total: number }> = [];
    for (let i = 0; i < 8; i++) {
      const windowEnd = new Date(now.getTime() - i * 7 * 24 * 60 * 60 * 1000);
      const windowStart = new Date(windowEnd.getTime() - 7 * 24 * 60 * 60 * 1000);
      const inWindow = parsed.filter((r) => r.createdAt >= windowStart && r.createdAt < windowEnd);
      if (inWindow.length === 0) continue;
      const completed = inWindow.filter((r) => r.status === "completed").length;
      successRateTrend.push({
        window: `${windowStart.toISOString().slice(5, 10)}–${windowEnd.toISOString().slice(5, 10)}`,
        rate: Math.round((completed / inWindow.length) * 100),
        total: inWindow.length,
      });
    }

    return NextResponse.json(
      {
        exportsOverTime,
        durationTrend,
        sizeBuckets,
        successRateTrend,
        totalAnalyzed: parsed.length,
        generatedAt: Date.now(),
      },
      {
        headers: {
          "Cache-Control": "no-store",
          "Content-Type": "application/json; charset=utf-8",
        },
      },
    );
  } catch (err) {
    return NextResponse.json(
      {
        error: "Failed to compute history stats",
        details: err instanceof Error ? err.message : String(err),
      },
      { status: 500 },
    );
  }
}

function hostOf(url: string): string {
  try {
    return new URL(url).hostname.replace(/^www\./, "");
  } catch {
    return url.slice(0, 30);
  }
}
