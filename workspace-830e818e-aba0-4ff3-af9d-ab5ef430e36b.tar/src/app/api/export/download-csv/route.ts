/**
 * YesCode — GET /api/export/download-csv
 *
 * Exports the full job history as CSV (default) or JSON (?format=json).
 * Includes: jobId, targetUrl, status, stage, createdAt, durationMs,
 * outputZipName, outputZipSizeBytes, totalRoutes, nitStatus.
 *
 * Content-Disposition: attachment; filename="yescode-jobs-{timestamp}.csv"
 */

import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

interface HistoryRow {
  jobId: string;
  targetUrl: string;
  status: string;
  stage: string;
  createdAt: Date;
  updatedAt: Date;
  metricsJson: string | null;
}

interface Metrics {
  durationMs?: number;
  outputZipName?: string;
  outputZipSizeBytes?: number;
  totalRoutes?: number;
  nitStatus?: string;
}

function escapeCsv(value: string): string {
  if (value.includes(",") || value.includes('"') || value.includes("\n")) {
    return `"${value.replace(/"/g, '""')}"`;
  }
  return value;
}

export async function GET(req: NextRequest) {
  try {
    const format = req.nextUrl.searchParams.get("format") ?? "csv";
    const rows = (await db.exportJob.findMany({
      orderBy: { createdAt: "desc" },
      take: 1000,
      select: {
        jobId: true,
        targetUrl: true,
        status: true,
        stage: true,
        createdAt: true,
        updatedAt: true,
        metricsJson: true,
      },
    })) as HistoryRow[];

    // Parse metrics
    const parsed = rows.map((r) => {
      let m: Metrics = {};
      if (r.metricsJson) {
        try {
          m = JSON.parse(r.metricsJson) as Metrics;
        } catch {
          // skip
        }
      }
      return {
        jobId: r.jobId,
        targetUrl: r.targetUrl,
        status: r.status,
        stage: r.stage,
        createdAt: r.createdAt.toISOString(),
        updatedAt: r.updatedAt.toISOString(),
        durationMs: m.durationMs ?? "",
        outputZipName: m.outputZipName ?? "",
        outputZipSizeBytes: m.outputZipSizeBytes ?? "",
        totalRoutes: m.totalRoutes ?? "",
        nitStatus: m.nitStatus ?? "",
      };
    });

    const timestamp = new Date().toISOString().slice(0, 19).replace(/[:T]/g, "-");

    if (format === "json") {
      return new NextResponse(JSON.stringify(parsed, null, 2), {
        status: 200,
        headers: {
          "Content-Type": "application/json; charset=utf-8",
          "Content-Disposition": `attachment; filename="yescode-jobs-${timestamp}.json"`,
          "Cache-Control": "no-store",
        },
      });
    }

    // CSV
    const headers = [
      "jobId",
      "targetUrl",
      "status",
      "stage",
      "createdAt",
      "updatedAt",
      "durationMs",
      "outputZipName",
      "outputZipSizeBytes",
      "totalRoutes",
      "nitStatus",
    ];
    const csvLines = [headers.join(",")];
    for (const p of parsed) {
      csvLines.push(
        headers.map((h) => escapeCsv(String(p[h as keyof typeof p] ?? ""))).join(","),
      );
    }
    const csv = csvLines.join("\n");

    return new NextResponse(csv, {
      status: 200,
      headers: {
        "Content-Type": "text/csv; charset=utf-8",
        "Content-Disposition": `attachment; filename="yescode-jobs-${timestamp}.csv"`,
        "Cache-Control": "no-store",
      },
    });
  } catch (err) {
    return NextResponse.json(
      {
        error: "Failed to export history",
        details: err instanceof Error ? err.message : String(err),
      },
      { status: 500 },
    );
  }
}
