/**
 * YesCode — GET /api/export/[jobId]/contents
 *
 * Returns a tree-structured listing of files inside the completed ZIP,
 * so the UI can render a preview tree before the user downloads.
 *
 * Response shape:
 *   {
 *     jobId, zipName, totalFiles, totalSize,
 *     tree: FileTreeNode[]
 *   }
 *
 * FileTreeNode:
 *   { type: "dir", name, children: FileTreeNode[] }
 *   { type: "file", name, size, ext }
 *
 * Reads the ZIP from disk using yauzl. Returns 404 if the job isn't
 * completed or the ZIP file is missing.
 */

import { NextRequest, NextResponse } from "next/server";
import { promises as fs } from "node:fs";
import { join, dirname, basename } from "node:path";
import yauzl from "yauzl";
import { jobManager } from "@/lib/exporter/jobs";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

interface FileTreeNode {
  type: "dir" | "file";
  name: string;
  path: string;
  children?: FileTreeNode[];
  size?: number;
  ext?: string;
}

/** Insert a file path into the tree, creating intermediate dirs as needed. */
function insertIntoTree(root: FileTreeNode, fullPath: string, size: number): void {
  const parts = fullPath.split("/").filter(Boolean);
  let current = root;
  for (let i = 0; i < parts.length; i++) {
    const part = parts[i];
    const isFile = i === parts.length - 1;
    if (isFile) {
      // Skip directory entries (paths ending with /)
      if (fullPath.endsWith("/")) return;
      current.children = current.children ?? [];
      current.children.push({
        type: "file",
        name: part,
        path: fullPath,
        size,
        ext: part.includes(".") ? part.split(".").pop()!.toLowerCase() : undefined,
      });
    } else {
      current.children = current.children ?? [];
      let dir = current.children.find((c) => c.type === "dir" && c.name === part) as FileTreeNode | undefined;
      if (!dir) {
        dir = {
          type: "dir",
          name: part,
          path: parts.slice(0, i + 1).join("/"),
          children: [],
        };
        current.children.push(dir);
      }
      current = dir;
    }
  }
}

/** Read a ZIP file and return a tree of its entries. */
function readZipTree(zipPath: string): Promise<{
  tree: FileTreeNode[];
  totalFiles: number;
  totalSize: number;
}> {
  return new Promise((resolve, reject) => {
    yauzl.open(zipPath, { lazyEntries: true, autoClose: true }, (err, zip) => {
      if (err || !zip) {
        reject(err ?? new Error("Failed to open ZIP"));
        return;
      }
      const root: FileTreeNode = {
        type: "dir",
        name: "",
        path: "",
        children: [],
      };
      let totalFiles = 0;
      let totalSize = 0;

      zip.on("entry", (entry: yauzl.Entry) => {
        if (!entry.fileName.endsWith("/")) {
          totalFiles++;
          totalSize += entry.uncompressedSize;
          insertIntoTree(root, entry.fileName, entry.uncompressedSize);
        }
        zip.readEntry();
      });
      zip.on("end", () => {
        // Sort tree: dirs first, then files, alphabetical
        const sortNode = (node: FileTreeNode) => {
          if (!node.children) return;
          node.children.sort((a, b) => {
            if (a.type !== b.type) return a.type === "dir" ? -1 : 1;
            return a.name < b.name ? -1 : a.name > b.name ? 1 : 0;
          });
          node.children.forEach(sortNode);
        };
        sortNode(root);
        resolve({ tree: root.children ?? [], totalFiles, totalSize });
      });
      zip.on("error", reject);
      zip.readEntry();
    });
  });
}

export async function GET(
  _req: NextRequest,
  { params }: { params: Promise<{ jobId: string }> },
) {
  const { jobId } = await params;
  const state = await jobManager.loadState(jobId);
  if (!state) {
    return NextResponse.json({ error: "Job not found" }, { status: 404 });
  }
  if (state.status !== "completed" || !state.outputZipPath) {
    return NextResponse.json(
      { error: "ZIP not ready", status: state.status },
      { status: 409 },
    );
  }
  const zipPath = state.outputZipPath;
  try {
    await fs.access(zipPath);
  } catch {
    return NextResponse.json({ error: "ZIP file missing on disk" }, { status: 404 });
  }
  try {
    const { tree, totalFiles, totalSize } = await readZipTree(zipPath);
    return NextResponse.json(
      {
        jobId,
        zipName: state.metrics?.outputZipName ?? basename(zipPath),
        totalFiles,
        totalSize,
        tree,
      },
      {
        headers: {
          "Cache-Control": "no-store",
          "Content-Type": "application/json; charset=utf-8",
        },
      },
    );
  } catch (err) {
    return NextResponse.json(
      { error: "Failed to read ZIP", details: err instanceof Error ? err.message : String(err) },
      { status: 500 },
    );
  }
}

void join;
void dirname;
