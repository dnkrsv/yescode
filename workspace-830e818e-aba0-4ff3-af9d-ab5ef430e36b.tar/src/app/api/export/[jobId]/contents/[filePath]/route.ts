/**
 * YesCode — GET /api/export/[jobId]/contents/[filePath]
 *
 * Reads the contents of a single file inside the completed ZIP. Used by
 * the ZipPreviewDialog's inline file viewer. Returns the file body as
 * text (truncated to 8 KB for safety) with the detected MIME type.
 *
 * Path format: the [filePath] segment is URL-encoded and may contain
 * slashes (e.g. "assets%2Fjs%2Fchunk.mjs"). We decode + sanitize.
 *
 * Response shape:
 *   { path, size, truncated, content, mime, ext }
 *
 * Returns 404 if the job/ZIP/file is missing, 422 if the file extension
 * is not previewable (binary formats).
 */

import { NextRequest, NextResponse } from "next/server";
import { promises as fs } from "node:fs";
import { basename, extname } from "node:path";
import yauzl from "yauzl";
import { jobManager } from "@/lib/exporter/jobs";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const MAX_PREVIEW_BYTES = 8 * 1024; // 8 KB cap

const PREVIEWABLE_EXT = new Set([
  "html", "htm", "css", "js", "mjs", "cjs", "json", "xml", "txt", "svg",
  "md", "csv", "yaml", "yml", "ts", "tsx", "jsx", "webmanifest", "map",
]);

const MIME_BY_EXT: Record<string, string> = {
  html: "text/html",
  htm: "text/html",
  css: "text/css",
  js: "text/javascript",
  mjs: "text/javascript",
  cjs: "text/javascript",
  json: "application/json",
  xml: "application/xml",
  txt: "text/plain",
  svg: "image/svg+xml",
  md: "text/markdown",
  csv: "text/csv",
  yaml: "text/yaml",
  yml: "text/yaml",
  ts: "text/typescript",
  tsx: "text/typescript",
  jsx: "text/javascript",
  webmanifest: "application/manifest+json",
  map: "application/json",
};

/** Read a single file from a ZIP archive. Returns null if not found. */
function readZipFile(zipPath: string, targetPath: string): Promise<{ buffer: Buffer; uncompressedSize: number } | null> {
  return new Promise((resolve, reject) => {
    yauzl.open(zipPath, { lazyEntries: true, autoClose: true }, (err, zip) => {
      if (err || !zip) {
        reject(err ?? new Error("Failed to open ZIP"));
        return;
      }
      zip.on("entry", (entry: yauzl.Entry) => {
        if (entry.fileName === targetPath && !entry.fileName.endsWith("/")) {
          zip.openReadStream(entry, (e, stream) => {
            if (e || !stream) {
              resolve(null);
              return;
            }
            const chunks: Buffer[] = [];
            stream.on("data", (c: Buffer) => chunks.push(c));
            stream.on("end", () => {
              resolve({
                buffer: Buffer.concat(chunks),
                uncompressedSize: entry.uncompressedSize,
              });
            });
            stream.on("error", () => resolve(null));
          });
        } else {
          zip.readEntry();
        }
      });
      zip.on("end", () => resolve(null));
      zip.on("error", reject);
      zip.readEntry();
    });
  });
}

export async function GET(
  _req: NextRequest,
  { params }: { params: Promise<{ jobId: string; filePath: string }> },
) {
  const { jobId, filePath: rawPath } = await params;
  // Decode + sanitize
  const filePath = decodeURIComponent(rawPath).replace(/^\/+/, "");
  if (!filePath || filePath.includes("..")) {
    return NextResponse.json({ error: "Invalid file path" }, { status: 422 });
  }
  const ext = extname(filePath).slice(1).toLowerCase();
  if (!PREVIEWABLE_EXT.has(ext)) {
    return NextResponse.json(
      {
        error: "File type not previewable",
        ext,
        previewable: [...PREVIEWABLE_EXT],
      },
      { status: 422 },
    );
  }

  const state = await jobManager.loadState(jobId);
  if (!state) {
    return NextResponse.json({ error: "Job not found" }, { status: 404 });
  }
  if (state.status !== "completed" || !state.outputZipPath) {
    return NextResponse.json(
      { error: "ZIP not ready", status: state.status },
      { status: 409 },
    );
  }

  try {
    await fs.access(state.outputZipPath);
  } catch {
    return NextResponse.json({ error: "ZIP file missing on disk" }, { status: 404 });
  }

  try {
    const result = await readZipFile(state.outputZipPath, filePath);
    if (!result) {
      return NextResponse.json({ error: "File not found in ZIP", filePath }, { status: 404 });
    }
    const fullSize = result.uncompressedSize;
    const truncated = result.buffer.length > MAX_PREVIEW_BYTES;
    const slice = truncated ? result.buffer.subarray(0, MAX_PREVIEW_BYTES) : result.buffer;
    const content = slice.toString("utf8");
    return NextResponse.json(
      {
        path: filePath,
        name: basename(filePath),
        ext,
        mime: MIME_BY_EXT[ext] ?? "text/plain",
        size: fullSize,
        truncated,
        truncatedAt: MAX_PREVIEW_BYTES,
        content,
      },
      {
        headers: {
          "Cache-Control": "no-store",
          "Content-Type": "application/json; charset=utf-8",
        },
      },
    );
  } catch (err) {
    return NextResponse.json(
      { error: "Failed to read file", details: err instanceof Error ? err.message : String(err) },
      { status: 500 },
    );
  }
}
