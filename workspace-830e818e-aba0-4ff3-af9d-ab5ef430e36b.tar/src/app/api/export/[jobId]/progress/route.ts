/**
 * YesCode — GET /api/export/[jobId]/progress
 *
 * Server-Sent Events stream of ProgressEvents for the given job.
 *
 * Per rules.md API DESIGN section: emits real-time JSON events of shape
 *   { jobId, stage, progress, overall, message, timestamp, level, metadata }
 *
 * Terminates the stream with either:
 *   { kind: "done", metrics, zipPath }   — when the job finishes successfully
 *   { kind: "error", error }            — when the job fails
 */

import { NextRequest } from "next/server";
import { jobManager } from "@/lib/exporter/jobs";
import type { ProgressEvent, ExportMetrics } from "@/lib/exporter/pipeline";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET(
  _req: NextRequest,
  { params }: { params: Promise<{ jobId: string }> },
) {
  const { jobId } = await params;
  const rec = jobManager.getJob(jobId);
  if (!rec) {
    return new Response(JSON.stringify({ error: "Job not found" }), {
      status: 404,
      headers: { "Content-Type": "application/json" },
    });
  }

  const bus = jobManager.getBus(jobId)!;
  const encoder = new TextEncoder();

  const stream = new ReadableStream<Uint8Array>({
    start(controller) {
      // Send keep-alive ping immediately so EventSource doesn't time out
      controller.enqueue(encoder.encode(": hello\n\n"));

      // Send a backlog of existing logs so a late subscriber sees history
      for (const ev of rec.state.logs) {
        controller.enqueue(
          encoder.encode(`data: ${JSON.stringify(ev)}\n\n`),
        );
      }

      const onProgress = (ev: ProgressEvent) => {
        try {
          controller.enqueue(
            encoder.encode(`data: ${JSON.stringify(ev)}\n\n`),
          );
        } catch {
          // ignore (closed)
        }
      };
      const onDone = (payload: { metrics: ExportMetrics; zipPath: string }) => {
        try {
          controller.enqueue(
            encoder.encode(
              `data: ${JSON.stringify({ kind: "done", ...payload })}\n\n`,
            ),
          );
          controller.close();
        } catch {
          // ignore
        }
      };
      const onError = (payload: { error: string }) => {
        try {
          controller.enqueue(
            encoder.encode(
              `data: ${JSON.stringify({ kind: "error", ...payload })}\n\n`,
            ),
          );
          controller.close();
        } catch {
          // ignore
        }
      };
      bus.on("progress", onProgress);
      bus.on("done", onDone);
      bus.on("error", onError);

      // If the job already finished before we subscribed, send a terminal event
      if (rec.state.status === "completed" && rec.state.metrics) {
        onDone({ metrics: rec.state.metrics, zipPath: rec.state.outputZipPath ?? "" });
      } else if (rec.state.status === "failed") {
        onError({ error: rec.state.error ?? "Unknown error" });
      }

      // Heartbeat every 15s
      const heartbeat = setInterval(() => {
        try {
          controller.enqueue(encoder.encode(": ping\n\n"));
        } catch {
          // ignore
        }
      }, 15000);

      // Cleanup when the stream is cancelled
      _req.signal.addEventListener("abort", () => {
        clearInterval(heartbeat);
        bus.off("progress", onProgress);
        bus.off("done", onDone);
        bus.off("error", onError);
        try { controller.close(); } catch { /* ignore */ }
      });
    },
  });

  return new Response(stream, {
    headers: {
      "Content-Type": "text/event-stream; charset=utf-8",
      "Cache-Control": "no-cache, no-transform",
      Connection: "keep-alive",
      "X-Accel-Buffering": "no",
    },
  });
}
