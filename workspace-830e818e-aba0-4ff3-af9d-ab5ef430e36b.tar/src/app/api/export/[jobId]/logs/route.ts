/**
 * YesCode — GET /api/export/[jobId]/logs
 *
 * Returns the full structured JSON execution log for a job. Falls back to
 * Prisma persistence for jobs from a previous server session. Also returns
 * the original export options so the UI can offer a "Re-run with same
 * options" action.
 */

import { NextRequest, NextResponse } from "next/server";
import { jobManager } from "@/lib/exporter/jobs";
import { loadJobOptions } from "@/lib/exporter/job-store";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET(
  _req: NextRequest,
  { params }: { params: Promise<{ jobId: string }> },
) {
  const { jobId } = await params;
  const state = await jobManager.loadState(jobId);
  if (!state) {
    return NextResponse.json({ error: "Job not found" }, { status: 404 });
  }
  // Load original options from DB (in-memory first via getOptions, then DB)
  const options =
    jobManager.getOptions(jobId) ?? (await loadJobOptions(jobId));
  return NextResponse.json(
    {
      jobId,
      targetUrl: state.targetUrl,
      status: state.status,
      stage: state.stage,
      overall: state.overall,
      createdAt: state.createdAt,
      updatedAt: state.updatedAt,
      metrics: state.metrics,
      error: state.error,
      logs: state.logs,
      outputZipPath: state.outputZipPath,
      options: options ?? null,
    },
    {
      headers: {
        "Cache-Control": "no-store",
        "Content-Type": "application/json; charset=utf-8",
      },
    },
  );
}
