/**
 * YesCode — DELETE /api/export/[jobId]
 *
 * Cancels a running job OR deletes a completed/failed job from history.
 * Returns 200 on success, 404 if the job doesn't exist.
 *
 * Behavior:
 *   - If the job is running: aborts the pipeline (AbortController) and
 *     marks it failed with "Cancelled by user".
 *   - If the job is completed/failed: removes it from in-memory map and
 *     the Prisma DB (history cleared).
 */

import { NextRequest, NextResponse } from "next/server";
import { jobManager } from "@/lib/exporter/jobs";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function DELETE(
  _req: NextRequest,
  { params }: { params: Promise<{ jobId: string }> },
) {
  const { jobId } = await params;
  const state = await jobManager.loadState(jobId);
  if (!state) {
    return NextResponse.json({ error: "Job not found" }, { status: 404 });
  }
  if (state.status === "running") {
    jobManager.cancelJob(jobId);
    return NextResponse.json({
      jobId,
      action: "cancelled",
      message: "Job cancelled by user",
    });
  }
  await jobManager.deleteJob(jobId);
  return NextResponse.json({
    jobId,
    action: "deleted",
    message: "Job removed from history",
  });
}
