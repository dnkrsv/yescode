/**
 * YesCode — GET /api/export/[jobId]/download
 *
 * Redirects to the standalone download service (port 3030) which streams
 * the ZIP file without Next.js response size limits. The browser follows
 * the 302 redirect and downloads directly from the download service,
 * bypassing Next.js buffering.
 */

import { NextRequest, NextResponse } from "next/server";
import { promises as fs } from "node:fs";
import { basename } from "node:path";
import { jobManager } from "@/lib/exporter/jobs";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const DOWNLOAD_SERVICE_PORT = 3030;

export async function GET(
  req: NextRequest,
  { params }: { params: Promise<{ jobId: string }> },
) {
  const { jobId } = await params;
  const state = await jobManager.loadState(jobId);
  if (!state) {
    return NextResponse.json({ error: "Job not found" }, { status: 404 });
  }
  if (state.status !== "completed" || !state.outputZipPath) {
    return NextResponse.json(
      { error: "ZIP not ready", status: state.status },
      { status: 409 },
    );
  }
  const zipPath = state.outputZipPath;
  try {
    await fs.access(zipPath);
  } catch {
    return NextResponse.json({ error: "ZIP file missing on disk" }, { status: 404 });
  }

  // Write a marker file so the download service can find the ZIP.
  // ALWAYS update it to the current valid path (in case of re-export).
  const markerPath = `/tmp/yescode/downloads/${jobId}.path`;
  try {
    await fs.mkdir("/tmp/yescode/downloads", { recursive: true });
    await fs.writeFile(markerPath, zipPath, "utf8");
  } catch {
    // ignore
  }

  // Redirect the browser to the download service via Caddy XTransformPort.
  // The browser follows the 302 and downloads directly from port 3030,
  // bypassing Next.js response body size limits.
  // Use relative URL so the browser uses the same host:port it came from.
  const downloadUrl = `/download/${jobId}?XTransformPort=${DOWNLOAD_SERVICE_PORT}`;

  return new NextResponse(null, {
    status: 302,
    headers: {
      "Location": downloadUrl,
      "Cache-Control": "no-store",
    },
  });
}
