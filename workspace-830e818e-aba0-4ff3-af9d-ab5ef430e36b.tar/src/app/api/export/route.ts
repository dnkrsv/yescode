/**
 * YesCode — POST /api/export
 *
 * Body: { url: string, options?: ExportOptions }
 *   options.maxPages?         1..1000  (default 250)
 *   options.maxDepth?         1..10    (default 10)
 *   options.customDomain?    string   (e.g. "https://my-prod.com")
 *   options.skipNIT?          boolean  (default false)
 *   options.keepFramerBranding? boolean (default false)
 * Returns: { jobId: string }
 *
 * Per rules.md API DESIGN section. Validates the URL via the SSRF guard,
 * creates a job in the in-memory JobManager, kicks off the pipeline
 * worker, and immediately returns the jobId for SSE subscription.
 *
 * GET /api/export returns the most recent job IDs (for the UI's history panel).
 */

import { NextRequest, NextResponse } from "next/server";
import { jobManager } from "@/lib/exporter/jobs";
import { assertSafeTargetUrl, SsrfError } from "@/lib/exporter/security";
import { runPipelineForJob } from "@/lib/exporter/orchestrator";
import { DEFAULT_EXPORT_OPTIONS, type ExportOptions } from "@/lib/exporter/pipeline";
import { cleanupExpiredJobs } from "@/lib/exporter/job-store";
import { z } from "zod";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const BodySchema = z.object({
  url: z.string().url(),
  options: z
    .object({
      maxPages: z.number().int().min(1).max(1000).optional(),
      maxDepth: z.number().int().min(1).max(10).optional(),
      customDomain: z.string().url().optional(),
      skipNIT: z.boolean().optional(),
      keepFramerBranding: z.boolean().optional(),
    })
    .optional(),
});

/** Shape of a single history entry returned by GET /api/export. */
interface JobHistoryEntry {
  jobId: string;
  targetUrl: string;
  status: "running" | "completed" | "failed";
  stage: string;
  overall: number;
  createdAt: number;
  updatedAt: number;
  outputZipName: string | null;
  outputZipSizeBytes: number | null;
  durationMs: number | null;
  nitStatus: "PASSED" | "FAILED" | "NOT_RUN" | null;
}

export async function POST(req: NextRequest) {
  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json(
      { error: "Invalid JSON body" },
      { status: 400 },
    );
  }
  const parsed = BodySchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json(
      { error: "Invalid request", details: parsed.error.flatten() },
      { status: 422 },
    );
  }

  // SSRF + URL validation (DNS lookup happens here)
  let targetUrl: URL;
  try {
    targetUrl = await assertSafeTargetUrl(parsed.data.url);
  } catch (err) {
    if (err instanceof SsrfError) {
      return NextResponse.json(
        { error: err.message, code: err.code },
        { status: 400 },
      );
    }
    return NextResponse.json(
      { error: err instanceof Error ? err.message : String(err) },
      { status: 400 },
    );
  }

  // Normalize custom domain
  let customDomain: string | undefined;
  if (parsed.data.options?.customDomain) {
    try {
      const cd = new URL(parsed.data.options.customDomain);
      customDomain = cd.origin;
    } catch {
      return NextResponse.json(
        { error: "customDomain must be a valid URL" },
        { status: 422 },
      );
    }
  }

  const opts: ExportOptions = {
    maxPages: parsed.data.options?.maxPages ?? DEFAULT_EXPORT_OPTIONS.maxPages,
    maxDepth: parsed.data.options?.maxDepth ?? DEFAULT_EXPORT_OPTIONS.maxDepth,
    customDomain,
    skipNIT: parsed.data.options?.skipNIT ?? DEFAULT_EXPORT_OPTIONS.skipNIT,
    keepFramerBranding:
      parsed.data.options?.keepFramerBranding ??
      DEFAULT_EXPORT_OPTIONS.keepFramerBranding,
  };

  // Create job & kick off worker
  const { jobId } = jobManager.createJob(targetUrl.toString(), opts);

  // Fire and forget — pipeline emits progress events into the bus
  void (async () => {
    try {
      await runPipelineForJob(jobId, {
        url: targetUrl.toString(),
        ...opts,
      });
    } catch (err) {
      // Should be caught inside the orchestrator, but just in case
      jobManager.failJob(
        jobId,
        `Pipeline crashed: ${err instanceof Error ? err.message : String(err)}`,
      );
    }
  })();

  return NextResponse.json({ jobId });
}

/** GET /api/export — list recent jobs (newest first) for the history panel.
 *  Merges in-memory running jobs with persisted DB jobs so history survives
 *  dev server restarts. Also triggers TTL cleanup (throttled to 5min). */
export async function GET() {
  // Best-effort TTL cleanup — deletes jobs older than 24h + their ZIPs
  void cleanupExpiredJobs();
  const allJobs = await jobManager.listAllRecentJobs(20);
  const entries: JobHistoryEntry[] = allJobs.map((st) => ({
    jobId: st.jobId,
    targetUrl: st.targetUrl,
    status: st.status,
    stage: st.stage,
    overall: Math.round(st.overall),
    createdAt: st.createdAt,
    updatedAt: st.updatedAt,
    outputZipName: st.metrics?.outputZipName ?? null,
    outputZipSizeBytes: st.metrics?.outputZipSizeBytes ?? null,
    durationMs: st.metrics?.durationMs ?? null,
    nitStatus: st.metrics?.nitStatus ?? null,
  }));
  return NextResponse.json({ jobs: entries });
}

/**
 * DELETE /api/export — clears ALL completed/failed jobs from memory + DB +
 * their ZIP files on disk. Running jobs are left alone (cancel them first).
 *
 * Returns the number of jobs deleted.
 */
export async function DELETE() {
  const allJobs = await jobManager.listAllRecentJobs(1000);
  let deleted = 0;
  let skippedRunning = 0;
  for (const st of allJobs) {
    if (st.status === "running") {
      skippedRunning++;
      continue;
    }
    await jobManager.deleteJob(st.jobId);
    // Also delete the ZIP file from disk
    if (st.outputZipPath) {
      try {
        const { promises: fs } = await import("node:fs");
        await fs.unlink(st.outputZipPath);
      } catch {
        // ignore — file may already be gone
      }
    }
    deleted++;
  }
  return NextResponse.json({
    deleted,
    skippedRunning,
    message: `Cleared ${deleted} job(s)${skippedRunning > 0 ? `, ${skippedRunning} running job(s) left alone` : ""}`,
  });
}
