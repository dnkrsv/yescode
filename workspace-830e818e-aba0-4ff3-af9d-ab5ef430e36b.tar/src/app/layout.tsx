import type { Metadata } from "next";
import { Roboto_Mono, Roboto_Flex } from "next/font/google";
import "./globals.css";
import { Toaster as SonnerToaster } from "@/components/ui/sonner";
import { ThemeProvider } from "@/components/theme-provider";

const robotoFlex = Roboto_Flex({
  variable: "--font-roboto-flex",
  subsets: ["latin"],
  display: "swap",
  weight: ["300", "400", "500", "600", "700", "800"],
});

const robotoMono = Roboto_Mono({
  variable: "--font-roboto-mono",
  subsets: ["latin"],
  display: "swap",
  weight: ["400", "500", "600", "700"],
});

export const metadata: Metadata = {
  title: "YesCode — Standalone Static Site Exporter",
  description:
    "YesCode: the ultimate standalone static site exporter. Convert any published Framer website into a 100% self-contained static archive. Preserve your design, liberate your code.",
  keywords: [
    "YesCode",
    "Framer",
    "static site",
    "exporter",
    "offline",
    "web archive",
    "Next.js",
  ],
  authors: [{ name: "YesCode" }],
  icons: { icon: "/logo.svg" },
  openGraph: {
    title: "YesCode — Standalone Static Site Exporter",
    description:
      "Convert any published Framer website into a 100% self-contained static archive.",
    url: "https://chat.z.ai",
    siteName: "YesCode",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "YesCode — Standalone Static Site Exporter",
    description:
      "Convert any published Framer website into a 100% self-contained static archive.",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${robotoFlex.variable} ${robotoMono.variable} antialiased bg-background text-foreground font-sans`}
      >
        <ThemeProvider
          attribute="class"
          defaultTheme="dark"
          enableSystem
          disableTransitionOnChange
        >
          {children}
          <SonnerToaster
            position="bottom-right"
            richColors
            closeButton
            toastOptions={{
              classNames: {
                toast: "font-mono text-xs",
                title: "font-semibold",
              },
            }}
          />
        </ThemeProvider>
      </body>
    </html>
  );
}
