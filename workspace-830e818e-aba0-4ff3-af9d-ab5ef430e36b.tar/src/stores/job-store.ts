"use client";

import { create } from "zustand";
import type {
  JobState,
  ProgressEvent,
  PipelineStageName,
  ExportMetrics,
  ExportOptions,
} from "@/lib/exporter/pipeline";
import { PIPELINE_STAGES } from "@/lib/exporter/pipeline";

export interface JobHistoryEntry {
  jobId: string;
  targetUrl: string;
  status: "running" | "completed" | "failed";
  stage: string;
  overall: number;
  createdAt: number;
  updatedAt: number;
  outputZipName: string | null;
  outputZipSizeBytes: number | null;
  durationMs: number | null;
  nitStatus: "PASSED" | "FAILED" | "NOT_RUN" | null;
}

interface JobStore {
  jobId: string | null;
  targetUrl: string;
  status: "idle" | "running" | "completed" | "failed";
  stage: PipelineStageName;
  overall: number;
  message: string;
  logs: ProgressEvent[];
  metrics: ExportMetrics | null;
  error: string | null;
  outputZipPath: string | null;
  /** Export options used for the current/last job. */
  options: ExportOptions;
  /** History of recent jobs (newest first). */
  history: JobHistoryEntry[];

  setTargetUrl: (url: string) => void;
  setOptions: (patch: Partial<ExportOptions>) => void;
  startJob: (jobId: string, url: string, options: ExportOptions) => void;
  ingestEvent: (ev: ProgressEvent) => void;
  finishJob: (metrics: ExportMetrics, zipPath: string) => void;
  failJob: (error: string) => void;
  reset: () => void;
  setHistory: (entries: JobHistoryEntry[]) => void;
  loadFromHistory: (entry: JobHistoryEntry) => void;
}

const defaultOptions: ExportOptions = {
  maxPages: 250,
  maxDepth: 10,
  customDomain: undefined,
  skipNIT: false,
  keepFramerBranding: false,
};

const initialState = {
  jobId: null,
  targetUrl: "",
  status: "idle" as const,
  stage: "QUEUED" as PipelineStageName,
  overall: 0,
  message: "",
  logs: [] as ProgressEvent[],
  metrics: null,
  error: null,
  outputZipPath: null,
  options: { ...defaultOptions },
  history: [] as JobHistoryEntry[],
};

export const useJobStore = create<JobStore>((set) => ({
  ...initialState,

  setTargetUrl: (url) => set({ targetUrl: url }),

  setOptions: (patch) =>
    set((state) => ({ options: { ...state.options, ...patch } })),

  startJob: (jobId, url, options) =>
    set({
      ...initialState,
      options: { ...defaultOptions, ...options },
      targetUrl: url,
      jobId,
      status: "running",
      stage: "QUEUED",
      overall: 0,
      message: `Job ${jobId.slice(0, 8)} accepted, worker spinning up…`,
      logs: [
        {
          jobId,
          stage: "QUEUED",
          progress: 0,
          overall: 0,
          message: `Job ${jobId} accepted`,
          timestamp: Date.now(),
          level: "INFO",
        },
      ],
      history: [], // preserve cleared; SSE will refresh
    }),

  ingestEvent: (ev) =>
    set((state) => {
      const logs = [...state.logs, ev].slice(-500);
      return {
        logs,
        stage: ev.stage,
        overall: Math.max(state.overall, ev.overall),
        message: ev.message,
        status: "running",
      };
    }),

  finishJob: (metrics, zipPath) =>
    set({
      status: "completed",
      metrics,
      outputZipPath: zipPath,
      stage: "COMPLETED",
      overall: 100,
      message: "Export finished — ZIP ready for download.",
    }),

  failJob: (error) =>
    set({
      status: "failed",
      error,
      message: `Export failed: ${error}`,
    }),

  reset: () =>
    set({
      ...initialState,
      // Preserve history across resets so the user can re-download past jobs
      history: useJobStore.getState().history,
    }),

  setHistory: (entries) => set({ history: entries }),

  loadFromHistory: (entry) =>
    set({
      ...initialState,
      jobId: entry.jobId,
      targetUrl: entry.targetUrl,
      status: entry.status === "running" ? "running" : entry.status,
      stage: entry.stage as PipelineStageName,
      overall: entry.overall,
      message:
        entry.status === "completed"
          ? "Export finished — ZIP ready for download."
          : entry.status === "failed"
            ? "Export failed (from history)"
            : "Job in progress…",
      outputZipPath: null, // we don't track zip path in history; download uses jobId
      metrics: entry.outputZipName
        ? ({
            totalRoutes: 0,
            totalAssets: 0,
            totalSizeBytes: entry.outputZipSizeBytes ?? 0,
            totalJsModules: 0,
            totalCssFiles: 0,
            totalImages: 0,
            totalFonts: 0,
            nitStatus: entry.nitStatus ?? "NOT_RUN",
            nitProhibitedCalls: 0,
            nitConsoleErrors: 0,
            durationMs: entry.durationMs ?? 0,
            outputZipName: entry.outputZipName,
            outputZipSizeBytes: entry.outputZipSizeBytes ?? 0,
          } as ExportMetrics)
        : null,
      history: useJobStore.getState().history,
    }),
}));

/** Convenience selector: index of current stage (0..13). */
export function useStageIndex(): number {
  return useJobStore((s) => PIPELINE_STAGES.indexOf(s.stage));
}
