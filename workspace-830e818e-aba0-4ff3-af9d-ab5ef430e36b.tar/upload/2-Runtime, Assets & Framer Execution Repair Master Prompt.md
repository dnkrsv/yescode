# YESCODE — RUNTIME, ASSETS & FRAMER EXECUTION REPAIR MASTER PROMPT

## ROLE

You are a senior browser-runtime engineer, static-site infrastructure engineer, JavaScript module-resolution engineer, reverse-engineering engineer, and production QA engineer.

You are working on the EXISTING YesCode codebase.

This is a targeted production repair task.

Do not rebuild YesCode from scratch.

Do not redesign the product UI.

Do not add unrelated features.

Your current task is to make the exported Framer website actually execute correctly after deployment to ordinary static hosting.

The current export has already improved route handling, but the browser still reports critical runtime failures.

You must diagnose the real root cause and repair the exporter at the subsystem level.

---

# MISSION

The current exported website is uploaded to:

```text
http://a34231089821.hosting.myjino.ru/
```

The browser reports repeated failures such as:

```text
Loading module from
"http://a34231089821.hosting.myjino.ru/assets/js/modules/rolldown-runtime.Dh6celcD.mjs"
was blocked because of a disallowed MIME type ("text/html").
```

The same failure occurs for modules including:

```text
rolldown-runtime.Dh6celcD.mjs
framer.Br48nG7B.mjs
siteMetadata.BwOaZ-v4.mjs
shared-lib.CEgYy3fE.mjs
motion.dv5ZULfb.mjs
react.BP_hhyJh.mjs
lE8fRlZ_F.OkxiJWLB.mjs
oe5G3slPq2BczTgdpT_dnFbK60NoEMrmJSpy0bdK8d4.CGoRtCoP.mjs
Zxw_TS4Oj.D28wrBb6.mjs
qHlwa_hFM.5f97lajd.mjs
uE4yEIrDh.BHD7hlb9.mjs
DuZdfpHRb.DtaOBGkc.mjs
I1fX_iZlC.MGbBJc14.mjs
pNL5QPLbI.DQHxm05J.mjs
```

The exported website also has:

1. animations not working;
2. some images not loading;
3. Framer runtime not fully executing;
4. third-party Yandex Metrica request failing;
5. warnings for localized TikTok Sans WOFF2 fonts.

Route navigation is already improved.

Do not assume all these failures have the same cause.

Determine the dependency chain.

The primary objective is:

> restore the exported site's actual client-side runtime and resource loading.

---

# CRITICAL INTERPRETATION

The following browser error:

```text
.mjs -> text/html
```

does NOT merely mean:

```text
"the MIME type is configured incorrectly"
```

It may mean:

```text
requested .mjs
→ file missing OR wrong mapping OR rewrite interception
→ HTML fallback
→ HTTP response Content-Type = text/html
→ browser rejects module
```

Therefore:

## DO NOT solve this task merely by adding:

```apache
AddType application/javascript .mjs
```

That directive may still be necessary for Apache, but it is only valid when the requested `.mjs` URL actually maps to the JavaScript file.

The real invariant is:

```text
/assets/js/modules/foo.mjs
        ↓
actual foo.mjs bytes
        ↓
Content-Type: text/javascript
        ↓
browser module execution
```

NOT:

```text
/assets/js/modules/foo.mjs
        ↓
index.html
        ↓
text/html
```

---

# NON-NEGOTIABLE INVARIANTS

## INVARIANT 1 — NO HTML FOR STATIC RESOURCES

A request such as:

```text
/assets/js/modules/framer.Br48nG7B.mjs
```

must NEVER resolve to:

```text
/index.html
```

or any other HTML file.

The server must either:

```text
200 + actual JavaScript
```

or:

```text
404
```

but never:

```text
200 + HTML
```

for a `.mjs` resource.

---

## INVARIANT 2 — FILE SYSTEM AND URL MAP MUST AGREE

For every emitted resource URL, YesCode must know:

```text
source URL
→ canonical URL
→ classification
→ local file path
→ HTTP URL
→ expected content type
```

Example:

```json
{
  "sourceUrl": "https://example.framer.app/...",
  "localPath": "assets/js/modules/framer.Br48nG7B.mjs",
  "publicPath": "/assets/js/modules/framer.Br48nG7B.mjs",
  "mime": "text/javascript",
  "type": "js-module",
  "required": true
}
```

If this mapping cannot be proven, export validation must fail.

---

# INVARIANT 3 — DO NOT CONFUSE ROUTE FALLBACK WITH ASSET SERVING

The previous routing repair must not reintroduce a generic fallback.

Never implement a rule equivalent to:

```text
unknown URL -> index.html
```

for all requests.

Correct classification:

```text
KNOWN HTML ROUTE
    -> corresponding index.html

KNOWN STATIC FILE
    -> exact file

UNKNOWN STATIC FILE
    -> 404

UNKNOWN ROUTE
    -> 404 / explicit hosting not-found behavior
```

---

# INVARIANT 4 — RUNTIME MODULES ARE FIRST-CLASS RESOURCES

These are not ordinary decorative assets.

Treat:

```text
react.*
framer.*
motion.*
rolldown-runtime.*
siteMetadata.*
shared-lib.*
dynamic chunks
```

as executable dependency nodes.

Their dependencies must be recursively resolved.

---

# INVARIANT 5 — RUNTIME MUST START BEFORE ANIMATION CAN WORK

Animations are not an isolated feature.

Do not attempt to "restore animations" by adding custom CSS/JS patches.

First restore:

```text
module graph
    ↓
React/runtime
    ↓
Framer runtime
    ↓
hydration
    ↓
motion/interactions
```

Only after runtime execution succeeds should animation behavior be evaluated.

---

# INVARIANT 6 — IMAGE FAILURE MUST BE TRACED

Do not assume image failures are caused by image localization itself.

An image may fail because:

```text
runtime did not initialize
lazy-loader did not execute
JS module failed
CSS reference was broken
URL was rewritten incorrectly
resource returned HTML
resource was not localized
```

Determine which applies.

---

# FIRST ACTION — DO NOT PATCH YET

Before changing code:

1. inspect current repository;
2. inspect current exporter;
3. inspect latest generated ZIP;
4. extract the ZIP;
5. inspect:
   - `index.html`;
   - all `*.mjs`;
   - all `*.js`;
   - CSS;
   - images;
   - fonts;
   - `.htaccess`;
6. identify which of the failing module files physically exist;
7. inspect their sizes and content;
8. start a clean HTTP server;
9. request each failing module directly;
10. inspect status code;
11. inspect Content-Type;
12. inspect response body;
13. compare actual filesystem path to requested URL.

Do not infer.

---

# REQUIRED DIRECT HTTP DIAGNOSTIC

For at least these files:

```text
/assets/js/modules/rolldown-runtime.Dh6celcD.mjs
/assets/js/modules/framer.Br48nG7B.mjs
/assets/js/modules/react.BP_hhyJh.mjs
/assets/js/modules/motion.dv5ZULfb.mjs
/assets/js/modules/siteMetadata.BwOaZ-v4.mjs
```

perform direct HTTP requests.

Record:

```text
URL
status
content-type
content-length
redirects
first bytes of response
resolved filesystem path
```

The diagnostic must identify whether the response body is:

```text
JavaScript
HTML
empty
404
other
```

If the body is HTML, determine exactly why.

---

# ROOT-CAUSE DECISION TREE

For every failing `.mjs`:

## CASE A — FILE DOES NOT EXIST

Then the exporter failed to localize the required runtime dependency.

Fix:

```text
capture
→ graph discovery
→ localization
```

not MIME configuration.

---

## CASE B — FILE EXISTS, REQUEST RETURNS 404

Then fix:

```text
publicPath
→ output path
→ URL rewriting
→ hosting resolution
```

---

## CASE C — FILE EXISTS, REQUEST RETURNS 200 + text/html

This is a routing/fallback problem.

Find the rewrite/fallback rule producing HTML.

Remove that behavior for static resources.

---

## CASE D — FILE EXISTS, REQUEST RETURNS 200 + text/plain

This is an HTTP MIME configuration problem.

Then fix Apache/static-host configuration.

---

## CASE E — FILE EXISTS, 200 + text/javascript, BUT BROWSER STILL FAILS

Then inspect:

- file content;
- syntax;
- module imports;
- relative import resolution;
- dynamic imports;
- CORS/base URL;
- nested asset references;
- dependency graph completeness.

---

# REQUIREMENT — GENERATE AN ASSET MANIFEST

Before packaging, generate an internal machine-readable manifest.

For every localized resource:

```json
{
  "publicPath": "/assets/js/modules/framer.Br48nG7B.mjs",
  "localPath": "assets/js/modules/framer.Br48nG7B.mjs",
  "kind": "js-module",
  "contentType": "text/javascript",
  "required": true,
  "exists": true
}
```

This manifest may be internal and does not have to ship publicly.

Use it to validate that every emitted resource reference has an actual target.

---

# JS DEPENDENCY GRAPH

The exporter must NOT assume that:

```text
HTML script src
```

is the complete runtime.

Build:

```text
HTML
 ↓
module entry
 ↓
static imports
 ↓
dynamic imports
 ↓
secondary chunks
 ↓
runtime-referenced assets
```

Resolve recursively.

For every local module:

```text
import "./foo.mjs"
```

must resolve to a localized module.

For:

```text
import("./chunk-ABC.mjs")
```

the chunk must also be captured/localized.

---

# IMPORT RESOLUTION

Do not use document-relative resolution for JavaScript modules incorrectly.

ECMAScript modules resolve imports relative to the importing module URL.

Therefore:

```text
/assets/js/main.mjs
```

containing:

```js
import "./modules/framer.mjs";
```

must resolve to:

```text
/assets/js/modules/framer.mjs
```

not:

```text
/modules/framer.mjs
```

and not:

```text
/assets/js/../modules/framer.mjs
```

unless canonicalized equivalently.

Implement real URL resolution using URL semantics.

---

# IMPORT REWRITING

For every import:

```text
import "./foo"
import "/foo"
import "https://..."
import("./foo")
```

determine whether it maps to a captured/local resource.

Rewrite only when appropriate.

Preserve JavaScript semantics.

Do not use blind global string replacement.

---

# RUNTIME URL VS ASSET URL

Maintain explicit distinction.

## Runtime module

```text
.mjs
.js
WASM
worker
dynamic chunk
```

## Static asset

```text
image
font
video
audio
SVG
```

## Platform infrastructure

```text
telemetry
editor
bootstrap
```

## Third-party

```text
analytics
maps
social embeds
external APIs
```

Never collapse them into one category.

---

# FRAMER-SPECIFIC RULES

## framerusercontent.com

Required Framer-hosted assets must be localized.

Examples:

```text
images
fonts
videos
media
JSON
```

Do not leave them remote if the resource is required for standalone execution.

---

## framercanvas.com

Do not treat as public website routes.

Do not crawl it as page content.

---

## FRAMER RUNTIME

Required Framer runtime must be localized.

Do not delete modules simply because their filenames contain:

```text
framer
motion
react
```

---

# IMAGE LOCALIZATION

Audit all image discovery channels:

```text
<img src="">
<img srcset="">
<picture>
CSS url()
background-image
mask-image
SVG references
JSON
JS string literals
runtime-generated URLs
preloads
```

Do not rely only on `<img>` scanning.

---

# IMAGE FAILURE INVESTIGATION

For every missing image determine:

```text
source URL
→ capture event?
→ Resource Graph node?
→ localized file?
→ local path?
→ rewritten reference?
→ HTTP request?
→ status?
→ Content-Type?
→ browser loaded?
```

Create an automated report.

---

# LAZY-LOADED IMAGES

The browser capture stage must trigger lazy-loaded assets.

Use deterministic mechanisms such as:

- scrolling;
- viewport traversal;
- intersection-triggering behavior;
- waiting for network activity to settle after viewport changes.

Do not rely only on initial HTML.

---

# CSS ASSET REFERENCES

Audit:

```text
url(...)
@import
background-image
mask
mask-image
font-face
```

A broken CSS reference must be reported with source and local target.

---

# FONTS

The WOFF2 warning:

```text
TikTok Sans
Invalid nameID: 17
Table discarded
```

must be diagnosed separately.

Do NOT treat this warning as equivalent to:

```text
.mjs -> text/html
```

Determine:

1. whether the font is actually required;
2. whether the downloaded WOFF2 is byte-identical to source;
3. whether the file was truncated/corrupted;
4. whether the server is returning the actual WOFF2;
5. whether MIME is correct;
6. whether the warning originates from font metadata itself.

Required font tests:

```text
status = 200
content-type = font/woff2
body is not HTML
reasonable file size
browser can decode
```

If the source font is malformed but the browser can still use it sufficiently, classify appropriately.

Do not silently replace fonts with another font.

---

# THIRD-PARTY YANDEX METRICA

The following request:

```text
https://mc.yandex.ru/metrika/tag.js?id=108803114
```

is not a Framer runtime failure.

Classify it as:

```text
THIRD_PARTY_ANALYTICS
```

Choose a policy.

For the default standalone export:

- preserve as external only if explicitly allowed;
- otherwise remove platform analytics;
- do not allow this external request to be confused with Framer runtime validation.

The exported site must remain fully functional without Yandex Metrica.

NIT must NOT fail merely because optional analytics are unavailable.

---

# .HTACCESS

Generate:

```apache
Options -Indexes
DirectoryIndex index.html
AddType application/javascript .mjs
```

when using Apache-compatible hosting.

But this configuration must NOT include a universal fallback such as:

```apache
RewriteRule ^ index.html
```

without strict route/asset exclusions.

The following must always win:

```text
/assets/*
*.js
*.mjs
*.css
*.json
*.svg
*.webp
*.png
*.jpg
*.woff
*.woff2
*.mp4
*.webm
```

These requests must be served as files or return 404.

---

# STATIC RESOURCE ROUTING RULE

For every request:

```text
pathname
```

determine:

1. does exact file exist?
2. is it a known route?
3. is it a known asset?
4. is it unknown?

Priority:

```text
EXACT FILE
    ↓
KNOWN HTML ROUTE
    ↓
404
```

Never:

```text
KNOWN ASSET
    ↓
HTML ROUTE
```

---

# NO SMART FALLBACK FOR ASSETS

If:

```text
/assets/js/modules/react.BP_hhyJh.mjs
```

does not exist:

return:

```text
404
```

Do not return:

```text
/index.html
```

This is mandatory.

---

# HTTP VALIDATION

After generating the ZIP:

1. extract;
2. start HTTP server;
3. request every generated `.mjs`;
4. request every generated CSS file;
5. request representative images;
6. request fonts;
7. request JSON;
8. inspect response MIME;
9. inspect response body type.

Fail if any resource receives HTML unexpectedly.

---

# BROWSER VALIDATION

Use Playwright or equivalent.

Load:

```text
/
/about
/about/
/projects
/projects/<real-cms-slug>
```

Record:

```text
request
response
status
content-type
console
pageerror
failed request
module load
```

---

# ANIMATION VALIDATION

Do not validate animations by checking whether a library file exists.

Actually test observable behavior.

At minimum:

1. load page;
2. wait for hydration;
3. capture initial DOM/layout state;
4. trigger scroll;
5. wait;
6. compare relevant state/layout/style;
7. interact with representative animated elements;
8. verify runtime errors do not occur.

Use appropriate browser instrumentation.

The objective is to verify that the Framer animation/runtime is executing.

---

# IMAGE VALIDATION

For representative images:

1. identify image URL;
2. wait for image load;
3. evaluate `HTMLImageElement.complete`;
4. check `naturalWidth > 0`;
5. inspect failed network requests;
6. verify source/currentSrc;
7. verify local URL.

For background images, inspect computed styles and actual network requests.

---

# HYDRATION VALIDATION

The exported site must not merely show server-rendered HTML.

Check that:

```text
runtime JS loaded
↓
hydration completed
↓
interactive behavior works
```

At minimum check for:

- module load errors;
- uncaught exceptions;
- failed dynamic imports;
- missing runtime containers;
- failed event binding.

---

# REAL NIT

Run the Network Independence Test against the EXTRACTED ZIP.

Procedure:

```text
ZIP
 ↓
extract
 ↓
HTTP server
 ↓
real browser
 ↓
block Framer domains
 ↓
load routes
 ↓
scroll
 ↓
interact
 ↓
inspect requests/errors
```

Block at least:

```text
framer.com
*.framer.com
framerusercontent.com
*.framerusercontent.com
framercanvas.com
*.framercanvas.com
known Framer publishing/CDN origins
```

However, before declaring any hostname prohibited, classify whether it is:

```text
FRAMER_RUNTIME
FRAMER_ASSET
FRAMER_EDITOR
FRAMER_TELEMETRY
```

Required localized dependencies must not be fetched remotely after export.

---

# OFFLINE TEST

After the Framer-blocked test, perform a stricter test where general external network access is unavailable.

Classify external requests into:

```text
REQUIRED LOCAL
OPTIONAL EXTERNAL
UNSUPPORTED
PROHIBITED
```

A site requiring Yandex Metrica should still function.

A required runtime module requiring `framerusercontent.com` should be a failure because it should have been localized.

---

# RESIDUAL DEPENDENCY SCAN

Scan:

```text
HTML
CSS
JS
MJS
JSON
SVG
manifest
```

for:

```text
framer.com
framerusercontent.com
framercanvas.com
known Framer CDN
```

But distinguish:

```text
network dependency
```

from:

```text
informational string
```

Do not reject text simply because it contains the word "Framer".

---

# REQUIRED DEBUG REPORT

At the end of every failed export generate:

```text
EXPORT RUNTIME DIAGNOSTIC

Routes:
...

CMS routes:
...

JS modules discovered:
...

JS modules localized:
...

JS modules unresolved:
...

Images discovered:
...

Images localized:
...

Fonts discovered:
...

Fonts localized:
...

HTTP asset failures:
...

HTML-as-asset failures:
...

Wrong MIME failures:
...

Dynamic import failures:
...

Console errors:
...

Page errors:
...

External requests:
...

Prohibited Framer requests:
...

NIT:
PASS / FAIL
```

---

# TESTING

Build tests at five levels.

## UNIT

Test:

- URL resolver;
- route resolver;
- resource classifier;
- MIME resolver;
- module import resolver;
- path normalizer.

## INTEGRATION

Test:

- HTML → resource graph;
- JS → dynamic imports;
- resource graph → localization;
- localization → rewriting;
- route → output tree.

## HTTP

Test:

- `.mjs`;
- `.js`;
- `.css`;
- images;
- fonts;
- JSON.

## BROWSER

Test:

- runtime;
- hydration;
- animation;
- image loading;
- navigation.

## NIT

Test:

- Framer blocked;
- internet unavailable;
- exported site still operational.

---

# REGRESSION TESTS

Keep all previous regressions and add these mandatory tests:

## REGRESSION 1

`.mjs` exists but server returns HTML.

Expected:

FAIL.

## REGRESSION 2

`.mjs` does not exist.

Expected:

404, never HTML.

## REGRESSION 3

`.mjs` exists and is served as text/plain.

Expected:

validation failure.

## REGRESSION 4

`.mjs` exists, correct MIME, but imports are missing.

Expected:

browser test failure.

## REGRESSION 5

Image discovered only from JS.

Expected:

localized.

## REGRESSION 6

Image loaded lazily after scroll.

Expected:

localized.

## REGRESSION 7

Animation depends on Framer runtime.

Expected:

runtime executes after export.

## REGRESSION 8

Nested route requests root-level assets.

Expected:

success.

## REGRESSION 9

CMS detail page depends on runtime data.

Expected:

static page works after export.

## REGRESSION 10

Yandex Metrica unavailable.

Expected:

site still functions.

## REGRESSION 11

TikTok Sans font has metadata warning.

Expected:

separate warning classification, not confused with runtime failure.

---

# ACCEPTANCE CRITERIA

The current repair is accepted ONLY if all mandatory conditions pass.

## MODULE DELIVERY

For all critical modules:

```text
HTTP 200
correct JS MIME
actual JS body
browser load success
```

## RUNTIME

At least:

```text
React/runtime
Framer runtime
motion
dynamic imports
```

load without critical errors.

## ANIMATION

Representative animation behavior executes.

## IMAGES

Representative:

- `<img>`;
- lazy image;
- CSS image;
- JS-referenced image

loads successfully.

## ROUTING

Previously fixed routing remains correct.

## CMS

CMS detail pages remain present.

## ASSETS

No required localized asset is served as HTML.

## FRAMER

No required runtime dependency accesses Framer infrastructure after export.

## ZIP

Extracted ZIP is directly deployable.

---

# DEBUGGING PRIORITY

Follow this exact priority:

### P0

Fix:

```text
.mjs -> HTML
```

### P1

Fix:

```text
module graph
```

### P2

Fix:

```text
runtime execution / hydration
```

### P3

Fix:

```text
images / lazy resources
```

### P4

Fix:

```text
font integrity
```

### P5

Fix:

```text
optional third-party integrations
```

Do not spend time polishing UI.

---

# EXECUTION PROTOCOL

## STEP 1

Inspect current exporter.

## STEP 2

Generate a fresh export.

## STEP 3

Extract ZIP.

## STEP 4

Find all referenced `.mjs`.

## STEP 5

For every `.mjs` determine:

```text
exists?
correct path?
correct URL?
correct MIME?
actual body?
imports resolve?
```

## STEP 6

Fix the localization/path/routing subsystem.

## STEP 7

Run direct HTTP validation.

## STEP 8

Run browser validation.

## STEP 9

Fix runtime graph.

## STEP 10

Re-test animations.

## STEP 11

Re-test images.

## STEP 12

Re-test fonts.

## STEP 13

Run NIT.

## STEP 14

Run regression suite.

## STEP 15

Repeat export three times.

## STEP 16

Compare deterministic output.

---

# FORBIDDEN SHORTCUTS

Never "fix" the problem by:

```text
adding a generic SPA fallback
copying index.html into asset paths
hardcoding specific module filenames
hardcoding specific project slugs
deleting Framer runtime
disabling animations
replacing images with placeholders
ignoring browser errors
marking 404 resources as optional
changing only MIME and declaring success
```

Do not mask the problem.

Fix the subsystem.

---

# DEFINITION OF DONE

You are finished ONLY when a freshly exported ZIP:

1. extracts correctly;
2. contains all required runtime modules;
3. serves `.mjs` as JavaScript;
4. never serves HTML for asset requests;
5. loads React/runtime;
6. loads Framer runtime;
7. loads motion;
8. executes dynamic imports;
9. loads representative images;
10. executes representative animations;
11. loads fonts or produces only explicitly classified non-critical font warnings;
12. keeps CMS detail routes;
13. keeps fixed routing behavior;
14. works over a real HTTP server;
15. survives Framer-domain blocking;
16. passes browser validation;
17. passes regression tests;
18. produces deterministic exports;
19. is not dependent on YesCode at runtime;
20. does not require manual post-export patching.

Do not report success based on screenshots.

Do not report success based on ZIP existence.

Do not report success based on HTTP 200 from the API.

The extracted ZIP and browser behavior are the source of truth.

# UNIVERSAL RUNTIME RESOLUTION — NO SITE-SPECIFIC HARDCODING

The exporter MUST be completely site-agnostic.

The filenames, hashes, chunk names, module names, asset names, and runtime graph of one Framer website MUST NEVER be treated as constants for another website.

Examples such as:

```text
framer.Br48nG7B.mjs
react.BP_hhyJh.mjs
motion.dv5ZULfb.mjs
rolldown-runtime.Dh6celcD.mjs
siteMetadata.BwOaZ-v4.mjs
```

are ONLY regression-test examples from one observed export.

They are NOT a canonical module list.

Do NOT hardcode:

* exact filenames;
* exact hashes;
* exact chunk names;
* exact asset names;
* exact CMS slugs;
* exact runtime URLs;
* exact Framer build identifiers.

The exporter MUST discover the actual dependency graph of EACH source website dynamically.

For every export:

```text
actual published HTML
        ↓
actual script/module references
        ↓
actual module URLs
        ↓
actual static imports
        ↓
actual dynamic imports
        ↓
actual runtime-loaded chunks
        ↓
actual runtime asset references
        ↓
recursive dependency graph
```

The resulting graph must be derived from the current source site.

The exporter MUST continue to work when:

* filenames change;
* hashes change;
* chunk names change;
* module counts change;
* module order changes;
* Framer build versions change;
* runtime architecture changes;
* some modules are absent;
* new modules appear;
* different pages use different runtime chunks;
* CMS pages introduce additional dependencies.

A module is required because it is discovered as a dependency of the current exported site — NOT because it resembles a module seen on a previous site.

Every resource must therefore be represented by data such as:

```text
sourceUrl
normalizedUrl
classification
parent
initiator
resourceType
contentType
localPath
required
localizationState
rewriteState
validationState
```

The implementation MUST NOT contain site-specific conditions such as:

```js
if (filename === "framer.Br48nG7B.mjs") ...
```

or:

```js
if (url.includes("rolldown-runtime")) ...
```

unless the condition is part of a documented, generic resource-classification rule that does NOT depend on a particular hash or exact build artifact.

Regression fixtures may reference concrete filenames.

Production export logic MUST NOT.

The final acceptance test MUST use at least two materially different runtime graphs and prove that both are exported without site-specific configuration.

The correct implementation is:

```text
DISCOVER
→ CLASSIFY
→ FETCH
→ PARSE
→ RESOLVE
→ LOCALIZE
→ REWRITE
→ VALIDATE
```

not:

```text
MATCH KNOWN FRAMER FILES
→ COPY FILES
```

The exporter must be resilient to future Framer builds that generate previously unseen filenames and dependency graphs.

# END