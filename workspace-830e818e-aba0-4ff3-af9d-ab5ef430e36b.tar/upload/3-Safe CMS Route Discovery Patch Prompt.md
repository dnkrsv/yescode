# YESCODE — SAFE CMS ROUTE DISCOVERY PATCH

## ROLE

You are a senior TypeScript/Node.js engineer working on the EXISTING YesCode codebase.

You are modifying a production exporter that already works.

This is a TARGETED PATCH, not a rewrite.

Your responsibility is to add reliable discovery and export of public Framer CMS pages while preserving all currently working export behavior.

---

# MISSION

Fix one specific functional limitation in the existing YesCode exporter:

> YesCode currently exports normal published pages but does not reliably discover and export Framer CMS detail pages.

This is critical because CMS may contain:

- projects;
- cases;
- blog posts;
- news;
- products;
- team members;
- articles;
- other collection items.

The exporter must discover and export these pages generically.

Examples:

```text
/projects/
    ↓
/projects/matti/
/projects/project-two/
/projects/project-three/
```

or:

```text
/blog/
    ↓
/blog/article-one/
/blog/article-two/
```

or:

```text
/cases/
    ↓
/cases/project-a/
/cases/project-b/
```

Do NOT hardcode any specific collection name, slug, route prefix, project name, CMS item name, or Framer-generated filename.

The implementation must work with arbitrary public CMS collections.

---

# CRITICAL CONSTRAINT — PRESERVE EXISTING EXPORT BEHAVIOR

The current YesCode exporter already has working functionality.

DO NOT replace or redesign existing export behavior unless it is proven necessary for CMS route discovery.

The following are protected:

- existing export UI;
- existing export parameters;
- current URL input;
- current export flow;
- current progress stages;
- current job model;
- current API;
- current ZIP naming;
- current output structure;
- current static routing;
- current `.htaccess` generation;
- current asset localization;
- current JS localization;
- current HTML rewriting;
- current CSS rewriting;
- current SEO generation;
- current validation;
- current NIT;
- current resource limits;
- current concurrency controls;
- current timeout values;
- current logging;
- current error model;
- current working route discovery behavior.

Do NOT change these just because you are working in the discovery subsystem.

---

# HARD RULE — NO REGRESSION

Before modifying anything:

1. inspect the repository;
2. inspect `package.json`;
3. inspect current architecture;
4. inspect current export configuration;
5. inspect current discovery implementation;
6. inspect current classifier;
7. inspect current tests;
8. run the existing test suite;
9. establish a baseline export.

Record which existing features currently work.

After the patch:

> every previously passing test must continue to pass.

Do not trade existing functionality for CMS support.

---

# VERY IMPORTANT — DO NOT REBUILD THE EXPORTER

Do NOT:

- replace the exporter architecture;
- replace the browser/capture engine;
- replace the routing subsystem;
- replace the Resource Graph;
- replace the URL resolver;
- replace the localization engine;
- replace the API;
- replace the UI;
- migrate frameworks;
- change package managers;
- introduce unrelated dependencies;
- perform broad refactoring.

Make the smallest architecture-compatible change that solves the problem correctly.

---

# FIRST DIAGNOSIS

Inspect the current implementation of:

```text
src/lib/exporter/discovery.ts
src/lib/exporter/classifier.ts
```

and all modules they directly depend on.

Determine exactly:

1. how candidate routes are discovered;
2. how sitemap URLs are discovered;
3. how internal links are discovered;
4. how CMS-related URLs are discovered;
5. how URLs are classified;
6. how editor/canvas URLs are filtered;
7. how routes are queued;
8. how duplicate routes are removed;
9. how discovered routes enter the existing export pipeline.

Do not modify code until this is understood.

---

# KNOWN EXISTING BUG

The current implementation contains an overly broad editor barrier around `/projects/`.

There is currently logic equivalent to:

```ts
const EDITOR_BARRIER_PATTERNS = [
  /\/edit\//i,
  /\/canvas\//i,
  /\/projects\//i,
  /\/templates\//i,
];
```

There is also classifier logic that can incorrectly classify `/projects/...` as Framer editor infrastructure.

This is WRONG for published websites.

For example:

```text
https://example.framer.ai/projects/matti
```

may be a completely normal PUBLIC CMS page.

It must NOT be rejected merely because its pathname contains `/projects/`.

---

# CORRECT EDITOR VS PUBLISHED ROUTE MODEL

Classification must be based primarily on origin/context, not pathname alone.

These are fundamentally different:

```text
https://example.framer.ai/projects/matti
```

and:

```text
https://some-project.framercanvas.com/projects/matti
```

The first may be a published website route.

The second is editor/canvas infrastructure.

Therefore:

## Published origin

If the URL belongs to the target published site origin:

```text
https://example.framer.ai/...
```

then a path such as:

```text
/projects/...
/blog/...
/cases/...
/news/...
```

must be allowed to become a published route unless another explicit rule proves otherwise.

## Editor/canvas origin

If the URL belongs to editor/canvas infrastructure such as:

```text
*.framercanvas.com
```

it must NOT become a published route.

Do not use pathname names such as `/projects/` as a universal editor detector.

---

# REQUIRED CHANGE

Replace overly broad pathname-based editor filtering with context-aware classification.

Do NOT simply delete all editor protection.

The goal is:

```text
published origin + /projects/matti
    → PUBLISHED_ROUTE

published origin + /blog/article
    → PUBLISHED_ROUTE

published origin + /cases/foo
    → PUBLISHED_ROUTE

editor/canvas origin + /projects/...
    → FRAMER_EDITOR
```

The distinction must be generic.

---

# CMS DISCOVERY STRATEGY

Implement CMS discovery as an additional route-discovery layer.

Do not create a separate exporter that bypasses the existing pipeline.

All CMS routes must eventually enter the SAME route queue and SAME export pipeline as ordinary published pages.

The final pipeline should remain conceptually:

```text
discover route
    ↓
enqueue route
    ↓
capture
    ↓
resource graph
    ↓
localization
    ↓
rewrite
    ↓
validate
    ↓
output /route/index.html
```

CMS routes are simply additional discovered published routes.

---

# SOURCE PRIORITY FOR CMS DISCOVERY

Use multiple public sources.

Recommended priority:

```text
1. sitemap.xml
2. sitemap index / child sitemaps
3. internal same-origin links
4. rendered browser DOM
5. canonical URLs
6. pagination / visible collection navigation
7. browser/runtime-discovered public URLs
```

Do NOT require all sources.

Do NOT assume sitemap always contains everything.

Do NOT rely exclusively on a CSS selector.

Do NOT make CMS discovery dependent on a specific Framer internal DOM structure.

---

# SITEMAP DISCOVERY

The current sitemap implementation must be inspected and improved only as necessary.

It must support:

```text
/sitemap.xml
```

and, if present:

```xml
<sitemapindex>
    <sitemap>
        <loc>...</loc>
    </sitemap>
</sitemapindex>
```

and:

```xml
<urlset>
    <url>
        <loc>...</loc>
    </url>
</urlset>
```

Recursively resolve sitemap indexes when appropriate.

Only accept same-site public URLs.

Do not crawl unrelated external domains.

Respect existing route/resource limits.

Preserve existing timeout and concurrency configuration.

---

# SITEMAP ROUTE RULE

Every URL discovered from the sitemap must still go through the existing URL classifier.

Do NOT bypass classification.

But:

> a URL from the target published origin must not be rejected solely because the path contains `/projects/`.

---

# CMS DETAIL ROUTE DISCOVERY

The exporter must be capable of discovering pages such as:

```text
/projects/matti
/projects/project-a
/projects/project-b
```

without knowing that `projects` is a CMS collection in advance.

Likewise:

```text
/blog/article-one
/news/article-two
/cases/project-three
```

must work without hardcoded prefixes.

The implementation must discover actual public URLs.

---

# INTERNAL LINKS

When processing:

```text
<a href="...">
```

collect same-origin route candidates.

Normalize the URL before deduplication.

Ignore:

```text
mailto:
tel:
javascript:
data:
blob:
hash-only
```

Do not crawl unrelated domains.

Preserve query and fragment semantics according to the existing route model.

Do not alter the existing URL rewriting subsystem.

This patch concerns discovery only.

---

# BROWSER DISCOVERY

If the existing exporter already has browser capture support, use it as an additional source of route candidates where appropriate.

After hydration:

- inspect links;
- inspect visible navigation;
- inspect collection links;
- inspect canonical URL;
- inspect relevant serialized route/data structures only when already exposed publicly.

Do not introduce destructive mutations.

Do not alter the page to make CMS content appear artificially.

---

# LAZY / PAGINATED CMS

Where a public CMS collection requires scrolling or pagination to reveal additional public detail links:

- use the existing browser/capture mechanism;
- trigger the minimum deterministic behavior required;
- discover the resulting public URLs;
- enqueue them through the existing route pipeline.

Respect all existing:

- route caps;
- timeouts;
- request limits;
- memory limits.

Do not introduce infinite crawling.

---

# NO CMS API DEPENDENCY

Do NOT introduce an authenticated Framer CMS API requirement.

YesCode must continue to work from a publicly accessible published website URL.

Prefer public evidence available through:

- sitemap;
- HTML;
- browser;
- public runtime data;
- public network responses.

Do not require a Framer project login.

---

# ROUTE IDENTITY

Every discovered CMS URL must become the same internal route identity type already used by the exporter.

For example:

```text
/projects/matti
```

should become:

```text
PUBLISHED_ROUTE
```

not some special incompatible output type.

Do not create a separate output mechanism unless the existing architecture truly requires one.

---

# OUTPUT STRUCTURE

For every successfully discovered public CMS detail route:

```text
/projects/matti
    ↓
/projects/matti/index.html
```

Similarly:

```text
/blog/article-one
    ↓
/blog/article-one/index.html
```

and:

```text
/cases/project-a
    ↓
/cases/project-a/index.html
```

Use the existing route materialization logic.

Do not manually construct HTML outside the existing export pipeline.

---

# CMS INDEX PAGE

The collection index itself must continue to export normally:

```text
/projects/
    ↓
/projects/index.html
```

Adding CMS detail discovery must NOT remove or alter the index page.

---

# DUPLICATION

The same route may be found through several sources:

```text
sitemap
DOM
navigation
browser
canonical
runtime
```

Deduplicate by canonical route identity.

Example:

```text
https://example.framer.ai/projects/matti
https://example.framer.ai/projects/matti/
https://example.framer.ai/projects/matti/index.html
```

must represent one route.

Use the existing canonicalization logic whenever possible.

Do not create a second competing normalization system.

---

# ROUTE SAFETY

Do not allow CMS discovery to become an unrestricted crawler.

Respect the existing:

- same-origin restriction;
- route cap;
- recursion depth;
- request budget;
- timeout;
- response-size limits;
- concurrency;
- cancellation.

If the project already has these values configured, preserve them exactly.

Do not silently increase them to make one CMS site work.

---

# PARAMETERS MUST NOT CHANGE

The patch must preserve the current export parameters.

Specifically:

- do not rename configuration fields;
- do not remove configuration fields;
- do not change their defaults;
- do not change their units;
- do not change their semantics;
- do not change existing user-facing controls;
- do not introduce mandatory new parameters.

If a new internal setting is absolutely necessary, make it internal and preserve all existing public configuration contracts.

Do not expose unnecessary settings in the UI.

---

# ERROR HANDLING

CMS discovery failures must follow the existing error model.

Do not make an optional CMS discovery signal fatal merely because one discovery source failed.

For example:

```text
sitemap unavailable
```

does NOT necessarily mean:

```text
export failure
```

if browser/DOM discovery can still find routes.

However:

```text
critical discovered CMS route cannot be captured
```

must be handled according to the existing route/export failure policy.

Do not silently report success if a route that the exporter explicitly committed to exporting is missing.

---

# LOGGING

Extend the existing structured logging minimally.

Useful diagnostics:

```text
CMS discovery started
Sitemap routes discovered: N
Same-origin candidate routes discovered: N
CMS-like/detail routes discovered: N
Duplicate routes removed: N
Final route count: N
```

For a route candidate:

```text
CMS route candidate:
 /projects/matti

Source:
 sitemap | DOM | browser | canonical | runtime

Classification:
 PUBLISHED_ROUTE

Queued:
 YES
```

Do not flood user logs with internal implementation details.

---

# TESTS — MANDATORY

Add regression tests before declaring the patch complete.

## TEST 1 — `/projects/` IS NOT EDITOR

Given target origin:

```text
https://example.framer.ai
```

and route:

```text
/projects/matti
```

expected classification:

```text
PUBLISHED_ROUTE
```

NOT:

```text
FRAMER_EDITOR
```

---

## TEST 2 — CANVAS REMAINS EDITOR

Given:

```text
https://example.framercanvas.com/projects/matti
```

expected:

```text
FRAMER_EDITOR
```

---

## TEST 3 — BLOG CMS

Given:

```text
/blog/post-one
/blog/post-two
```

both must be accepted as published routes.

There must be no special logic for `/blog/`.

---

## TEST 4 — CASES CMS

Given:

```text
/cases/project-a
```

it must be treated the same way.

---

## TEST 5 — SITEMAP INDEX

A sitemap index containing multiple child sitemaps must produce the combined route set.

---

## TEST 6 — DUPLICATES

These:

```text
/projects/matti
/projects/matti/
/projects/matti/index.html
```

must become one logical route.

---

## TEST 7 — CMS DETAIL OUTPUT

A discovered:

```text
/projects/matti
```

must produce:

```text
/projects/matti/index.html
```

through the existing export pipeline.

---

## TEST 8 — EXISTING ROUTES

Existing ordinary routes such as:

```text
/
 /about
 /contact
```

must remain unchanged.

---

## TEST 9 — EXTERNAL DOMAINS

A link to:

```text
https://external.example.com/page
```

must NOT become an exported route.

---

## TEST 10 — EXISTING EXPORT PARAMETERS

Run the same export using the current configuration.

Verify:

- same settings;
- same UI;
- same output conventions;
- same working behavior;
- additional CMS routes only.

---

# REAL-WORLD TEST

Use the current Framer site fixture that previously failed to export CMS detail pages.

The test must prove that:

```text
/projects/index.html
```

and the actual public CMS detail pages:

```text
/projects/<real-slug>/index.html
```

are both present.

Do not use a fake hardcoded fixture only.

The exporter must discover the real public routes.

---

# SECOND REAL-WORLD TEST

Use another Framer site with a materially different CMS structure.

For example, if the first site uses:

```text
/projects/<slug>
```

the second site should use another collection route such as:

```text
/blog/<slug>
```

or:

```text
/cases/<slug>
```

The same implementation must work without changing source code or configuration.

This is mandatory to prove the solution is generic.

---

# IMPORTANT — NO SITE-SPECIFIC HARD-CODING

NEVER add logic such as:

```ts
if (path.startsWith("/projects/"))
```

to identify CMS.

NEVER add:

```ts
if (slug === "matti")
```

NEVER hardcode:

```text
/projects/matti
```

NEVER hardcode Framer-generated module filenames.

NEVER hardcode one site's sitemap structure.

The exporter must derive routes from the current source site.

---

# REGRESSION PROTECTION

After the patch, verify that the following previously working systems still behave identically:

```text
URL input
Export button
job lifecycle
progress stages
route discovery
asset capture
asset localization
HTML rewriting
CSS rewriting
JS rewriting
MIME handling
routing
SEO
ZIP generation
download
NIT
error handling
```

Do not refactor them unless a direct dependency on CMS discovery requires it.

---

# ACCEPTANCE CRITERIA

The patch is accepted only if:

1. `/projects/...` on the target published origin is no longer incorrectly classified as editor infrastructure.

2. `framercanvas.com` remains excluded from published route discovery.

3. CMS routes are discovered without knowing collection names in advance.

4. CMS detail pages are added to the existing route graph.

5. CMS detail pages use the existing export pipeline.

6. CMS detail pages are materialized as:

```text
/route/index.html
```

7. Multiple CMS collections can work.

8. No CMS slug is hardcoded.

9. No module filename is hardcoded.

10. Sitemap indexes are handled.

11. Duplicate routes are canonicalized.

12. External domains are not crawled.

13. Existing export parameters are unchanged.

14. Existing tests remain green.

15. New CMS regression tests pass.

16. At least two materially different CMS structures are tested.

17. A real exported ZIP contains actual CMS detail pages.

18. The exported CMS pages load through the existing HTTP/browser validation pipeline.

19. No unrelated UI or exporter feature has been changed.

---

# DEFINITION OF DONE

Do NOT report completion with a statement such as:

```text
CMS support added.
```

Instead provide evidence:

```text
Baseline tests:
PASS

Modified files:
...

Existing behavior preserved:
YES

Published CMS routes discovered:
N

CMS detail pages exported:
N

CMS collections observed:
...

Example generated files:
...

Sitemap index support:
PASS / NOT PRESENT

Canvas/editor exclusion:
PASS

Hardcoded collection/slug logic:
NONE

Existing export parameters changed:
NO

Regression tests:
PASS

Real-world export:
PASS

Extracted ZIP validation:
PASS
```

If the real-world test still produces only:

```text
/projects/index.html
```

while known public CMS detail pages exist, the task is NOT complete.

---

# EXECUTION ORDER

Follow this order exactly:

## 1. INSPECT

Understand the current code.

## 2. BASELINE

Run existing tests and export once.

## 3. IDENTIFY

Trace why CMS routes disappear.

## 4. PATCH CLASSIFICATION

Fix only the overly broad editor classification.

## 5. PATCH DISCOVERY

Improve sitemap/DOM/browser route discovery only where necessary.

## 6. PATCH ROUTE QUEUE

Ensure discovered CMS routes enter the existing route pipeline.

## 7. TEST

Add regression tests.

## 8. REAL EXPORT

Run against the real Framer CMS site.

## 9. SECOND SITE

Run against another CMS structure.

## 10. REGRESSION

Run the complete existing test suite.

## 11. FINAL VALIDATION

Confirm that existing export parameters and behavior are unchanged.

---

# FINAL INSTRUCTION

This is a SURGICAL FIX.

The desired result is:

```text
CURRENT WORKING YESCODE
        +
GENERIC CMS ROUTE DISCOVERY
        =
CURRENT WORKING YESCODE
        +
CMS DETAIL PAGE EXPORT
```

NOT:

```text
CURRENT WORKING YESCODE
        →
NEW EXPORTER
```

Preserve everything that already works.

Change only what is necessary to make public Framer CMS pages discoverable and exportable.