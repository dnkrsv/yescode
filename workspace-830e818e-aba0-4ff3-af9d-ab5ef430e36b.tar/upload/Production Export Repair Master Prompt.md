# YESCODE — PRODUCTION EXPORT REPAIR MASTER PROMPT

## ROLE

You are a senior software architect, browser automation engineer, static-site infrastructure engineer, reverse-engineering engineer, JavaScript runtime engineer, and QA engineer.

You are working on an EXISTING YesCode codebase.

Your job is NOT to redesign YesCode from scratch.

Your job is to diagnose, reproduce, repair, harden, and validate the existing export engine so that a real exported Framer website works correctly when uploaded to ordinary static hosting.

You must work from evidence.

Do not assume that a successful ZIP creation means the export succeeded.

Do not replace real engineering problems with superficial heuristics.

Do not solve browser/runtime failures with fake validation.

---

# MISSION

Repair the current YesCode exporter.

The current exported sites have at least these known production failures:

1. JavaScript modules with `.mjs` extension are requested from the correct-looking local path, but the server responds with `text/html`.

2. Firefox therefore reports errors such as:

```text
The module at ".../assets/js/modules/rolldown-runtime....mjs"
was blocked because of a disallowed MIME type ("text/html").
```

and similarly for:

```text
framer....
react....
motion....
siteMetadata....
shared-lib....
other dynamically generated .mjs modules....
```

3. This strongly indicates that the request for a JS module is reaching an HTML document or route fallback instead of the actual module file.

4. The exported `/projects/` route contains only one page while Framer CMS project detail pages are missing.

5. Internal route links are incorrectly relative.

For example:

```text
current page:
https://mysite.com/about/
```

A link intended to target:

```text
/contact
```

may currently be emitted as:

```html
<a href="contact">
```

which the browser resolves as:

```text
https://mysite.com/about/contact
```

6. The exporter previously used a `.htaccess` containing:

```apache
AddType application/javascript .mjs

Options -Indexes
```

and this helped with hosting behavior.

Treat this as evidence of a real deployment problem, but DO NOT assume that `.htaccess` alone is the root fix.

The exporter must generate a structurally correct site so that hosting configuration is only part of the solution.

---

# NON-NEGOTIABLE INVARIANTS

The following requirements are mandatory.

## 1. Never return HTML for an asset request

If the browser requests:

```text
/assets/js/modules/foo.mjs
```

the server must either:

- return the actual `foo.mjs` file with correct MIME;
- or return a genuine 404.

It must NEVER return:

```text
/index.html
```

or another HTML page.

This rule applies to:

- `.js`
- `.mjs`
- `.css`
- `.json`
- images
- fonts
- video
- audio
- manifests
- source maps
- WASM
- any other static resource

## 2. MIME correctness is not optional

`.mjs` must be served as JavaScript.

At minimum validate:

```text
.js    -> text/javascript
.mjs   -> text/javascript
.css   -> text/css
.json  -> application/json
.svg   -> image/svg+xml
.webp  -> image/webp
.png   -> image/png
.jpg   -> image/jpeg
.jpeg  -> image/jpeg
.woff2 -> font/woff2
```

Do not consider a file valid merely because it exists on disk.

Validate using an actual HTTP server and a browser/request inspection.

## 3. Route URLs and asset URLs are different classes

Never apply the same relative-path logic to:

- HTML route links
- JavaScript modules
- CSS imports
- images
- fonts
- videos
- API endpoints

Every URL must first be classified.

## 4. Internal website routes must be route-safe

For exported internal routes, prefer root-absolute links.

Example:

```html
href="/contact"
href="/projects"
href="/projects/matti"
```

Do not emit:

```html
href="contact"
href="../contact"
```

for known site routes unless there is a demonstrated reason not to.

This is especially important with directory-style routes.

## 5. Asset references must also resolve from every route depth

A page at:

```text
/about/
```

must be able to load:

```text
/assets/js/main.mjs
/assets/css/main.css
/assets/images/logo.svg
```

without becoming:

```text
/about/assets/...
```

unless that asset was intentionally localized there.

Prefer root-absolute exported asset paths where safe:

```text
/assets/...
```

or correctly computed document-relative paths.

## 6. CMS detail routes must be exported

If a public Framer CMS collection exposes:

```text
/projects/
```

and the public site contains project records such as:

```text
/projects/matti
/projects/project-two
/projects/project-three
```

the exporter must produce:

```text
/projects/index.html
/projects/matti/index.html
/projects/project-two/index.html
/projects/project-three/index.html
```

not only:

```text
/projects/index.html
```

## 7. No editor/canvas routes

Do not discover or export routes from Framer editor/canvas infrastructure.

In particular, do NOT treat URLs from `framercanvas.com` or editor project infrastructure as published-site pages.

The exporter operates on the published website.

## 8. framerusercontent.com resources are real export resources

Required `framerusercontent.com` images, fonts, videos, JSON and other static resources must be captured, localized and rewritten into local paths.

Do not classify them as editor URLs merely because they contain the word "framer".

## 9. Do not delete all Framer JavaScript

Do not use:

```text
hostname contains "framer" => delete
```

or any equivalent heuristic.

Required runtime modules must be captured and localized.

Only remove:

- editor machinery;
- telemetry;
- unnecessary bootstrap infrastructure;
- publishing infrastructure that is not needed for standalone execution.

## 10. Export success requires real evidence

The exporter must not report success based only on:

- ZIP creation;
- file count;
- 200 response from the export API;
- static URL scan;
- one screenshot;
- one successful page load;
- unit tests alone.

---

# FIRST TASK — REPRODUCE THE CURRENT FAILURES

Before changing architecture, inspect the existing repository.

Do the following:

1. Inspect the repository structure.
2. Inspect `package.json`.
3. Inspect the current export pipeline.
4. Find route discovery code.
5. Find CMS discovery code.
6. Find resource localization code.
7. Find HTML rewriting.
8. Find CSS rewriting.
9. Find JS/MJS rewriting.
10. Find ZIP generation.
11. Find hosting configuration generation.
12. Find current validation/NIT logic.
13. Run the current tests.
14. Create or reproduce the current export failure using a representative Framer site.
15. Extract the generated ZIP.
16. Serve the extracted site through a real HTTP server.
17. Reproduce the MIME failures.
18. Reproduce the incorrect nested route behavior.
19. Inspect why CMS detail routes are missing.

Do NOT begin by rewriting the whole project.

First establish the actual failure path.

---

# FAILURE CLASS A — MJS RETURNS HTML

## REQUIRED INVESTIGATION

For a failing path such as:

```text
/assets/js/modules/rolldown-runtime.Dh6celcD.mjs
```

determine all of the following:

1. Does the file exist in the ZIP?
2. What is its exact filesystem path?
3. Is the URL emitted by HTML exactly the same path?
4. Does the path differ because of:
   - leading slash;
   - base URL;
   - nested route;
   - relative resolution;
   - filename normalization;
   - encoding;
   - case sensitivity;
   - rewrite logic?
5. Does the HTTP server return:
   - 200 HTML;
   - 404 HTML;
   - 200 JavaScript with wrong MIME;
   - correct JavaScript?
6. What physical file actually answers the request?
7. Is a rewrite rule intercepting the request?
8. Is a route fallback answering an asset request?
9. Is the asset path accidentally mapped to an HTML route?
10. Is the file missing from the ZIP even though the HTML references it?
11. Is the hosting configuration incorrectly handling `.mjs`?

Do not stop at adding `AddType`.

Fix the cause.

---

# ASSET REQUEST INTEGRITY

Create an explicit integrity test.

For every emitted static asset URL:

```text
request URL
→ expected local node
→ expected local file
→ expected MIME
```

must be known before packaging.

For example:

```json
{
  "url": "/assets/js/modules/react.BP_hhyJh.mjs",
  "localPath": "assets/js/modules/react.BP_hhyJh.mjs",
  "expectedType": "module",
  "expectedMime": "text/javascript",
  "exists": true
}
```

If an HTML file is mapped to this asset node, fail the export.

If the resource is missing, fail the export when the resource is critical.

---

# STATIC SERVER CONTRACT

The generated site must follow this contract.

## HTML routes

```text
/
    -> /index.html

/about
    -> /about/index.html

/about/
    -> /about/index.html

/about/index.html
    -> /about/index.html

/projects/matti
    -> /projects/matti/index.html

/projects/matti/
    -> /projects/matti/index.html
```

## Static assets

```text
/assets/js/main.mjs
    -> exact file

/assets/css/main.css
    -> exact file

/assets/images/logo.svg
    -> exact file
```

## Unknown asset

```text
/assets/js/not-found.mjs
    -> 404
```

Never:

```text
/assets/js/not-found.mjs
    -> /index.html
```

## Unknown route

Return a real 404 or the hosting platform's explicit not-found behavior.

Do not use a universal SPA fallback.

---

# .HTACCESS

Generate an appropriate `.htaccess` for Apache-compatible shared hosting.

At minimum evaluate and, where applicable, include:

```apache
AddType application/javascript .mjs
Options -Indexes
DirectoryIndex index.html
```

Do not blindly add rewrite rules.

Any rewrite rule must preserve the following invariant:

> static resource requests never resolve to an HTML route.

Verify the generated `.htaccess` against the actual exported file tree.

Test it on a real Apache-compatible host when available.

The `.htaccess` is deployment configuration, NOT a substitute for a correct export structure.

---

# FAILURE CLASS B — ROUTE RESOLUTION

## ROOT-ABSOLUTE ROUTES

For known exported site routes, normalize internal links to root-absolute URLs.

Examples:

```text
/contact
/about
/projects
/projects/matti
```

If the source route contains query parameters:

```text
/projects/matti?foo=bar
```

preserve them.

If it contains a fragment:

```text
/projects/matti#section
```

preserve it.

If it is the current page:

```text
#section
```

preserve it as a fragment.

Do not accidentally convert an external URL into an internal route.

---

# INTERNAL URL CLASSIFICATION

Before rewriting an `href`, determine whether it is:

```text
SAME_ORIGIN_ROUTE
SAME_ORIGIN_ASSET
EXTERNAL_URL
MAILTO
TEL
JAVASCRIPT
HASH
DATA
BLOB
UNKNOWN
```

Only rewrite `SAME_ORIGIN_ROUTE` according to route rules.

Do NOT apply route normalization to assets.

---

# ROUTE CANONICALIZATION

Create one central route canonicalization function.

It must normalize:

```text
/contact
/contact/
/contact/index.html
```

into one canonical route identity:

```text
/contact
```

Then separately map that route identity to:

```text
/contact/index.html
```

This route identity must be used consistently by:

- route discovery;
- HTML rewriting;
- sitemap generation;
- CMS route generation;
- validation;
- NIT;
- ZIP generation.

Never maintain multiple incompatible route representations.

---

# FAILURE CLASS C — CMS DETAIL PAGES

This is a critical feature.

The exporter currently exports the collection index but misses individual CMS project pages.

Do NOT solve this by simply guessing filenames.

Build a proper CMS/public-route discovery strategy.

---

# CMS DISCOVERY

Use all publicly observable evidence available.

Potential sources:

1. rendered HTML;
2. hydrated DOM;
3. internal anchor links;
4. navigation;
5. collection index pages;
6. pagination;
7. browser-discovered links;
8. runtime JSON;
9. network responses;
10. public CMS payloads;
11. embedded serialized data;
12. canonical URLs;
13. route patterns;
14. links revealed after hydration;
15. links revealed after scrolling;
16. route references inside runtime state.

The discovery process must distinguish:

```text
collection page
```

from:

```text
collection detail page
```

---

# CMS ROUTE RECONSTRUCTION

Suppose the collection index contains public items such as:

```text
Matti
Project Two
Project Three
```

and Framer exposes their public URLs through:

```text
/projects/matti
/projects/project-two
/projects/project-three
```

the exporter must detect and enqueue all detail routes.

Do not rely only on the links visible in the initial HTML.

Do not rely only on sitemap.xml.

Do not require manual user entry for CMS routes.

---

# CMS DATA MATERIALIZATION

For every discovered CMS detail route:

1. navigate to it;
2. capture the rendered HTML;
3. capture required runtime data;
4. capture required media;
5. localize dependencies;
6. rewrite URLs;
7. save:

```text
/projects/<slug>/index.html
```

The final exported site must not call the Framer CMS at runtime.

---

# CMS DISCOVERY SAFETY

Do not infinitely recurse.

Define:

- route caps;
- CMS item caps;
- recursion limits;
- duplicate detection;
- canonicalization;
- cycle detection;
- request budgets.

Do not crawl unrelated domains.

---

# RESOURCE GRAPH REPAIR

The current implementation must be audited for the difference between:

```text
URL discovered
```

and:

```text
resource successfully localized
```

Create explicit graph states.

Example:

```text
DISCOVERED
FETCHING
FETCHED
LOCALIZED
REWRITTEN
VALIDATED
FAILED
```

A discovered `.mjs` URL is not considered complete until:

1. the resource was fetched;
2. a local file exists;
3. its type is known;
4. references to it were rewritten;
5. the local URL maps to the local file;
6. browser validation confirms successful loading.

---

# RESOURCE CLASSIFICATION

Every external resource must be classified.

Minimum classifications:

```text
FRAMER_ASSET
FRAMER_RUNTIME
FRAMER_TELEMETRY
FRAMER_EDITOR
FRAMER_BOOTSTRAP
PUBLISHED_ROUTE
THIRD_PARTY_STATIC_ASSET
THIRD_PARTY_API
USER_CODE
EXTERNAL_UNSUPPORTED
LOCAL_RESOURCE
INFORMATIONAL_STRING
```

Do not use:

```text
hostname contains "framer"
```

as a universal rule.

---

# FRAMER URL RULES

## framerusercontent.com

Treat required resources from:

```text
framerusercontent.com
```

as first-class export resources.

Examples:

- images;
- fonts;
- videos;
- JSON;
- other static resources.

Capture and localize them.

Rewrite references everywhere they occur.

---

## framercanvas.com

Treat:

```text
framercanvas.com
```

as editor/canvas infrastructure.

Do not use it for published-site route discovery.

Do not export its internal paths as website pages.

---

# JAVASCRIPT / MJS LOCALIZATION

The exporter must resolve:

```text
<script type="module">
```

plus:

```text
modulepreload
```

plus:

```text
import "...";
```

plus:

```text
import(...)
```

plus runtime-loaded chunks.

Recursively resolve JS dependencies.

Do not assume that downloading only the HTML-referenced entry module is sufficient.

---

# AST-BASED JAVASCRIPT REWRITING

Use parser/AST-based techniques for JavaScript wherever semantics permit.

The implementation must support, where relevant:

```text
static import
dynamic import
export from
import.meta
URL constructors
worker references
asset URLs
fetch URLs
XHR URLs
preload manifests
runtime module references
sourceMappingURL
WASM references
```

Never perform global blind string replacement such as:

```text
replaceAll("https://...", "/assets/...")
```

across arbitrary JavaScript.

---

# JS RESOURCE VALIDATION

For every localized `.js` or `.mjs`:

1. verify file exists;
2. verify non-zero size;
3. verify content corresponds to expected resource;
4. verify syntax where technically possible;
5. verify local imports resolve;
6. verify dynamic imports are captured;
7. verify browser can load it;
8. verify HTTP MIME.

An `.mjs` file existing on disk is insufficient.

---

# PATH RESOLUTION MODEL

Implement a central URL resolver.

Do not allow every module to invent its own path logic.

The resolver must understand:

```text
absolute URL
root-relative URL
document-relative URL
relative URL
query strings
fragments
directory route semantics
asset paths
route paths
external origins
```

Example:

Current page:

```text
/about/
```

Input:

```text
contact
```

If the source site semantics indicate an internal route:

```text
/contact
```

must be emitted.

Input:

```text
/assets/app.mjs
```

must remain:

```text
/assets/app.mjs
```

not:

```text
/about/assets/app.mjs
```

---

# HTML REWRITING

Use a proper HTML parser.

Rewrite at minimum:

```text
href
src
srcset
poster
action where applicable
script src
link href
preload
modulepreload
stylesheet
manifest
canonical
inline style
```

Do not rewrite URLs inside visible text.

Do not rewrite arbitrary strings just because they look like URLs.

---

# CSS REWRITING

Handle:

```text
url(...)
@import
fonts
images
masks
SVG
backgrounds
```

Support:

```text
single quotes
double quotes
unquoted URLs
escaping
query strings
fragments
```

Do not rely exclusively on fragile regex replacement.

---

# ASSET PATH STRATEGY

Use deterministic local paths.

Prefer a clear structure such as:

```text
/assets/
    images/
    fonts/
    css/
    js/
    media/
    data/
    vendor/
```

For runtime modules, preserving Framer site identity may be useful.

If technically justified, use:

```text
/assets/js/sites/<siteId>/
```

but only if this provides a real runtime or collision-management benefit.

Do not introduce path complexity without a reason.

---

# FORBIDDEN OUTPUT

Never produce:

```text
/_assets/page.html
/_assets/projects.html
/assets/foo.html
```

HTML route documents must live under route directories only.

For example:

```text
/index.html
/about/index.html
/projects/index.html
/projects/matti/index.html
```

An HTML response captured while crawling an asset-like URL must be classified and stored correctly.

---

# PRE-FLIGHT

Before a full export:

1. validate input URL;
2. verify published-site reachability;
3. resolve redirects;
4. verify HTML root document;
5. establish published origin;
6. detect obvious editor/canvas URLs;
7. measure initial response size;
8. inspect initial runtime characteristics;
9. establish export limits.

Do not begin destructive rewriting during preflight.

---

# BROWSER CAPTURE

Use a real browser.

Capture at least:

- navigation;
- HTML;
- requests;
- responses;
- response MIME;
- redirects;
- JS modules;
- dynamic imports;
- images;
- fonts;
- CSS;
- lazy assets;
- runtime requests;
- network failures;
- console errors;
- page errors.

Do not rely on a single arbitrary timeout.

Use deterministic readiness criteria.

Where appropriate:

- wait for DOM readiness;
- wait for hydration indicators;
- observe network activity;
- scroll;
- allow lazy content to appear;
- inspect layout;
- interact with representative controls.

---

# NETWORK CAPTURE

Use browser-level network instrumentation.

Record:

```text
request URL
response URL
status
content-type
resource type
initiator
request chain
redirect chain
body availability
```

This data feeds the Resource Graph.

Do not destructively rewrite during capture.

---

# THIRD-PARTY ANALYTICS

The observed Yandex Metrica request:

```text
https://mc.yandex.ru/metrika/tag.js
```

must be classified as third-party analytics, not Framer runtime.

Do not automatically classify every external request as an exporter failure.

Define an explicit policy for:

```text
LOCALIZE
PRESERVE EXTERNAL
REMOVE
UNSUPPORTED
```

The exporter must remain Framer-independent without falsely claiming that every possible third-party service can become offline.

If third-party analytics are preserved as external dependencies, this must be explicit in validation results.

---

# STATIC RESIDUAL SCAN

After localization and rewriting, scan:

```text
HTML
CSS
JS
MJS
JSON
SVG
manifests
```

for residual URLs.

Classify all remaining external references.

Do not simply fail because the literal string:

```text
Framer
```

exists somewhere.

A textual reference is not necessarily a network dependency.

A runtime request to a prohibited Framer origin IS a failure.

---

# REAL NETWORK INDEPENDENCE TEST

The final validation must use the actual extracted ZIP.

Procedure:

1. Export.
2. Create ZIP.
3. Extract ZIP to a fresh directory.
4. Start a real HTTP server over the extracted directory.
5. Open the site with a real browser.
6. Block prohibited Framer infrastructure at browser/network level.
7. Optionally disable general internet access for the strict offline test.
8. Load every exported route.
9. Test route variants.
10. Scroll.
11. Trigger representative interactions.
12. Observe:
    - requests;
    - failed requests;
    - console errors;
    - page errors;
    - runtime errors;
    - blank screens;
    - missing assets;
    - failed module loads;
    - failed dynamic imports.

The NIT must specifically fail if required runtime attempts to access prohibited Framer infrastructure.

---

# MANDATORY ROUTE TEST MATRIX

For a route:

```text
/about
```

test:

```text
/about
/about/
/about/index.html
```

For:

```text
/projects/matti
```

test:

```text
/projects/matti
/projects/matti/
/projects/matti/index.html
```

For root:

```text
/
/index.html
```

---

# MANDATORY LINK TEST

From:

```text
/about/
```

click a navigation link intended for:

```text
/contact
```

The resulting URL MUST be:

```text
/contact
```

and MUST NOT be:

```text
/about/contact
```

Repeat this from:

```text
/about/
projects/
projects/matti/
```

to representative site routes.

---

# MANDATORY ASSET TEST

From a nested route such as:

```text
/projects/matti/
```

verify that:

```text
/assets/js/...
/assets/css/...
/assets/images/...
/assets/fonts/...
```

are fetched from root-level asset paths.

They must not become:

```text
/projects/matti/assets/...
```

unless intentionally generated that way.

---

# MANDATORY MJS HTTP TEST

For every `.mjs` referenced by exported HTML or runtime:

1. HTTP GET it;
2. assert status is 200;
3. assert body is JavaScript, not HTML;
4. assert MIME is JavaScript;
5. assert it is not an HTML fallback;
6. load it in browser where possible.

Explicitly fail if:

```text
status = 200
content-type = text/html
```

for a `.mjs` resource.

Also fail if:

```text
body starts as an HTML document
```

despite a nominal JavaScript MIME.

This detects broken rewrite chains.

---

# MANDATORY HTML-FALLBACK DETECTION

For every static asset request:

```text
GET /assets/...
```

assert that the response is not an HTML document unless the resource itself is intentionally HTML.

This must be a dedicated automated test.

---

# HOSTING CONFIGURATION

Generate deployment configuration appropriate for static hosting.

For Apache-compatible hosting generate `.htaccess`.

At minimum evaluate:

```apache
Options -Indexes
DirectoryIndex index.html
AddType application/javascript .mjs
```

Do not assume this is enough.

Validate the actual resulting HTTP behavior.

The export must be correct both:

1. structurally;
2. operationally.

---

# SEO

SEO is a separate phase after the final route model is known.

Generate:

```text
sitemap.xml
robots.txt
```

Preserve or generate:

- title;
- meta description;
- canonical;
- Open Graph;
- Twitter/X metadata;
- structured data;
- language metadata.

Canonical URLs must correspond to the final route model.

---

# ERROR MODEL

## FATAL

At minimum:

- root page unavailable;
- browser cannot render root;
- required route cannot be captured;
- critical JS dependency unresolved;
- critical asset unresolved;
- CMS route discovery fails where required;
- asset request maps to HTML;
- required `.mjs` fails MIME validation;
- route navigation points to the wrong route;
- final standalone browser test fails;
- exported site has prohibited Framer requests.

## NON-FATAL

Potential examples:

- source map missing;
- optional favicon unavailable;
- optional analytics unavailable;
- decorative image unavailable;
- obsolete preload;
- optional third-party service failure.

Do not mark the export successful if any mandatory criterion fails.

---

# OBSERVABILITY

For every export job record:

```text
jobId
sourceUrl
publishedOrigin
currentStage
routeCount
cmsRouteCount
resourceCount
assetCount
jsModuleCount
mjsCount
failedResources
warnings
fatalErrors
duration
memoryUsage
NIT result
```

For each resource keep:

```text
original URL
normalized URL
classification
local path
status
MIME
initiator
parent
localization state
rewrite state
validation state
```

---

# MEMORY AND STABILITY

The current exporter must be protected against browser/server OOM.

Implement:

- bounded concurrency;
- request timeouts;
- browser timeouts;
- maximum response size;
- maximum total export size;
- maximum route count;
- maximum resource count;
- cancellation;
- cleanup;
- temporary directory cleanup;
- browser context cleanup;
- watchdogs.

One failed page must not terminate the exporter process.

---

# DETERMINISM

Three consecutive exports of the same source site must produce equivalent:

- route set;
- CMS route set;
- file set;
- local path assignments;
- critical content hashes;
- JS entrypoints;
- external classifications;
- validation results.

Avoid:

- random path generation;
- unstable graph traversal;
- timestamp-dependent content;
- concurrency-dependent naming;
- nondeterministic route ordering.

---

# TEST FIXTURES

Create or extend test fixtures for:

1. single-page site;
2. multiple routes;
3. nested routes;
4. CMS collection index;
5. CMS detail pages;
6. dynamic imports;
7. `.mjs` modules;
8. lazy-loaded images;
9. fonts;
10. CSS masks;
11. JS-referenced images;
12. runtime assets;
13. user code;
14. third-party analytics;
15. broken assets;
16. slow resources;
17. duplicate filenames;
18. redirects;
19. route fallback;
20. Apache `.htaccess`;
21. asset-to-HTML fallback;
22. nested internal navigation.

---

# REGRESSION TESTS

Add explicit regression tests for:

## 1. MJS MIME failure

Given:

```text
/assets/js/modules/example.mjs
```

the server must not return HTML.

## 2. MJS missing file

A missing `.mjs` must return 404, not `index.html`.

## 3. Nested asset path

From:

```text
/projects/matti/
```

asset paths must resolve correctly.

## 4. Nested route navigation

From:

```text
/about/
```

`/contact` must remain `/contact`.

## 5. CMS detail export

Collection index must produce all discovered public detail pages.

## 6. JS image localization

Images referenced only from JS must still be localized.

## 7. Dynamic imports

All required dynamically imported chunks must exist and load.

## 8. Framer residual runtime request

A required localized runtime must not call prohibited Framer infrastructure.

## 9. HTML-as-asset

No resource URL may resolve to an HTML page.

## 10. `_assets/*.html`

HTML route pages must not be stored as asset files.

## 11. `.htaccess`

Generated Apache configuration must not break static asset delivery.

## 12. Partial export

If a critical CMS route or runtime dependency is missing, export must fail.

## 13. Triple-run determinism

Three exports must be equivalent.

---

# UI

Keep the current YesCode UI minimal.

Use:

- Tailwind CSS;
- Roboto Mono;
- Roboto Flex.

The UI should expose:

```text
URL input
Export
current stage
progress
optional detailed log
Download ZIP
Retry / Re-export
```

Do not introduce:

- dashboards;
- project managers;
- persistent project systems;
- unrelated settings;
- complex feature panels.

Do not change UI architecture to hide export-engine failures.

---

# API

Maintain a clean separation between the UI and export engine.

The backend may expose a job-based model such as:

```text
POST /api/export
GET /api/export/:jobId
GET /api/export/:jobId/events
GET /api/export/:jobId/download
```

Use SSE where it is already appropriate for progress streaming.

The UI must consume structured job state and not infer exporter state from log text.

---

# PIPELINE

The corrected export pipeline should conceptually be:

```text
Preflight
    ↓
Route Discovery
    ↓
CMS Discovery
    ↓
Browser Capture
    ↓
Resource Graph
    ↓
JS Graph Resolution
    ↓
Localization
    ↓
HTML/CSS/JS Rewriting
    ↓
Route Materialization
    ↓
SEO
    ↓
Hosting Configuration
    ↓
Static Validation
    ↓
HTTP Validation
    ↓
Browser Validation
    ↓
Network Independence Test
    ↓
ZIP Packaging
    ↓
Final Verification
```

Stages must exchange structured data.

Do not mutate global state unpredictably between stages.

---

# ARCHITECTURAL PRIORITY

Fix the export engine in this priority order:

## P0 — Correct file serving

Fix:

- wrong local paths;
- missing assets;
- HTML fallback;
- `.mjs` MIME;
- static routing.

## P1 — Correct internal route resolution

Fix:

- absolute/root-relative internal links;
- nested route handling;
- route canonicalization;
- asset base paths.

## P2 — CMS detail discovery

Fix:

- public collection item discovery;
- CMS route generation;
- CMS detail page capture;
- CMS media localization.

## P3 — JS runtime completeness

Fix:

- dynamic imports;
- runtime chunks;
- JS asset references;
- hydration;
- runtime dependencies.

## P4 — Hardening

Fix:

- determinism;
- memory;
- validation;
- NIT;
- regression suite.

## P5 — UI refinement

Only after P0-P4 pass.

---

# IMPORTANT IMPLEMENTATION RULE

Do NOT fix these issues with isolated patches such as:

```text
"add AddType"
"replace href with /"
"hardcode /projects/matti"
"copy more JS files"
```

unless the patch is part of a correct generalized subsystem.

The implementation must fix the underlying model.

Especially:

- MIME failures usually indicate resource-routing/fallback problems;
- wrong nested URLs indicate route-vs-document-relative path ambiguity;
- missing CMS pages indicate incomplete route/CMS discovery.

---

# REQUIRED DEBUG OUTPUT

For each failing resource, produce diagnostics such as:

```text
RESOURCE FAILURE

Original URL:
https://...

Normalized URL:
...

Classification:
FRAMER_RUNTIME

Expected local path:
assets/js/modules/...

File exists:
YES / NO

HTTP status:
...

HTTP Content-Type:
...

Detected body type:
HTML / JS / CSS / IMAGE / ...

Parent:
...

Discovered by:
...

Rewrite state:
...

Validation:
PASS / FAIL
```

For each missing CMS page:

```text
CMS ROUTE FAILURE

Collection:
projects

Candidate:
...

Expected route:
...

Discovery source:
...

Captured:
YES / NO

Materialized:
YES / NO

HTML generated:
YES / NO

Reason:
...
```

---

# ACCEPTANCE CRITERIA

The repair is complete only when all of the following are true.

## FILE STRUCTURE

The extracted ZIP contains real route directories:

```text
/index.html
/about/index.html
/contact/index.html
/projects/index.html
/projects/<slug>/index.html
```

and no accidental HTML files under asset directories.

## MJS

Every critical `.mjs`:

- exists;
- is referenced correctly;
- resolves correctly;
- is served as JavaScript;
- is not served as HTML;
- can load in browser.

## ROUTING

These all work:

```text
/about
/about/
/about/index.html
```

and:

```text
/contact
/projects
/projects/matti
```

## NAVIGATION

From nested pages:

```text
/about/
/projects/
```

internal navigation resolves to the intended root route.

No incorrect:

```text
/about/contact
/projects/contact
```

links are generated.

## CMS

All discovered public CMS detail routes are exported.

The `/projects/` collection must not be considered complete merely because `projects/index.html` exists.

## ASSETS

Images, fonts, CSS, JS, modules, media and other critical resources load.

## MIME

HTTP responses have appropriate MIME types.

## FALLBACK

No static asset request returns HTML.

## FRAMER

No prohibited Framer infrastructure is required at runtime.

Required Framer runtime code is localized rather than blindly removed.

`framerusercontent.com` dependencies required by the exported site are localized.

`framercanvas.com` editor infrastructure does not become published-site routes.

## BROWSER

The extracted site renders through a real browser.

## NIT

The real Network Independence Test passes.

## ZIP

The ZIP is deployable as a normal static website.

---

# DEFINITION OF DONE

Do not claim:

```text
DONE
```

until you have evidence from an actual extracted export.

The final evidence package must include:

1. export completed;
2. ZIP extracted;
3. file tree inspected;
4. representative routes tested;
5. CMS routes tested;
6. `.mjs` resources tested;
7. MIME verified over HTTP;
8. asset fallback tested;
9. nested navigation tested;
10. browser console inspected;
11. failed requests inspected;
12. Network Independence Test executed;
13. prohibited Framer requests checked;
14. deterministic repeat export performed;
15. memory/resource cleanup verified.

---

# EXECUTION PROTOCOL

Follow this order exactly.

## STEP 1 — INSPECT

Inspect the existing repository and architecture.

Do not rewrite yet.

## STEP 2 — REPRODUCE

Reproduce:

- `.mjs -> text/html`;
- nested `/about/contact`;
- missing CMS detail pages.

Record exact root causes.

## STEP 3 — TRACE

Trace each failure through:

```text
source URL
→ capture
→ graph
→ localization
→ rewrite
→ output path
→ HTTP request
→ server response
→ browser behavior
```

## STEP 4 — FIX P0

Correct resource localization, file mapping, static asset routing, and MIME behavior.

## STEP 5 — FIX P1

Correct route canonicalization and internal navigation.

Prefer root-absolute internal route links.

## STEP 6 — FIX P2

Implement robust CMS route discovery and detail-page materialization.

## STEP 7 — FIX P3

Repair runtime module graphs, dynamic imports, and runtime asset localization.

## STEP 8 — FIX P4

Add regression tests, NIT, deterministic export checks, memory protection, and production validation.

## STEP 9 — REAL DEPLOYMENT TEST

Deploy or simulate the extracted ZIP using an actual static HTTP server.

When possible, test the resulting ZIP on an Apache-compatible environment.

Do not validate only inside the YesCode development server.

## STEP 10 — BROWSER TEST

Open:

```text
/
/about
/about/
/projects
/projects/matti
```

and representative CMS routes.

Inspect:

- console;
- network;
- resource MIME;
- navigation;
- lazy loading;
- runtime errors.

## STEP 11 — NIT

Block prohibited Framer infrastructure.

Repeat the browser test.

## STEP 12 — REGRESSION

Run all regression tests.

## STEP 13 — DETERMINISM

Export the same source three times.

Compare:

- routes;
- files;
- paths;
- critical hashes;
- runtime entrypoints;
- validation.

## STEP 14 — ONLY THEN UI

Do not spend time on unrelated UI improvements until export correctness is proven.

---

# FINAL RULES

Never:

- fake the NIT;
- equate file existence with deployment correctness;
- use global regex replacement for JavaScript;
- use universal SPA fallback;
- make all URLs absolute indiscriminately;
- treat every Framer URL as the same thing;
- delete required Framer runtime;
- hardcode specific CMS project slugs;
- report partial exports as successful;
- fix MIME only at the symptom level;
- introduce unrelated product features before the export engine works.

Always:

- identify the actual root cause;
- fix the general subsystem;
- add a regression test;
- test the extracted ZIP;
- test over HTTP;
- test with a real browser;
- validate browser behavior;
- validate CMS routes;
- validate asset requests;
- validate MIME;
- validate route navigation;
- validate Framer independence;
- preserve required runtime behavior.

The objective is not merely to make the current example work.

The objective is to make YesCode robust against this entire class of export failures.